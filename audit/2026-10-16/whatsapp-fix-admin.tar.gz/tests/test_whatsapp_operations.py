import unittest
from unittest.mock import patch, Mock
from app.routers import whatsapp

class WhatsAppOperationsTests(unittest.TestCase):
    @patch.object(whatsapp, 'log_admin_action')
    @patch.object(whatsapp, 'backend_whatsapp')
    def test_test_send_calls_backend_and_never_claims_delivery(self, backend, audit):
        backend.return_value = {'success': True, 'message': 'Aceita', 'data': {'status': 'accepted'}}
        response = whatsapp.send_test_message('11912345678', 'dose_reminder', 'test-request', {'name': 'Test'})
        args = backend.call_args.args
        self.assertEqual(args[:2], ('send', 'POST'))
        self.assertEqual(args[2]['requestId'], 'test-request')
        self.assertIn('msg=accepted', response.headers['location'])
        self.assertNotIn('delivered', response.headers['location'])

    @patch.object(whatsapp, 'log_admin_action')
    @patch.object(whatsapp, 'backend_whatsapp')
    def test_failure_is_shown_as_failure(self, backend, audit):
        backend.return_value = {'success': False, 'message': 'Linha desconectada'}
        response = whatsapp.send_test_message('11912345678', 'dose_reminder', 'test-request', {'name': 'Test'})
        self.assertIn('error=', response.headers['location'])
        self.assertNotIn('msg=', response.headers['location'])

    @patch.object(whatsapp, 'log_admin_action')
    @patch.object(whatsapp, 'backend_whatsapp')
    def test_resend_calls_backend_instead_of_mutating_database(self, backend, audit):
        backend.return_value = {'success': False, 'message': 'Resultado não confirmado'}
        response = whatsapp.resend_whatsapp_event('event-id', {'name': 'Test'})
        backend.assert_called_once_with('resend', 'POST', {'eventId': 'event-id'})
        self.assertIn('error=', response.headers['location'])

    @patch.object(whatsapp, 'WHATSAPP_ADMIN_TOKEN', 'x' * 64)
    @patch.object(whatsapp.requests, 'request')
    def test_http_failure_is_not_a_success(self, request):
        request.return_value = Mock(ok=False, json=lambda: {'message': 'Provedor indisponível'})
        self.assertFalse(whatsapp.backend_whatsapp('send', 'POST', {})['success'])

    @patch.object(whatsapp, 'WHATSAPP_ADMIN_TOKEN', 'x' * 64)
    @patch.object(whatsapp.requests, 'request')
    def test_lost_response_has_uncertain_result(self, request):
        request.side_effect = whatsapp.requests.Timeout()
        result = whatsapp.backend_whatsapp('send', 'POST', {})
        self.assertFalse(result['success'])
        self.assertIn('histórico', result['message'])

if __name__ == '__main__': unittest.main()
