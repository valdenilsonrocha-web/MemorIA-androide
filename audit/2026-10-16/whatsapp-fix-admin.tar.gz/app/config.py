import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# Carrega arquivo .env da raiz do projeto
BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

def resolve_db_path(path_str: str) -> str:
    """Resolve caminhos entre Linux/WSL e Windows nativo."""
    if not path_str:
        return str(BASE_DIR / "memoria_admin.sqlite")
    
    # Se estiver rodando no Linux/WSL e o path for formato Windows 'D:\DEV\...'
    if sys.platform.startswith("linux") and (":" in path_str or "\\" in path_str):
        # Ex: D:\DEV\MemorIA\... -> /mnt/d/DEV/MemorIA/...
        drive = path_str[0].lower()
        rest = path_str[2:].replace("\\", "/")
        path_str = f"/mnt/{drive}{rest}"
    # Se estiver rodando no Windows e o path for '/mnt/d/...'
    elif sys.platform.startswith("win") and path_str.startswith("/mnt/"):
        parts = path_str.split("/")
        if len(parts) > 2 and len(parts[2]) == 1:
            drive = parts[2].upper()
            rest = "\\".join(parts[3:])
            path_str = f"{drive}:\\{rest}"

    return path_str

PORT = int(os.getenv("PORT", "8000"))
HOST = os.getenv("HOST", "0.0.0.0")
DEBUG = os.getenv("DEBUG", "True").lower() in ("true", "1", "yes")
SECRET_KEY = os.getenv("SECRET_KEY", "")
if not SECRET_KEY:
    if DEBUG:
        import secrets
        SECRET_KEY = secrets.token_hex(32)
    else:
        raise RuntimeError("CRITICAL SECURITY ERROR: SECRET_KEY environment variable is required in production.")
ROOT_PATH = os.getenv("ROOT_PATH", "").rstrip("/")

def url_path(path: str) -> str:
    """Retorna o caminho com prefixo do ROOT_PATH se configurado."""
    if not path.startswith("/"):
        path = "/" + path
    if ROOT_PATH and not path.startswith(ROOT_PATH):
        return f"{ROOT_PATH}{path}"
    return path

ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "")
ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "admin@memoria.app")

DB_DIALECT = os.getenv("DB_DIALECT", "sqlite").lower()
DB_STORAGE = ""

if DB_DIALECT == "sqlite":
    raw_storage = os.getenv("DB_STORAGE", "")
    resolved_storage = resolve_db_path(raw_storage)
    # Se o arquivo não existir ou diretório não existir, verifica se o backend tem
    if not os.path.exists(resolved_storage):
        # Tenta caminhos comuns relativos
        candidate = Path("/mnt/d/DEV/MemorIA/backend/memoria_dev.sqlite")
        candidate_win = Path("D:/DEV/MemorIA/backend/memoria_dev.sqlite")
        if candidate.exists():
            resolved_storage = str(candidate)
        elif candidate_win.exists():
            resolved_storage = str(candidate_win)
        else:
            # Fallback para o arquivo local dentro de MemorIA-Admin
            resolved_storage = str(BASE_DIR / "memoria_admin.sqlite")
            
    DB_STORAGE = resolved_storage
    DATABASE_URL = f"sqlite:///{DB_STORAGE}"
elif DB_DIALECT in ("postgres", "postgresql"):
    DB_HOST = os.getenv("DB_HOST", "localhost")
    DB_PORT = os.getenv("DB_PORT", "5432")
    DB_NAME = os.getenv("DB_NAME", "memoria_db")
    DB_USER = os.getenv("DB_USER", "postgres")
    DB_PASSWORD = os.getenv("DB_PASSWORD", "")
    DB_SSL = os.getenv("DB_SSL", "false").lower() in ("true", "1")
    ssl_query = "?sslmode=require" if DB_SSL else ""
    DATABASE_URL = f"postgresql+psycopg2://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}{ssl_query}"
else:
    DATABASE_URL = f"sqlite:///{BASE_DIR / 'memoria_admin.sqlite'}"

MEMORIA_BACKEND_URL = os.getenv("MEMORIA_BACKEND_URL", "http://localhost:3001")

# HeraclitusDB (Auditoria e Logs Imutáveis)
HERACLITUS_ADDRESS = os.getenv("HERACLITUS_ADDRESS", "127.0.0.1:7474")
HERACLITUS_TOKEN = os.getenv("HERACLITUS_TOKEN", "")
HERACLITUS_TLS = os.getenv("HERACLITUS_TLS", "false").lower() in ("true", "1")


# Scoped server credential; never exposed to the browser.
WHATSAPP_ADMIN_TOKEN = os.getenv('WHATSAPP_ADMIN_TOKEN', '')
