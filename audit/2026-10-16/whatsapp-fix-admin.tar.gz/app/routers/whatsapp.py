from typing import Optional
from uuid import uuid4
from urllib.parse import quote
import requests
from fastapi import APIRouter, Request, Depends, responses, status, Query, Form
from sqlalchemy.orm import Session
from sqlalchemy import or_, desc
from app.config import url_path, MEMORIA_BACKEND_URL, WHATSAPP_ADMIN_TOKEN
from app.database import get_db
from app.models import WhatsAppEvent
from app.auth import require_admin
from app.audit import log_admin_action

router = APIRouter(prefix="/whatsapp", tags=["whatsapp"])


def backend_whatsapp(path, method="GET", payload=None):
    if not WHATSAPP_ADMIN_TOKEN:
        return {"success": False, "message": "Integração administrativa do WhatsApp não configurada."}
    try:
        response = requests.request(method, f"{MEMORIA_BACKEND_URL.rstrip('/')}/api/integrations/whatsapp/ops/{path}",
            headers={"x-whatsapp-admin-token": WHATSAPP_ADMIN_TOKEN}, json=payload, timeout=(3, 18))
        result = response.json()
        if not response.ok:
            return {"success": False, "message": result.get("message") or "Falha ao consultar o WhatsApp."}
        return result
    except (requests.RequestException, ValueError):
        return {"success": False, "message": "Não foi possível confirmar o resultado no servidor. Consulte o histórico antes de tentar novamente."}


def result_redirect(result, success_message):
    suffix = f"msg={success_message}" if result.get("success") else "error=" + quote(str(result.get("message", "Falha no envio.")), safe="")
    return responses.RedirectResponse(url=url_path("/whatsapp?" + suffix), status_code=status.HTTP_303_SEE_OTHER)


@router.get("")
def list_whatsapp_events(request: Request, admin: dict = Depends(require_admin),
    q: Optional[str] = Query(None), status_filter: Optional[str] = Query(None, alias="status"),
    provider_filter: Optional[str] = Query(None, alias="provider"), page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=5, le=100), db: Session = Depends(get_db)):
    from app.main import templates
    query = db.query(WhatsAppEvent)
    if q:
        search = f"%{q.strip()}%"
        query = query.filter(or_(WhatsAppEvent.recipient.ilike(search), WhatsAppEvent.message_id.ilike(search), WhatsAppEvent.event_type.ilike(search), WhatsAppEvent.error.ilike(search)))
    if status_filter:
        query = query.filter(WhatsAppEvent.status == status_filter)
    if provider_filter:
        query = query.filter(WhatsAppEvent.provider == provider_filter)
    total_records = query.count()
    total_pages = (total_records + page_size - 1) // page_size if total_records > 0 else 1
    events = query.order_by(desc(WhatsAppEvent.event_at)).offset((page - 1) * page_size).limit(page_size).all()
    connection = backend_whatsapp("status")
    return templates.TemplateResponse(request=request, name="whatsapp/list.html", context={
        "request": request, "admin": admin, "events": events, "total": total_records,
        "page": page, "page_size": page_size, "total_pages": total_pages,
        "q": q or "", "status_filter": status_filter or "", "provider_filter": provider_filter or "",
        "msg": request.query_params.get("msg"), "error": request.query_params.get("error"),
        "connection": connection.get("data") or {"connected": False, "state": "unavailable"},
        "connection_error": connection.get("message") if not connection.get("success") else None,
        "request_id": str(uuid4()),
    })


@router.get("/status")
def whatsapp_status(admin: dict = Depends(require_admin)):
    return backend_whatsapp("status")


@router.post("/connect")
def connect_whatsapp(request: Request, admin: dict = Depends(require_admin)):
    from app.main import templates
    result = backend_whatsapp("qrcode", "POST")
    data = result.get("data") or {}
    qr = data.get("base64") or (data.get("qrcode") or {}).get("base64") or ""
    if not qr.startswith("data:image/png;base64,"):
        qr = ""
    return templates.TemplateResponse(request=request, name="whatsapp/connect.html", context={
        "request": request, "admin": admin, "qr": qr,
        "error": result.get("message") if not result.get("success") else None,
    }, headers={"Cache-Control": "no-store"})


@router.post("/{event_id}/resend")
def resend_whatsapp_event(event_id: str, admin: dict = Depends(require_admin)):
    result = backend_whatsapp("resend", "POST", {"eventId": event_id})
    log_admin_action(admin, "REENVIO_WHATSAPP_ACEITO" if result.get("success") else "REENVIO_WHATSAPP_FALHOU", "WhatsAppEvent", event_id, result.get("message", ""))
    return result_redirect(result, "accepted")


@router.post("/send-test")
def send_test_message(phone: str = Form(...), message_type: str = Form("dose_reminder"),
    request_id: str = Form(...), admin: dict = Depends(require_admin)):
    labels = {"dose_reminder": "lembrete de medicamento", "missed_dose_alert": "alerta ao cuidador", "stock_low_warning": "aviso de estoque", "welcome": "boas-vindas"}
    message = f"*MemorIA — Mensagem de teste*\n\nEste é um teste de {labels.get(message_type, 'notificação')} solicitado pelo administrador. Não representa uma dose real."
    result = backend_whatsapp("send", "POST", {"to": phone, "message": message, "requestId": request_id})
    log_admin_action(admin, "TESTE_WHATSAPP_ACEITO" if result.get("success") else "TESTE_WHATSAPP_FALHOU", "WhatsAppEvent", request_id, result.get("message", ""))
    return result_redirect(result, "accepted")
