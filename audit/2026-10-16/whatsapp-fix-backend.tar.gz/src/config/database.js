import { Sequelize } from 'sequelize';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dialect = process.env.DB_DIALECT || 'sqlite';

let sequelize;

if (dialect === 'sqlite') {
    const storagePath = process.env.DB_STORAGE || path.join(__dirname, '../../memoria_dev.sqlite');
    sequelize = new Sequelize({
        dialect: 'sqlite',
        storage: storagePath,
        logging: process.env.NODE_ENV === 'development' ? console.log : false,
    });
} else {
    const isProduction = process.env.NODE_ENV === 'production';
    const defaultPort = dialect === 'mysql' ? 3306 : 5432;
    const defaultUser = dialect === 'mysql' ? 'root' : 'postgres';

    // Monta a string de conexão para Postgres, adicionando sslmode=require se necessário
    let dbHost = process.env.DB_HOST || 'localhost';
    let dbName = process.env.DB_NAME || 'memoria_db';
    let dbUser = process.env.DB_USER || defaultUser;
    let dbPassword = process.env.DB_PASSWORD || '';
    let dbPort = parseInt(process.env.DB_PORT) || defaultPort;
    let connectionUri = '';
    if (dialect === 'postgres') {
        // SSL: obrigatório para bancos geridos (Neon, RDS), impossível num
        // Postgres local — que normalmente nem serve TLS. Forçá-lo sempre
        // quebrava o deploy com DB no próprio host (erro `self-signed
        // certificate`); desligá-lo por omissão exporia as credenciais num
        // banco remoto se alguém se esquecesse da variável.
        //
        // Por isso o default segue o host e DB_SSL só é lido quando definido:
        // remoto => SSL ligado; loopback => desligado. Seguro sem configuração
        // em ambos os casos, e explicitamente sobreponível nos dois sentidos.
        const isLoopbackDb = ['localhost', '127.0.0.1', '::1'].includes(dbHost);
        const useSsl = process.env.DB_SSL === undefined || process.env.DB_SSL === ''
            ? !isLoopbackDb
            : process.env.DB_SSL === 'true';

        const sslQuery = useSsl ? '?sslmode=verify-full' : '';
        connectionUri = `postgres://${encodeURIComponent(dbUser)}:${encodeURIComponent(dbPassword)}@${dbHost}:${dbPort}/${dbName}${sslQuery}`;
        sequelize = new Sequelize(connectionUri, {
            dialect,
            logging: process.env.NODE_ENV === 'development' ? console.log : false,
            pool: {
                max: 5,
                min: 0,
                acquire: 60000,
                idle: 30000
            },
            dialectOptions: {
                connectTimeout: 60000,
                ...(useSsl && { ssl: { require: true, rejectUnauthorized: isProduction } })
            }
        });
    } else {
        sequelize = new Sequelize({
            host: dbHost,
            port: dbPort,
            database: dbName,
            username: dbUser,
            password: dbPassword,
            dialect,
            logging: process.env.NODE_ENV === 'development' ? console.log : false,
            pool: {
                max: 5,
                min: 0,
                acquire: 60000,
                idle: 30000
            },
            dialectOptions: {
                connectTimeout: 60000,
                ...(dialect === 'mysql' && {
                    charset: 'utf8mb4',
                    supportBigNumbers: true,
                    bigNumberStrings: true
                })
            }
        });
    }
}

// Test connection
export const testConnection = async () => {
    try {
        await sequelize.authenticate();
        console.log('✓ Database connection established successfully');
        return true;
    } catch (error) {
        console.error('✗ Unable to connect to database:', {
            dialect,
            host: process.env.DB_HOST,
            port: process.env.DB_PORT,
            database: process.env.DB_NAME,
            user: process.env.DB_USER,
            code: error?.original?.code || error?.code,
            message: error?.original?.message || error?.message
        });
        return false;
    }
};

export default sequelize;
