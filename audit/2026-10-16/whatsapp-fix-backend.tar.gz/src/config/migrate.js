/**
 * Migração idempotente — adiciona ao schema as colunas novas que o `sync` não cria.
 * Rode uma vez por ambiente, ANTES de subir a versão nova do código:
 *
 *   npm run migrate
 *
 * Em produção isto não é opcional: `server.js` calcula
 * `shouldAlterSchema = !isProduction && DB_SYNC_ALTER === 'true'`, portanto com
 * NODE_ENV=production o sync NUNCA altera o schema — pôr DB_SYNC_ALTER=true no
 * .env de produção não tem efeito nenhum. Uma coluna declarada num model mas
 * ausente da tabela faz o Sequelize incluí-la no SELECT e o Postgres rejeitar a
 * query inteira, derrubando o endpoint (não é uma degradação parcial).
 *
 * Compatível com Postgres / MySQL / SQLite (usa queryInterface.addColumn).
 */
import dotenv from 'dotenv';
import { DataTypes } from 'sequelize';
import sequelize from './database.js';
import '../models/index.js'; // garante que os models/associações carregam

dotenv.config();

const COLUMNS_BY_TABLE = {
    users: {
        google_play_subscription: { type: DataTypes.JSON, allowNull: true },
        caregivers: { type: DataTypes.JSON, allowNull: true },
        subscription_status: { type: DataTypes.STRING(40), allowNull: true },
        subscription_id: { type: DataTypes.STRING(120), allowNull: true },
        report_auto_send_enabled: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
        report_frequency: { type: DataTypes.ENUM('weekly', 'monthly'), allowNull: false, defaultValue: 'weekly' },
        report_contact_email: { type: DataTypes.STRING(255), allowNull: true },
        last_report_sent_at: { type: DataTypes.DATE, allowNull: true },
        last_report_period_key: { type: DataTypes.STRING(40), allowNull: true },
        report_last_meta: { type: DataTypes.JSON, allowNull: true },
        medical_consultations: { type: DataTypes.JSON, allowNull: true },
        health_vital_signs: { type: DataTypes.JSON, allowNull: true },
        voice_assistant_config: { type: DataTypes.JSON, allowNull: true },
        // Início dos 7 dias de acesso total (middleware/auth.js getUserTrialInfo).
        first_login_at: { type: DataTypes.DATE, allowNull: true }
    },
    medications: {
        // Fornecedor/Farmácia (Premium): {name, phone}. Sem esta coluna o
        // alerta de stock crítico à farmácia não tem para onde ligar.
        supplier: { type: DataTypes.JSON, allowNull: true }
    },
    prescriptions: {
        ocr_text: { type: DataTypes.TEXT, allowNull: true }
    }
};

const run = async () => {
    await sequelize.authenticate();
    const qi = sequelize.getQueryInterface();

    for (const [tableName, columns] of Object.entries(COLUMNS_BY_TABLE)) {
        let table;
        try {
            table = await qi.describeTable(tableName);
        } catch {
            console.log(`! ${tableName}: tabela não existe ainda, ignorada`);
            continue;
        }

        for (const [col, def] of Object.entries(columns)) {
            if (table[col]) {
                console.log(`= ${tableName}.${col}: já existe, ignorado`);
                continue;
            }
            await qi.addColumn(tableName, col, def);
            console.log(`+ ${tableName}.${col}: coluna adicionada`);
        }
    }
    console.log('✓ Migração concluída.');
};

run()
    .then(() => sequelize.close())
    .then(() => process.exit(0))
    .catch((error) => {
        console.error('✗ Migração falhou:', error.message);
        process.exit(1);
    });
