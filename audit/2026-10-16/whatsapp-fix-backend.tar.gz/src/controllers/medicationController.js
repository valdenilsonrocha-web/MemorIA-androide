import { Medication } from '../models/index.js';
import { Op } from 'sequelize';

const sanitizeString = (value, max = 255) => String(value || '').trim().slice(0, max);
const sanitizeStringArray = (value) => {
    if (!Array.isArray(value)) return [];
    return value
        .map((item) => sanitizeString(item, 16))
        .filter(Boolean)
        .slice(0, 12);
};

const sanitizeWeekDays = (value) => {
    if (!Array.isArray(value)) return [];
    const unique = new Set();
    value.forEach((item) => {
        const day = Number.parseInt(item, 10);
        if (Number.isInteger(day) && day >= 0 && day <= 6) {
            unique.add(day);
        }
    });
    return Array.from(unique).slice(0, 7);
};

const FREQUENCIES = ['daily', 'alternate', 'weekly'];

/**
 * Recusa payloads que produziriam um medicamento que NUNCA lembra ninguém.
 *
 * Antes, tudo isto era corrigido em silêncio e devolvia 201: uma frequência
 * desconhecida virava 'daily', e uma lista de horários vazia era aceite tal e
 * qual. Num app de adesão à medicação esse é o pior desfecho possível — o
 * doente recebe "cadastrado com sucesso" e fica convencido de que está coberto,
 * enquanto o `notificationService` salta o medicamento por não ter horários
 * (ver frontend/public/src/services/notificationService.js) e nenhum lembrete
 * chega. Um erro visível é estritamente melhor do que um sucesso mentiroso.
 *
 * Só se exige horário a medicamentos ATIVOS: um tratamento pausado não precisa
 * de agenda e continua a poder ser guardado.
 */
const validateMedicationPayload = (payload = {}) => {
    if (!sanitizeString(payload.name, 255)) return 'Nome do medicamento é obrigatório.';

    if (payload.frequency !== undefined && !FREQUENCIES.includes(payload.frequency)) {
        return `Frequência inválida. Use uma de: ${FREQUENCIES.join(', ')}.`;
    }

    const isActive = payload.active === undefined ? true : payload.active !== false;
    if (isActive) {
        if (sanitizeStringArray(payload.times).length === 0) {
            return 'Informe pelo menos um horário — sem horário nenhum lembrete é enviado.';
        }
        if (payload.frequency === 'weekly' && sanitizeWeekDays(payload.weekDays).length === 0) {
            return 'Frequência semanal exige pelo menos um dia da semana.';
        }
    }

    return null;
};

const pickMedicationPayload = (payload = {}, { allowActive = true } = {}) => {
    const normalized = {
        name: sanitizeString(payload.name, 255),
        dosage: sanitizeString(payload.dosage, 100),
        frequency: ['daily', 'alternate', 'weekly'].includes(payload.frequency) ? payload.frequency : 'daily',
        times: sanitizeStringArray(payload.times),
        weekDays: sanitizeWeekDays(payload.weekDays),
        instructions: payload.instructions == null ? null : sanitizeString(payload.instructions, 2000),
        stock: Number.isFinite(Number.parseInt(payload.stock, 10)) ? Math.max(0, Number.parseInt(payload.stock, 10)) : 0
    };

    // `supplier` só é tocado quando o cliente o envia. Antes era sempre
    // reescrito — e como nenhum ecrã do app móvel o preenche, qualquer edição
    // feita no telemóvel apagaria em silêncio o contacto da farmácia definido
    // na web, desligando o alerta de stock crítico sem aviso nenhum. Enviar
    // `supplier: null` explicitamente continua a limpá-lo, de propósito.
    if ('supplier' in payload) {
        normalized.supplier = payload.supplier && typeof payload.supplier === 'object' ? {
            name: sanitizeString(payload.supplier.name, 255),
            phone: sanitizeString(payload.supplier.phone, 20)
        } : null;
    }

    if (allowActive && payload.active !== undefined) {
        normalized.active = payload.active !== false;
    }

    return normalized;
};

// @desc    Get all medications for user
// @route   GET /api/medications
// @access  Private
export const getMedications = async (req, res) => {
    try {
        const medications = await Medication.findAll({
            where: { userId: req.user.id },
            order: [['createdAt', 'DESC']]
        });

        res.json({
            success: true,
            count: medications.length,
            data: { medications }
        });
    } catch (error) {
        console.error('Get medications error:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao buscar medicamentos.',
            error: error.message
        });
    }
};

// @desc    Get single medication
// @route   GET /api/medications/:id
// @access  Private
export const getMedication = async (req, res) => {
    try {
        const medication = await Medication.findOne({
            where: {
                id: req.params.id,
                userId: req.user.id
            }
        });

        if (!medication) {
            return res.status(404).json({
                success: false,
                message: 'Medicamento não encontrado.'
            });
        }

        res.json({
            success: true,
            data: { medication }
        });
    } catch (error) {
        console.error('Get medication error:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao buscar medicamento.',
            error: error.message
        });
    }
};

// @desc    Create new medication
// @route   POST /api/medications
// @access  Private
export const createMedication = async (req, res) => {
    try {
        const invalid = validateMedicationPayload(req.body || {});
        if (invalid) {
            return res.status(400).json({ success: false, message: invalid });
        }

        const medicationData = {
            ...pickMedicationPayload(req.body, { allowActive: true }),
            userId: req.user.id
        };

        const medication = await Medication.create(medicationData);

        res.status(201).json({
            success: true,
            message: 'Medicamento cadastrado com sucesso.',
            data: { medication }
        });
    } catch (error) {
        console.error('Create medication error:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao cadastrar medicamento.',
            error: error.message
        });
    }
};

// @desc    Update medication
// @route   PUT /api/medications/:id
// @access  Private
export const updateMedication = async (req, res) => {
    try {
        const invalid = validateMedicationPayload(req.body || {});
        if (invalid) {
            return res.status(400).json({ success: false, message: invalid });
        }

        const medication = await Medication.findOne({
            where: {
                id: req.params.id,
                userId: req.user.id
            }
        });

        if (!medication) {
            return res.status(404).json({
                success: false,
                message: 'Medicamento não encontrado.'
            });
        }

        const safeUpdate = pickMedicationPayload(req.body, { allowActive: true });
        await medication.update(safeUpdate);

        res.json({
            success: true,
            message: 'Medicamento atualizado com sucesso.',
            data: { medication }
        });
    } catch (error) {
        console.error('Update medication error:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao atualizar medicamento.',
            error: error.message
        });
    }
};

// @desc    Delete medication
// @route   DELETE /api/medications/:id
// @access  Private
export const deleteMedication = async (req, res) => {
    try {
        const medication = await Medication.findOne({
            where: {
                id: req.params.id,
                userId: req.user.id
            }
        });

        if (!medication) {
            return res.status(404).json({
                success: false,
                message: 'Medicamento não encontrado.'
            });
        }

        // Soft delete - mark as inactive
        await medication.update({ active: false });

        res.json({
            success: true,
            message: 'Medicamento removido com sucesso.'
        });
    } catch (error) {
        console.error('Delete medication error:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao remover medicamento.',
            error: error.message
        });
    }
};

// @desc    Sync medications from local storage
// @route   POST /api/medications/sync
// @access  Private
export const syncMedications = async (req, res) => {
    try {
        const { medications: localMedications } = req.body;

        if (!Array.isArray(localMedications)) {
            return res.status(400).json({
                success: false,
                message: 'Dados inválidos.'
            });
        }

        const syncedMedications = [];

        for (const localMed of localMedications) {
            const safeLocalMed = pickMedicationPayload(localMed, { allowActive: true });

            // Check if medication already exists (by local ID or other identifier)
            let medication = await Medication.findOne({
                where: {
                    userId: req.user.id,
                    name: safeLocalMed.name,
                    dosage: safeLocalMed.dosage,
                    createdAt: localMed.createdAt
                }
            });

            if (medication) {
                // Update existing
                await medication.update({
                    times: safeLocalMed.times,
                    frequency: safeLocalMed.frequency,
                    weekDays: safeLocalMed.weekDays,
                    instructions: safeLocalMed.instructions,
                    stock: safeLocalMed.stock,
                    supplier: safeLocalMed.supplier,
                    active: safeLocalMed.active
                });
            } else {
                // Create new
                medication = await Medication.create({
                    userId: req.user.id,
                    name: safeLocalMed.name,
                    dosage: safeLocalMed.dosage,
                    frequency: safeLocalMed.frequency,
                    times: safeLocalMed.times,
                    weekDays: safeLocalMed.weekDays,
                    instructions: safeLocalMed.instructions,
                    stock: safeLocalMed.stock,
                    supplier: safeLocalMed.supplier,
                    active: safeLocalMed.active !== false
                });
            }

            syncedMedications.push(medication);
        }

        // Update user's last sync time
        await req.user.update({ lastSync: new Date() });

        res.json({
            success: true,
            message: 'Medicamentos sincronizados com sucesso.',
            data: {
                medications: syncedMedications,
                syncedAt: new Date()
            }
        });
    } catch (error) {
        console.error('Sync medications error:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao sincronizar medicamentos.',
            error: error.message
        });
    }
};
