import Stripe from 'stripe';
import {
    isMercadoPagoConfigured,
    createSubscription as mpCreateSubscription,
    getSubscription as mpGetSubscription,
    cancelSubscription as mpCancelSubscription,
    isAccessActive as mpIsAccessActive,
    validateWebhookSignature as mpValidateSignature,
    createSubscriptionWithCardToken as mpCreateSubscriptionWithCardToken,
    getPublicKey as mpGetPublicKey,
    PLAN_CONFIG as MP_PLAN_CONFIG,
    TRIAL_PERIOD_DAYS as MP_TRIAL_DAYS
} from '../services/mercadoPago.js';
import { User } from '../models/index.js';

const PAYMENT_GATEWAY = () => (process.env.PAYMENT_GATEWAY || 'stripe').toLowerCase();
const isMercadoPago = () => PAYMENT_GATEWAY() === 'mercadopago';

const PLAN_CONFIG = {
    monthly: {
        label: 'Mensal',
        interval: 'month',
        amountInCents: 1490,
        displayPrice: 'R$ 14,90/mês'
    },
    annual: {
        label: 'Anual',
        interval: 'year',
        amountInCents: 11880,
        displayPrice: 'R$ 9,90/mês (cobrança anual de R$ 118,80)'
    }
};

const TRIAL_PERIOD_DAYS = 7;

const getStripeClient = () => {
    if (!process.env.STRIPE_SECRET_KEY) {
        return null;
    }

    return new Stripe(process.env.STRIPE_SECRET_KEY, {
        apiVersion: '2024-06-20'
    });
};

const containsSensitiveCardData = (payload = {}) => {
    const blockedKeys = [
        'cardNumber',
        'card_number',
        'number',
        'pan',
        'cvv',
        'cvc',
        'securityCode',
        'expMonth',
        'expYear',
        'expiry',
        'expirationDate'
    ];

    return blockedKeys.some((key) => Object.prototype.hasOwnProperty.call(payload, key));
};

const sanitizeString = (value, max = 255) => String(value || '').trim().slice(0, max);
const onlyDigits = (value = '') => String(value || '').replace(/\D/g, '');

const sanitizePlan = (value) => (value === 'annual' ? 'annual' : 'monthly');

const sanitizeBaseUrl = (value = '') => String(value || '').trim().replace(/\/+$/, '');

const isLocalHttpUrl = (url = '') => {
    const normalized = String(url || '').toLowerCase();
    return normalized.startsWith('http://localhost') || normalized.startsWith('http://127.0.0.1');
};

const extractOriginFromReferer = (referer = '') => {
    try {
        if (!referer) return '';
        const parsed = new URL(String(referer));
        return sanitizeBaseUrl(parsed.origin);
    } catch {
        return '';
    }
};

const resolveFrontendUrlFromRequest = (req) => {
    const byOrigin = sanitizeBaseUrl(req.get('origin') || '');
    if (byOrigin) return byOrigin;

    const byReferer = extractOriginFromReferer(req.get('referer') || '');
    if (byReferer) return byReferer;

    const forwardedProto = sanitizeString(req.get('x-forwarded-proto') || '', 20).toLowerCase();
    const forwardedHost = sanitizeString(req.get('x-forwarded-host') || '', 255);
    if ((forwardedProto === 'http' || forwardedProto === 'https') && forwardedHost) {
        return sanitizeBaseUrl(`${forwardedProto}://${forwardedHost}`);
    }

    const host = sanitizeString(req.get('host') || '', 255);
    if (host) {
        const protocol = req.protocol === 'https' ? 'https' : 'http';
        return sanitizeBaseUrl(`${protocol}://${host}`);
    }

    return '';
};

// ── Mercado Pago (assinatura) — handlers que espelham a API do gateway Stripe ──

const createMercadoPagoCheckout = async (req, res) => {
    if (!isMercadoPagoConfigured()) {
        return res.status(500).json({
            success: false,
            message: 'Gateway Mercado Pago não configurado. Defina MERCADOPAGO_ACCESS_TOKEN no backend.'
        });
    }
    const { plan = 'monthly', customerEmail = '', invoiceEmail = '' } = req.body || {};
    const payerEmail = sanitizeString(invoiceEmail || customerEmail, 255).toLowerCase();
    if (!payerEmail) {
        return res.status(400).json({ success: false, message: 'E-mail do pagador é obrigatório para o Mercado Pago.' });
    }
    const safePlan = sanitizePlan(plan);
    const configuredFrontendUrl = sanitizeBaseUrl(process.env.FRONTEND_URL || '');
    const isProduction = process.env.NODE_ENV === 'production';
    const frontendUrl = isProduction
        ? configuredFrontendUrl
        : (configuredFrontendUrl || resolveFrontendUrlFromRequest(req) || 'http://localhost:8080');
    if (isProduction && !configuredFrontendUrl) {
        return res.status(500).json({ success: false, message: 'URL do frontend não configurada para produção. Defina FRONTEND_URL no backend.' });
    }
    const result = await mpCreateSubscription({
        plan: safePlan, payerEmail, frontendUrl, externalReference: req.user?.id || 'anonymous'
    });
    if (!result.ok) {
        console.error('Mercado Pago checkout error:', result.error);
        return res.status(502).json({ success: false, message: 'Não foi possível iniciar o pagamento no Mercado Pago.' });
    }
    return res.json({ success: true, message: 'Checkout criado com sucesso.', data: result.data });
};

/**
 * Assinatura a partir de um cartão JÁ tokenizado pelo app nativo.
 *
 * @route POST /api/payments/subscribe
 *
 * O telemóvel troca os dados do cartão por um `card_token_id` diretamente com o
 * Mercado Pago (chave pública) e envia apenas o token. Nunca aceites aqui número
 * de cartão, CVV ou validade — se algum aparecer no corpo, o pedido é recusado,
 * para que um cliente mal escrito não arraste este servidor para o âmbito PCI.
 */
export const subscribeWithCard = async (req, res) => {
    if (!isMercadoPago()) {
        return res.status(400).json({
            success: false,
            message: 'Assinatura no app disponível apenas com o gateway Mercado Pago.'
        });
    }
    if (!isMercadoPagoConfigured()) {
        return res.status(500).json({
            success: false,
            message: 'Gateway Mercado Pago não configurado. Defina MERCADOPAGO_ACCESS_TOKEN no backend.'
        });
    }

    const body = req.body || {};
    const forbidden = ['card_number', 'cardNumber', 'security_code', 'securityCode', 'cvv', 'expiration_month', 'expirationMonth'];
    if (forbidden.some((field) => field in body)) {
        return res.status(400).json({
            success: false,
            message: 'Envie apenas o token do cartão. Dados de cartão não são aceites neste endpoint.'
        });
    }

    const { plan = 'monthly', cardTokenId = '', payerEmail = '' } = body;
    const token = sanitizeString(cardTokenId, 128);
    if (!token) {
        return res.status(400).json({ success: false, message: 'Token do cartão é obrigatório.' });
    }

    const email = sanitizeString(payerEmail || req.user?.email || '', 255).toLowerCase();
    if (!email) {
        return res.status(400).json({ success: false, message: 'E-mail do pagador é obrigatório.' });
    }

    const result = await mpCreateSubscriptionWithCardToken({
        plan: sanitizePlan(plan),
        payerEmail: email,
        cardTokenId: token,
        externalReference: req.user?.id || 'anonymous'
    });

    if (!result.ok) {
        console.error('Mercado Pago subscribe error:', result.error);

        // "Card token service not found" é o 404 que o Mercado Pago devolve
        // quando a conta NÃO tem assinatura-com-cartão (sem redirect) libertada.
        // Verificado: o mesmo token é aprovado em /v1/payments, portanto o token
        // é válido e o que falta é a permissão do produto na conta. Sem esta
        // tradução o utilizador via uma mensagem interna que não lhe diz nada.
        const missingCapability = /card token service not found/i.test(result.error || '');
        if (missingCapability) {
            return res.status(501).json({
                success: false,
                message: 'Assinatura pelo app ainda não está liberada nesta conta do Mercado Pago. '
                    + 'Peça a liberação de "assinaturas com cartão sem redirecionamento" ao suporte do Mercado Pago.'
            });
        }

        return res.status(402).json({ success: false, message: result.error });
    }

    // O webhook confirma mais tarde, mas uma assinatura que nasce autorizada já
    // pode libertar o Premium — senão o utilizador paga e continua a ver o
    // ecrã de venda até o Mercado Pago chamar de volta.
    if (req.user && mpIsAccessActive(result.data.subscriptionStatus)) {
        await req.user
            .update({
                subscriptionStatus: result.data.subscriptionStatus,
                subscriptionId: result.data.sessionId
            })
            .catch(() => {});
    }

    return res.json({
        success: true,
        message: 'Assinatura criada com sucesso.',
        data: result.data
    });
};

const mpPlanFromReason = (reason = '') => (String(reason).toLowerCase().includes('anual') ? 'annual' : 'monthly');

const mercadoPagoStatus = async (req, res) => {
    const id = sanitizeString((req.body || {}).sessionId, 200);
    if (!id || id.length < 6) return res.status(400).json({ success: false, message: 'sessionId inválido.' });
    const r = await mpGetSubscription(id);
    if (!r.ok) return res.status(502).json({ success: false, message: 'Erro ao consultar assinatura no Mercado Pago.' });
    const sub = r.data || {};
    if (req.user?.id && sub.external_reference && String(sub.external_reference) !== String(req.user.id)) {
        return res.status(403).json({ success: false, message: 'Assinatura não pertence a este utilizador.' });
    }
    const plan = mpPlanFromReason(sub.reason);
    return res.json({
        success: true,
        data: {
            accessActive: mpIsAccessActive(sub.status),
            plan,
            amount: MP_PLAN_CONFIG[plan].amount,
            trialDays: MP_TRIAL_DAYS,
            subscriptionStatus: sub.status || undefined,
            sessionId: id
        }
    });
};

const mercadoPagoVerify = async (req, res) => {
    const id = sanitizeString((req.body || {}).sessionId, 200);
    if (!id || id.length < 6) return res.status(400).json({ success: false, message: 'sessionId inválido.' });
    const r = await mpGetSubscription(id);
    if (!r.ok) return res.status(502).json({ success: false, message: 'Erro ao verificar assinatura no Mercado Pago.' });
    const sub = r.data || {};
    if (req.user?.id && sub.external_reference && String(sub.external_reference) !== String(req.user.id)) {
        return res.status(403).json({ success: false, message: 'Assinatura não pertence a este utilizador.' });
    }
    if (!mpIsAccessActive(sub.status)) {
        return res.status(402).json({ success: false, message: 'Assinatura ainda não confirmada.' });
    }
    const plan = mpPlanFromReason(sub.reason);
    return res.json({
        success: true,
        message: 'Assinatura ativa.',
        data: { plan, amount: MP_PLAN_CONFIG[plan].amount, sessionId: id, trialDays: MP_TRIAL_DAYS, subscriptionStatus: sub.status }
    });
};

const mercadoPagoWebhook = async (req, res) => {
    try {
        let payload = {};
        try { payload = JSON.parse(req.body?.toString?.() || '{}'); } catch { payload = {}; }
        const type = payload.type || req.query.type;
        const dataId = payload.data?.id || req.query['data.id'];

        // 1) valida a assinatura (x-signature) — rejeita POSTs forjados.
        const sig = mpValidateSignature({
            xSignature: req.headers['x-signature'],
            xRequestId: req.headers['x-request-id'],
            dataId
        });
        if (!sig.ok) {
            console.warn('Mercado Pago webhook: assinatura inválida — rejeitado.');
            return res.status(401).json({ received: false });
        }

        // 2) evento de assinatura → consulta o preapproval e PERSISTE o Premium no banco.
        if (dataId && /preapproval|subscription/i.test(String(type))) {
            const r = await mpGetSubscription(dataId);
            if (r.ok) {
                const sub = r.data || {};
                const userId = sub.external_reference;
                if (userId && userId !== 'anonymous') {
                    await User.update(
                        { subscriptionStatus: sub.status || null, subscriptionId: sub.id || dataId },
                        { where: { id: userId } }
                    ).catch((e) => console.error('Webhook update user error:', e.message));
                }
                console.log(`✅ Mercado Pago webhook: preapproval=${dataId} status=${sub.status} user=${userId}`);
            }
        }
        return res.json({ received: true });
    } catch (error) {
        console.error('Mercado Pago webhook error:', error.message);
        return res.status(200).json({ received: true });
    }
};

export const createCheckoutSession = async (req, res) => {
    try {
        if (isMercadoPago()) return createMercadoPagoCheckout(req, res);
        const stripe = getStripeClient();

        if (!stripe) {
            return res.status(500).json({
                success: false,
                message: 'Gateway Stripe não configurado. Defina STRIPE_SECRET_KEY no backend.'
            });
        }

        const {
            plan = 'monthly',
            customerName = '',
            customerEmail = '',
            invoiceLegalName = '',
            invoiceDocument = '',
            invoiceEmail = '',
            invoicePhone = '',
            invoiceAddressLine1 = '',
            invoiceAddressNumber = '',
            invoiceNeighborhood = '',
            invoiceCity = '',
            invoiceState = '',
            invoiceZipCode = '',
            invoiceCountry = 'BR'
        } = req.body || {};

        if (containsSensitiveCardData(req.body || {})) {
            return res.status(400).json({
                success: false,
                message: 'Dados sensíveis de cartão não devem ser enviados ao MemorIA. Use apenas o checkout seguro da Stripe.'
            });
        }

        const safePlan = sanitizePlan(plan);
        const selectedPlan = PLAN_CONFIG[safePlan] || PLAN_CONFIG.monthly;
        const configuredFrontendUrl = sanitizeBaseUrl(process.env.FRONTEND_URL || '');
        const frontendUrlFromRequest = resolveFrontendUrlFromRequest(req);
        const isProduction = process.env.NODE_ENV === 'production';
        const frontendUrl = isProduction
            ? configuredFrontendUrl
            : (configuredFrontendUrl || frontendUrlFromRequest || 'http://localhost:8080');
        const isHttpsUrl = frontendUrl.startsWith('https://');

        if (isProduction && !configuredFrontendUrl) {
            return res.status(500).json({
                success: false,
                message: 'URL do frontend não configurada para produção. Defina FRONTEND_URL no backend.'
            });
        }

        if (isProduction && !isHttpsUrl && !isLocalHttpUrl(frontendUrl)) {
            return res.status(500).json({
                success: false,
                message: 'Configuração insegura de redirecionamento de pagamento. Use FRONTEND_URL com https://.'
            });
        }

        const safeName = sanitizeString(customerName, 120);
        const safeEmail = sanitizeString(customerEmail, 255).toLowerCase();
        const safeInvoiceLegalName = sanitizeString(invoiceLegalName, 120);
        const safeInvoiceDocument = onlyDigits(invoiceDocument);
        const safeInvoiceEmail = sanitizeString(invoiceEmail, 255).toLowerCase();
        const safeInvoicePhone = onlyDigits(invoicePhone);
        const safeInvoiceAddressLine1 = sanitizeString(invoiceAddressLine1, 120);
        const safeInvoiceAddressNumber = sanitizeString(invoiceAddressNumber, 20);
        const safeInvoiceNeighborhood = sanitizeString(invoiceNeighborhood, 80);
        const safeInvoiceCity = sanitizeString(invoiceCity, 80);
        const safeInvoiceState = sanitizeString(invoiceState, 2).toUpperCase();
        const safeInvoiceZipCode = onlyDigits(invoiceZipCode);
        const safeInvoiceCountry = sanitizeString(invoiceCountry || 'BR', 2).toUpperCase() || 'BR';
        const userId = req.user?.id || 'anonymous';

        const missingInvoiceFields = [];
        if (!safeInvoiceLegalName) missingInvoiceFields.push('invoiceLegalName');
        if (!(safeInvoiceDocument.length === 11 || safeInvoiceDocument.length === 14)) missingInvoiceFields.push('invoiceDocument');
        if (!safeInvoiceEmail) missingInvoiceFields.push('invoiceEmail');
        if (safeInvoicePhone.length < 10 || safeInvoicePhone.length > 15) missingInvoiceFields.push('invoicePhone');
        if (!safeInvoiceAddressLine1) missingInvoiceFields.push('invoiceAddressLine1');
        if (!safeInvoiceAddressNumber) missingInvoiceFields.push('invoiceAddressNumber');
        if (!safeInvoiceNeighborhood) missingInvoiceFields.push('invoiceNeighborhood');
        if (!safeInvoiceCity) missingInvoiceFields.push('invoiceCity');
        if (safeInvoiceState.length !== 2) missingInvoiceFields.push('invoiceState');
        if (safeInvoiceZipCode.length !== 8) missingInvoiceFields.push('invoiceZipCode');

        if (missingInvoiceFields.length > 0) {
            return res.status(400).json({
                success: false,
                message: 'Dados do pagador para nota fiscal são obrigatórios.',
                errors: missingInvoiceFields
            });
        }

        const stripeCustomer = await stripe.customers.create({
            name: safeInvoiceLegalName || safeName || undefined,
            email: safeInvoiceEmail || safeEmail || undefined,
            phone: safeInvoicePhone || undefined,
            address: {
                line1: [safeInvoiceAddressLine1, safeInvoiceAddressNumber].filter(Boolean).join(', '),
                line2: safeInvoiceNeighborhood || undefined,
                city: safeInvoiceCity || undefined,
                state: safeInvoiceState || undefined,
                postal_code: safeInvoiceZipCode || undefined,
                country: safeInvoiceCountry || 'BR'
            },
            metadata: {
                userId,
                invoiceDocument: safeInvoiceDocument,
                invoiceLegalName: safeInvoiceLegalName,
                invoiceAddressLine1: safeInvoiceAddressLine1,
                invoiceAddressNumber: safeInvoiceAddressNumber,
                invoiceNeighborhood: safeInvoiceNeighborhood,
                invoiceCity: safeInvoiceCity,
                invoiceState: safeInvoiceState,
                invoiceZipCode: safeInvoiceZipCode,
                invoiceCountry: safeInvoiceCountry
            }
        });

        const session = await stripe.checkout.sessions.create({
            mode: 'subscription',
            payment_method_types: ['card'],
            payment_method_collection: 'always',
            locale: 'pt-BR',
            customer: stripeCustomer.id,
            line_items: [
                {
                    quantity: 1,
                    price_data: {
                        currency: 'brl',
                        unit_amount: selectedPlan.amountInCents,
                        recurring: {
                            interval: selectedPlan.interval
                        },
                        product_data: {
                            name: `MemorIA Premium ${selectedPlan.label}`,
                            description: `Assinatura ${selectedPlan.displayPrice}`
                        }
                    }
                }
            ],
            metadata: {
                plan: safePlan,
                userId,
                customerName: safeName || undefined,
                invoiceLegalName: safeInvoiceLegalName,
                invoiceDocument: safeInvoiceDocument,
                invoiceEmail: safeInvoiceEmail,
                invoicePhone: safeInvoicePhone,
                invoiceAddressLine1: safeInvoiceAddressLine1,
                invoiceAddressNumber: safeInvoiceAddressNumber,
                invoiceNeighborhood: safeInvoiceNeighborhood,
                invoiceCity: safeInvoiceCity,
                invoiceState: safeInvoiceState,
                invoiceZipCode: safeInvoiceZipCode,
                invoiceCountry: safeInvoiceCountry
            },
            subscription_data: {
                trial_period_days: TRIAL_PERIOD_DAYS,
                metadata: {
                    plan: safePlan,
                    userId,
                    invoiceDocument: safeInvoiceDocument
                }
            },
            success_url: `${frontendUrl}/?payment=success&plan=${safePlan}&session_id={CHECKOUT_SESSION_ID}`,
            cancel_url: `${frontendUrl}/?payment=cancelled&plan=${safePlan}`
        });

        return res.json({
            success: true,
            message: 'Checkout criado com sucesso.',
            data: {
                sessionId: session.id,
                url: session.url,
                plan: safePlan,
                trialDays: TRIAL_PERIOD_DAYS,
                amount: selectedPlan.amountInCents / 100
            }
        });
    } catch (error) {
        console.error('Stripe checkout error:', {
            message: error?.message,
            code: error?.code,
            type: error?.type
        });
        return res.status(500).json({
            success: false,
            message: 'Não foi possível iniciar o pagamento online.'
        });
    }
};

export const getPaymentConfig = async (req, res) => {
    if (isMercadoPago()) {
        return res.json({
            success: true,
            data: {
                gateway: 'mercadopago',
                configured: isMercadoPagoConfigured(),
                // A chave PÚBLICA é para ser publicada: é com ela que o app
                // nativo troca o cartão por um token contra a API do Mercado
                // Pago, sem que o número passe por este servidor.
                publicKey: mpGetPublicKey(),
                plans: { monthly: MP_PLAN_CONFIG.monthly, annual: MP_PLAN_CONFIG.annual }
            }
        });
    }
    res.json({
        success: true,
        data: {
            gateway: 'stripe',
            configured: !!process.env.STRIPE_SECRET_KEY,
            plans: {
                monthly: PLAN_CONFIG.monthly,
                annual: PLAN_CONFIG.annual
            }
        }
    });
};

export const verifySession = async (req, res) => {
    try {
        if (isMercadoPago()) return mercadoPagoVerify(req, res);
        const stripe = getStripeClient();
        if (!stripe) {
            return res.status(500).json({ success: false, message: 'Gateway n\u00e3o configurado.' });
        }

        const { sessionId } = req.body || {};
        const safeSessionId = sanitizeString(sessionId, 200);
        if (!safeSessionId || safeSessionId.length < 10) {
            return res.status(400).json({ success: false, message: 'sessionId inv\u00e1lido.' });
        }

        const session = await stripe.checkout.sessions.retrieve(safeSessionId);

        const plan = session.metadata?.plan || 'monthly';
        const selectedPlan = PLAN_CONFIG[plan] || PLAN_CONFIG.monthly;
        let subscriptionStatus = '';
        let trialEndsAt = null;

        if (session.subscription) {
            const subscriptionId = typeof session.subscription === 'string'
                ? session.subscription
                : session.subscription.id;

            if (subscriptionId) {
                const subscription = await stripe.subscriptions.retrieve(subscriptionId);
                subscriptionStatus = subscription.status || '';

                if (subscription.trial_end) {
                    trialEndsAt = new Date(subscription.trial_end * 1000).toISOString();
                }
            }
        }

        const accessGranted =
            session.payment_status === 'paid' ||
            subscriptionStatus === 'trialing' ||
            subscriptionStatus === 'active';

        if (!accessGranted) {
            return res.status(402).json({
                success: false,
                message: 'Assinatura ainda não confirmada.'
            });
        }

        return res.json({
            success: true,
            message: trialEndsAt ? 'Assinatura iniciada com 7 dias grátis.' : 'Pagamento confirmado.',
            data: {
                plan,
                amount: selectedPlan.amountInCents / 100,
                customerEmail: session.customer_email || session.customer_details?.email || '',
                sessionId: session.id,
                trialDays: TRIAL_PERIOD_DAYS,
                trialEndsAt,
                subscriptionStatus: subscriptionStatus || undefined
            }
        });
    } catch (error) {
        console.error('Stripe verifySession error:', { message: error?.message, code: error?.code });
        return res.status(500).json({ success: false, message: 'Erro ao verificar sess\u00e3o de pagamento.' });
    }
};

export const getSubscriptionStatus = async (req, res) => {
    try {
        if (isMercadoPago()) return mercadoPagoStatus(req, res);
        const stripe = getStripeClient();
        if (!stripe) {
            return res.status(500).json({ success: false, message: 'Gateway não configurado.' });
        }

        const { sessionId } = req.body || {};
        const safeSessionId = sanitizeString(sessionId, 200);
        if (!safeSessionId || safeSessionId.length < 10) {
            return res.status(400).json({ success: false, message: 'sessionId inválido.' });
        }

        const session = await stripe.checkout.sessions.retrieve(safeSessionId);
        const plan = session.metadata?.plan || 'monthly';
        const selectedPlan = PLAN_CONFIG[plan] || PLAN_CONFIG.monthly;

        let subscriptionStatus = '';
        let trialEndsAt = null;
        let trialStartsAt = null;

        if (session.subscription) {
            const subscriptionId = typeof session.subscription === 'string'
                ? session.subscription
                : session.subscription.id;

            if (subscriptionId) {
                const subscription = await stripe.subscriptions.retrieve(subscriptionId);
                subscriptionStatus = subscription.status || '';

                if (subscription.trial_end) {
                    trialEndsAt = new Date(subscription.trial_end * 1000).toISOString();
                }

                if (subscription.trial_start) {
                    trialStartsAt = new Date(subscription.trial_start * 1000).toISOString();
                }
            }
        }

        const accessActive =
            session.payment_status === 'paid' ||
            subscriptionStatus === 'trialing' ||
            subscriptionStatus === 'active';

        return res.json({
            success: true,
            data: {
                accessActive,
                plan,
                amount: selectedPlan.amountInCents / 100,
                trialDays: TRIAL_PERIOD_DAYS,
                trialStartsAt,
                trialEndsAt,
                subscriptionStatus: subscriptionStatus || undefined,
                sessionId: session.id
            }
        });
    } catch (error) {
        console.error('Stripe getSubscriptionStatus error:', { message: error?.message, code: error?.code });
        return res.status(500).json({ success: false, message: 'Erro ao consultar status da assinatura.' });
    }
};

export const cancelSubscription = async (req, res) => {
    try {
        if (!isMercadoPago()) {
            return res.status(400).json({ success: false, message: 'Cancelamento disponível apenas para Mercado Pago neste momento.' });
        }
        const id = sanitizeString((req.body || {}).sessionId || req.user?.subscriptionId || '', 200);
        if (!id) return res.status(400).json({ success: false, message: 'Assinatura não encontrada.' });
        const r = await mpCancelSubscription(id);
        if (!r.ok) return res.status(502).json({ success: false, message: 'Não foi possível cancelar a assinatura no Mercado Pago.' });
        if (req.user) await req.user.update({ subscriptionStatus: 'cancelled' }).catch(() => {});
        return res.json({ success: true, message: 'Assinatura cancelada.' });
    } catch (error) {
        console.error('cancelSubscription error:', error.message);
        return res.status(500).json({ success: false, message: 'Erro ao cancelar assinatura.' });
    }
};

export const stripeWebhook = async (req, res) => {
    if (isMercadoPago()) return mercadoPagoWebhook(req, res);
    const stripe = getStripeClient();
    if (!stripe) {
        return res.status(500).json({ success: false, message: 'Gateway n\u00e3o configurado.' });
    }

    const sig = req.headers['stripe-signature'];
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
    const isProduction = process.env.NODE_ENV === 'production';

    if (isProduction && !webhookSecret) {
        return res.status(500).json({
            success: false,
            message: 'Webhook Stripe não configurado para produção.'
        });
    }

    let event;
    try {
        if (webhookSecret) {
            event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
        } else {
            // Sem secret configurado: aceita em dev mas loga aviso
            console.warn('\u26a0 STRIPE_WEBHOOK_SECRET n\u00e3o definido. Webhook n\u00e3o verificado.');
            event = JSON.parse(req.body.toString());
        }
    } catch (err) {
        console.error('Webhook signature error:', err.message);
        return res.status(400).json({ success: false, message: 'Assinatura de webhook inv\u00e1lida.' });
    }

    if (event.type === 'checkout.session.completed') {
        const session = event.data.object;
        const plan = session.metadata?.plan || 'monthly';
        const userId = session.metadata?.userId;

        console.log(`\u2705 Checkout concluído via webhook: user=${userId}, plan=${plan}, session=${session.id}`);
        // Aqui: atualizar o usu\u00e1rio no banco com premium ativo se necess\u00e1rio
    }

    return res.json({ received: true });
};
