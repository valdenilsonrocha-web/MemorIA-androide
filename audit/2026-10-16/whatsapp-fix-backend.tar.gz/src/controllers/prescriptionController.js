import { Prescription } from '../models/index.js';

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

const getImageDataBytes = (dataUrl = '') => {
    const base64Part = String(dataUrl).split(',')[1] || '';
    return Buffer.byteLength(base64Part, 'base64');
};

export const getPrescriptions = async (req, res) => {
    try {
        const prescriptions = await Prescription.findAll({
            where: { userId: req.user.id },
            order: [['capturedAt', 'DESC']]
        });

        return res.json({
            success: true,
            count: prescriptions.length,
            data: { prescriptions }
        });
    } catch (error) {
        console.error('Get prescriptions error:', error);
        return res.status(500).json({
            success: false,
            message: 'Erro ao buscar receitas.',
            error: error.message
        });
    }
};

export const createPrescription = async (req, res) => {
    try {
        const { fileName, imageData, capturedAt, ocrText } = req.body || {};

        if (!imageData || typeof imageData !== 'string' || !imageData.startsWith('data:image/')) {
            return res.status(400).json({
                success: false,
                message: 'Imagem de receita inválida.'
            });
        }

        const bytes = getImageDataBytes(imageData);
        if (bytes > MAX_IMAGE_BYTES) {
            return res.status(400).json({
                success: false,
                message: 'A imagem deve ter no máximo 5MB.'
            });
        }

        const prescription = await Prescription.create({
            userId: req.user.id,
            fileName: fileName || 'receita.jpg',
            imageData,
            ocrText: String(ocrText || '').trim().slice(0, 8000) || null,
            capturedAt: capturedAt ? new Date(capturedAt) : new Date()
        });

        return res.status(201).json({
            success: true,
            message: 'Receita salva com sucesso.',
            data: { prescription }
        });
    } catch (error) {
        console.error('Create prescription error:', error);
        return res.status(500).json({
            success: false,
            message: 'Erro ao salvar receita.',
            error: error.message
        });
    }
};

export const deletePrescription = async (req, res) => {
    try {
        const { id } = req.params;

        const prescription = await Prescription.findOne({
            where: {
                id,
                userId: req.user.id
            }
        });

        if (!prescription) {
            return res.status(404).json({
                success: false,
                message: 'Receita não encontrada.'
            });
        }

        await prescription.destroy();

        return res.json({
            success: true,
            message: 'Receita removida com sucesso.'
        });
    } catch (error) {
        console.error('Delete prescription error:', error);
        return res.status(500).json({
            success: false,
            message: 'Erro ao remover receita.',
            error: error.message
        });
    }
};
