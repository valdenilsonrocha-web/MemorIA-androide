import { MedicationHistory } from '../models/index.js';
import { Op } from 'sequelize';

const sanitizeString = (value, max = 255) => String(value || '').trim().slice(0, max);
const sanitizeOptionalDate = (value) => {
    if (!value) return null;
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? null : date;
};

const clampInt = (value, min, max, fallback) => {
    const parsed = Number.parseInt(value, 10);
    if (!Number.isFinite(parsed)) return fallback;
    return Math.min(max, Math.max(min, parsed));
};

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * `medication_id` é UUID NOT NULL com chave estrangeira. Um id ausente virava
 * string vazia no `sanitizeString` e só rebentava no Postgres, devolvendo 500
 * com o erro cru do banco ("invalid input syntax for type uuid") — que é um
 * pedido inválido do cliente, não uma falha do servidor. Validamos antes.
 */
const validateHistoryPayload = (payload = {}) => {
    const id = sanitizeString(payload.medicationId, 64);
    if (!id) return 'medicationId é obrigatório.';
    if (!UUID_RE.test(id)) return 'medicationId inválido.';
    if (!sanitizeString(payload.medicationName, 255)) return 'medicationName é obrigatório.';
    return null;
};

const pickHistoryPayload = (payload = {}) => {
    const safeStatus = ['taken', 'missed', 'snoozed'].includes(payload.status) ? payload.status : 'missed';
    const scheduledFor = sanitizeOptionalDate(payload.scheduledFor || payload.timestamp) || new Date();

    return {
        medicationId: sanitizeString(payload.medicationId, 64),
        medicationName: sanitizeString(payload.medicationName, 255),
        dosage: sanitizeString(payload.dosage, 100),
        scheduleTime: sanitizeString(payload.scheduleTime, 5),
        status: safeStatus,
        scheduledFor,
        takenAt: safeStatus === 'taken' ? (sanitizeOptionalDate(payload.takenAt || payload.timestamp) || new Date()) : null,
        notes: payload.notes == null ? null : sanitizeString(payload.notes, 2000)
    };
};

// @desc    Get medication history for user
// @route   GET /api/history
// @access  Private
export const getHistory = async (req, res) => {
    try {
        const { startDate, endDate, status, medicationId } = req.query;
        const limit = clampInt(req.query.limit, 1, 500, 100);

        const where = { userId: req.user.id };

        if (startDate || endDate) {
            where.scheduledFor = {};
            const start = sanitizeOptionalDate(startDate);
            const end = sanitizeOptionalDate(endDate);
            if (start) where.scheduledFor[Op.gte] = start;
            if (end) where.scheduledFor[Op.lte] = end;
            if (Object.keys(where.scheduledFor).length === 0) {
                delete where.scheduledFor;
            }
        }

        if (['taken', 'missed', 'snoozed'].includes(status)) {
            where.status = status;
        }

        if (medicationId) {
            where.medicationId = sanitizeString(medicationId, 64);
        }

        const history = await MedicationHistory.findAll({
            where,
            order: [['scheduledFor', 'DESC']],
            limit
        });

        res.json({
            success: true,
            count: history.length,
            data: { history }
        });
    } catch (error) {
        console.error('Get history error:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao buscar histórico.',
            error: error.message
        });
    }
};

// @desc    Add history entry
// @route   POST /api/history
// @access  Private
export const addHistoryEntry = async (req, res) => {
    try {
        const invalid = validateHistoryPayload(req.body || {});
        if (invalid) {
            return res.status(400).json({ success: false, message: invalid });
        }

        const safePayload = pickHistoryPayload(req.body || {});
        const historyData = {
            ...safePayload,
            userId: req.user.id
        };

        const entry = await MedicationHistory.create(historyData);

        res.status(201).json({
            success: true,
            message: 'Entrada de histórico registrada com sucesso.',
            data: { entry }
        });
    } catch (error) {
        console.error('Add history error:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao registrar histórico.',
            error: error.message
        });
    }
};

// @desc    Sync history from local storage
// @route   POST /api/history/sync
// @access  Private
export const syncHistory = async (req, res) => {
    try {
        const { history: localHistory } = req.body;

        if (!Array.isArray(localHistory)) {
            return res.status(400).json({
                success: false,
                message: 'Dados inválidos.'
            });
        }

        const syncedEntries = [];
        let skipped = 0;

        for (const localEntry of localHistory) {
            // Uma entrada inválida não pode abortar o lote: este endpoint recebe
            // o histórico acumulado offline, portanto rejeitar tudo por causa de
            // um registo perderia as restantes dezenas. Salta-se e reporta-se.
            if (validateHistoryPayload(localEntry || {})) {
                skipped += 1;
                continue;
            }

            const safeEntry = pickHistoryPayload(localEntry);

            // Check if entry already exists
            const existing = await MedicationHistory.findOne({
                where: {
                    userId: req.user.id,
                    medicationName: safeEntry.medicationName,
                    scheduleTime: safeEntry.scheduleTime,
                    status: safeEntry.status,
                    scheduledFor: safeEntry.scheduledFor
                }
            });

            if (!existing) {
                const entry = await MedicationHistory.create({
                    userId: req.user.id,
                    medicationId: safeEntry.medicationId,
                    medicationName: safeEntry.medicationName,
                    dosage: safeEntry.dosage,
                    scheduleTime: safeEntry.scheduleTime,
                    status: safeEntry.status,
                    scheduledFor: safeEntry.scheduledFor,
                    takenAt: safeEntry.takenAt,
                    notes: safeEntry.notes
                });
                syncedEntries.push(entry);
            }
        }

        // Update user's last sync time
        await req.user.update({ lastSync: new Date() });

        res.json({
            success: true,
            message: skipped
                ? `${syncedEntries.length} entradas sincronizadas; ${skipped} ignoradas por serem inválidas.`
                : `${syncedEntries.length} entradas de histórico sincronizadas com sucesso.`,
            data: {
                syncedCount: syncedEntries.length,
                skippedCount: skipped,
                syncedAt: new Date()
            }
        });
    } catch (error) {
        console.error('Sync history error:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao sincronizar histórico.',
            error: error.message
        });
    }
};

// @desc    Get adherence statistics
// @route   GET /api/history/adherence
// @access  Private
export const getAdherence = async (req, res) => {
    try {
        const days = clampInt(req.query.days, 1, 365, 30);
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - days);

        const history = await MedicationHistory.findAll({
            where: {
                userId: req.user.id,
                scheduledFor: {
                    [Op.gte]: startDate
                }
            }
        });

        const total = history.length;
        const taken = history.filter(h => h.status === 'taken').length;
        const missed = history.filter(h => h.status === 'missed').length;
        const adherenceRate = total > 0 ? Math.round((taken / total) * 100) : 0;

        res.json({
            success: true,
            data: {
                period: `${days} dias`,
                total,
                taken,
                missed,
                adherenceRate: `${adherenceRate}%`
            }
        });
    } catch (error) {
        console.error('Get adherence error:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao calcular adesão.',
            error: error.message
        });
    }
};
