import { User, Medication, MedicationHistory, Prescription } from '../models/index.js';
import crypto from 'crypto';
import { hasGooglePlayAccess } from '../services/googlePlay.js';
import { generateToken, userIsPremium, getUserTrialInfo, FREE_HAS_ALL_FEATURES } from '../middleware/auth.js';
import { sendPasswordResetEmail, sendWelcomeEmail } from '../services/emailService.js';

const maskCpf = (cpf = '') => {
    const clean = String(cpf || '').replace(/\D/g, '');
    if (clean.length !== 11) return '';
    return `${clean.slice(0, 3)}***${clean.slice(6, 9)}**`;
};

const hashResetToken = (token = '') => {
    return crypto.createHash('sha256').update(String(token)).digest('hex');
};
const VALID_GLUCOSE_CONTEXTS = new Set(['fasting', 'postmeal', 'random']);

const isValidEmailAddress = (value = '') => {
    const normalized = String(value || '').trim().toLowerCase();
    const at = normalized.indexOf('@');
    if (at <= 0 || at !== normalized.lastIndexOf('@')) return false;
    const domain = normalized.slice(at + 1);
    return (
        !normalized.includes(' ') &&
        domain.includes('.') &&
        !domain.startsWith('.') &&
        !domain.endsWith('.')
    );
};

const sanitizeUserOutput = (user) => {
    const payload = user.toJSON();
    const trialInfo = getUserTrialInfo(user);
    return {
        id: payload.id,
        name: payload.name,
        email: payload.email || '',
        phone: payload.phone || '',
        cpfMasked: maskCpf(payload.cpf),
        city: payload.city || '',
        state: payload.state || '',
        healthUnit: payload.healthUnit || '',
        isActive: !!payload.isActive,
        isAdmin: !!payload.isAdmin,
        caregivers: Array.isArray(payload.caregivers) ? payload.caregivers : [],
        subscriptionStatus: hasGooglePlayAccess(user.googlePlaySubscription) ? 'active' : (payload.subscriptionStatus || null),
        subscriptionProvider: hasGooglePlayAccess(user.googlePlaySubscription) ? 'googleplay' : null,
        subscriptionPlan: user.googlePlaySubscription?.plan || null,
        subscriptionExpiresAt: user.googlePlaySubscription?.expiryTime || null,
        isPremium: FREE_HAS_ALL_FEATURES || trialInfo.isPremium,
        isTrialActive: trialInfo.isTrialActive,
        trialDaysRemaining: trialInfo.trialDaysRemaining,
        trialExpired: FREE_HAS_ALL_FEATURES ? false : trialInfo.trialExpired,
        trialEndsAt: trialInfo.trialEndsAt,
        firstLoginAt: payload.firstLoginAt || payload.createdAt || null,
        reportSettings: {
            enabled: !!payload.reportAutoSendEnabled,
            frequency: payload.reportFrequency === 'monthly' ? 'monthly' : 'weekly',
            contactEmail: payload.reportContactEmail || payload.email || '',
            lastReportSentAt: payload.lastReportSentAt || null,
            lastReportPeriodKey: payload.lastReportPeriodKey || null,
            lastReportMeta: payload.reportLastMeta || null
        },
        consentDate: payload.consentDate || null,
        lastSync: payload.lastSync || null,
        createdAt: payload.createdAt,
        updatedAt: payload.updatedAt
    };
};

// @desc    Register new user
// @route   POST /api/auth/register
// @access  Public
export const register = async (req, res) => {
    try {
        const { cpf, name, password, email, phone, susCard, birthDate, gender, address, city, state, zipCode, healthUnit, lgpdConsent } = req.body;

        if (lgpdConsent !== true) {
            return res.status(400).json({
                success: false,
                message: 'É necessário aceitar a política de privacidade (LGPD) para criar a conta.'
            });
        }

        // Check if user already exists
        const existingUser = await User.findOne({ where: { cpf } });
        if (existingUser) {
            return res.status(400).json({
                success: false,
                message: 'CPF já cadastrado no sistema.'
            });
        }

        // Check email if provided
        if (email) {
            const existingEmail = await User.findOne({ where: { email } });
            if (existingEmail) {
                return res.status(400).json({
                    success: false,
                    message: 'Email já cadastrado no sistema.'
                });
            }
        }

        // Create user
        const user = await User.create({
            cpf,
            name,
            password,
            email,
            phone,
            susCard,
            birthDate,
            gender: gender || 'not_informed',
            address,
            city,
            state,
            zipCode,
            healthUnit,
            consentDate: new Date(), // LGPD consent
            firstLoginAt: new Date()
        });

        // Generate token
        const token = generateToken(user.id);

        // Envia e-mail de boas-vindas (falha silenciosa)
        if (process.env.RESEND_API_KEY && user.email) {
            sendWelcomeEmail({ to: user.email, name: user.name }).catch((e) =>
                console.error('Welcome email error:', e.message)
            );
        }

        res.status(201).json({
            success: true,
            message: 'Usuário cadastrado com sucesso.',
            data: {
                user: sanitizeUserOutput(user),
                token
            }
        });
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao cadastrar usuário.'
        });
    }
};

// @desc    Login user
// @route   POST /api/auth/login
// @access  Public
export const login = async (req, res) => {
    try {
        const { cpf, password } = req.body;

        // Validate input
        if (!cpf || !password) {
            return res.status(400).json({
                success: false,
                message: 'Por favor, forneça CPF e senha.'
            });
        }

        // Find user
        const user = await User.findOne({ where: { cpf } });

        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'CPF ou senha inválidos.'
            });
        }

        // Check if user is active
        if (!user.isActive) {
            return res.status(401).json({
                success: false,
                message: 'Conta desativada. Entre em contato com o suporte.'
            });
        }

        // Check password
        const isPasswordValid = await user.comparePassword(password);

        if (!isPasswordValid) {
            return res.status(401).json({
                success: false,
                message: 'CPF ou senha inválidos.'
            });
        }

        // Update last sync and initialize firstLoginAt for 15-day trial if not set
        const updates = { lastSync: new Date() };
        if (!user.firstLoginAt) {
            updates.firstLoginAt = new Date();
            user.firstLoginAt = updates.firstLoginAt;
        }
        await user.update(updates);

        // Generate token
        const token = generateToken(user.id);

        res.json({
            success: true,
            message: 'Login realizado com sucesso.',
            data: {
                user: sanitizeUserOutput(user),
                token
            }
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao realizar login.'
        });
    }
};

// @desc    Get current user
// @route   GET /api/auth/me
// @access  Private
export const getMe = async (req, res) => {
    try {
        res.json({
            success: true,
            data: {
                user: sanitizeUserOutput(req.user)
            }
        });
    } catch (error) {
        console.error('GetMe error:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao buscar dados do usuário.'
        });
    }
};

// Sanitiza a lista de cuidadores/responsáveis (alerta de dose perdida).
// maxCount limita por plano (gating server-side): free = 1, premium = 3.
const sanitizeCaregivers = (value, maxCount = 1) => {
    if (!Array.isArray(value)) return [];
    return value
        .map((c) => ({
            name: String(c?.name || '').trim().slice(0, 120),
            phone: String(c?.phone || '').replace(/\D/g, '').slice(0, 15),
            relation: String(c?.relation || '').trim().slice(0, 40),
        }))
        .filter((c) => c.phone.length >= 10)
        .slice(0, Math.max(1, maxCount));
};

const sanitizeReportContactEmail = (value) => {
    const raw = String(value ?? '').trim().toLowerCase();
    if (!raw) return null;
    if (!isValidEmailAddress(raw)) return null;
    return raw;
};

const sanitizeMedicalConsultations = (value) => {
    if (!Array.isArray(value)) return [];
    return value
        .map((item) => {
            const dateTime = new Date(String(item?.dateTime || ''));
            if (Number.isNaN(dateTime.getTime())) return null;
            return {
                id: String(item?.id || `consultation-${dateTime.getTime()}`).slice(0, 80),
                dateTime: dateTime.toISOString(),
                professional: String(item?.professional || '').trim().slice(0, 255),
                location: String(item?.location || '').trim().slice(0, 255),
                notes: String(item?.notes || '').trim().slice(0, 1000),
                updatedAt: item?.updatedAt ? new Date(item.updatedAt).toISOString() : new Date().toISOString(),
                createdAt: item?.createdAt ? new Date(item.createdAt).toISOString() : new Date().toISOString()
            };
        })
        .filter((item) => item && item.professional)
        .slice(0, 100);
};

const sanitizeHealthVitalSigns = (value) => {
    if (!Array.isArray(value)) return [];
    return value
        .map((item) => {
            const date = new Date(String(item?.date || item?.createdAt || ''));
            if (Number.isNaN(date.getTime())) return null;
            const parseNumber = (val, min, max) => {
                if (val === null || val === undefined || val === '') return null;
                const num = Number(val);
                if (!Number.isFinite(num)) return null;
                return Math.min(max, Math.max(min, num));
            };
            return {
                date: date.toISOString(),
                systolic: parseNumber(item?.systolic, 60, 260),
                diastolic: parseNumber(item?.diastolic, 40, 160),
                heartRate: parseNumber(item?.heartRate, 30, 260),
                spo2: parseNumber(item?.spo2, 50, 100),
                glucose: parseNumber(item?.glucose, 20, 800),
                glucoseContext: VALID_GLUCOSE_CONTEXTS.has(item?.glucoseContext) ? item.glucoseContext : 'random',
                hba1c: parseNumber(item?.hba1c, 2, 25),
                temperature: parseNumber(item?.temperature, 30, 45)
            };
        })
        .filter(Boolean)
        .sort((a, b) => new Date(b.date) - new Date(a.date))
        .slice(0, 5000);
};

// @desc    Update user profile
// @route   PUT /api/auth/profile
// @access  Private
export const updateProfile = async (req, res) => {
    try {
        const {
            name,
            email,
            phone,
            address,
            city,
            state,
            zipCode,
            caregivers,
            reportAutoSendEnabled,
            reportFrequency,
            reportContactEmail,
            medicalConsultations,
            healthVitalSigns
        } = req.body;

        const updateData = {};
        if (name) updateData.name = name;
        if (email) updateData.email = email;
        if (phone) updateData.phone = phone;
        if (address) updateData.address = address;
        if (city) updateData.city = city;
        if (state) updateData.state = state;
        if (zipCode) updateData.zipCode = zipCode;
        if (caregivers !== undefined) {
            // Limite por plano (gating no servidor): Premium até 3, gratuito 1.
            const maxCaregivers = userIsPremium(req.user) ? 3 : 1;
            updateData.caregivers = sanitizeCaregivers(caregivers, maxCaregivers);
        }
        if (typeof reportAutoSendEnabled === 'boolean') {
            updateData.reportAutoSendEnabled = reportAutoSendEnabled;
        }
        if (reportFrequency !== undefined) {
            updateData.reportFrequency = reportFrequency === 'monthly' ? 'monthly' : 'weekly';
        }
        if (reportContactEmail !== undefined) {
            updateData.reportContactEmail = sanitizeReportContactEmail(reportContactEmail);
        }
        if (medicalConsultations !== undefined) {
            updateData.medicalConsultations = sanitizeMedicalConsultations(medicalConsultations);
        }
        if (healthVitalSigns !== undefined) {
            updateData.healthVitalSigns = sanitizeHealthVitalSigns(healthVitalSigns);
        }

        await req.user.update(updateData);

        res.json({
            success: true,
            message: 'Perfil atualizado com sucesso.',
            data: {
                user: sanitizeUserOutput(req.user)
            }
        });
    } catch (error) {
        console.error('Update profile error:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao atualizar perfil.'
        });
    }
};

// @desc    Exportar todos os dados do utilizador (LGPD — direito de acesso/portabilidade)
// @route   GET /api/auth/export-data
// @access  Private
export const exportMyData = async (req, res) => {
    try {
        const userId = req.user.id;
        const [medications, history, prescriptions] = await Promise.all([
            Medication.findAll({ where: { userId } }),
            MedicationHistory.findAll({ where: { userId } }),
            Prescription.findAll({ where: { userId } })
        ]);
        return res.json({
            success: true,
            data: {
                exportedAt: new Date().toISOString(),
                user: sanitizeUserOutput(req.user),
                medications,
                history,
                prescriptions
            }
        });
    } catch (error) {
        console.error('Export data error:', error);
        return res.status(500).json({ success: false, message: 'Erro ao exportar dados.' });
    }
};

// @desc    Eliminar conta e todos os dados (LGPD — direito ao apagamento)
// @route   DELETE /api/auth/account
// @access  Private
export const deleteMyAccount = async (req, res) => {
    try {
        const userId = req.user.id;
        await Promise.all([
            MedicationHistory.destroy({ where: { userId } }),
            Medication.destroy({ where: { userId } }),
            Prescription.destroy({ where: { userId } })
        ]);
        await req.user.destroy();
        return res.json({ success: true, message: 'Conta e dados eliminados com sucesso.' });
    } catch (error) {
        console.error('Delete account error:', error);
        return res.status(500).json({ success: false, message: 'Erro ao eliminar a conta.' });
    }
};

// @desc    Update LGPD consent
// @route   PUT /api/auth/consent
// @access  Private
export const updateConsent = async (req, res) => {
    try {
        const { consent } = req.body;

        if (typeof consent !== 'boolean') {
            return res.status(400).json({
                success: false,
                message: 'Valor de consentimento inválido.'
            });
        }

        await req.user.update({
            consentDate: consent ? new Date() : null
        });

        return res.json({
            success: true,
            message: consent
                ? 'Consentimento LGPD atualizado com sucesso.'
                : 'Consentimento LGPD revogado com sucesso.',
            data: {
                user: sanitizeUserOutput(req.user)
            }
        });
    } catch (error) {
        console.error('Update consent error:', error);
        return res.status(500).json({
            success: false,
            message: 'Erro ao atualizar consentimento LGPD.'
        });
    }
};

// @desc    Request password reset link
// @route   POST /api/auth/forgot-password
// @access  Public
export const forgotPassword = async (req, res) => {
    try {
        const { cpf, email } = req.body;

        const cleanCpf = String(cpf || '').replace(/\D/g, '');
        const cleanEmail = String(email || '').trim().toLowerCase();

        const user = await User.findOne({
            where: { cpf: cleanCpf }
        });

        // Resposta genérica para não revelar se CPF/e-mail existem (segurança)
        const genericResponse = {
            success: true,
            message: 'Se encontrarmos uma conta com esses dados, você receberá um e-mail com o link de recuperação em breve.'
        };

        if (!user || !user.email || user.email.toLowerCase() !== cleanEmail) {
            return res.json(genericResponse);
        }

        // Gera token temporário válido por 1 hora.
        // Apenas o hash é persistido no banco para reduzir impacto em caso de vazamento.
        const resetToken = crypto.randomBytes(32).toString('hex');
        const resetTokenHash = hashResetToken(resetToken);
        const resetExpires = new Date(Date.now() + 60 * 60 * 1000); // 1h

        await user.update({
            resetPasswordToken: resetTokenHash,
            resetPasswordExpires: resetExpires
        });

        // Envia e-mail via Resend
        if (process.env.RESEND_API_KEY) {
            try {
                await sendPasswordResetEmail({
                    to: cleanEmail,
                    name: user.name,
                    resetToken
                });
            } catch (emailErr) {
                console.error('Erro ao enviar e-mail de reset:', emailErr.message);
                // Não bloqueia a resposta — token já foi salvo
            }
        } else {
            // Sem chave Resend configurada — exibe link no console (desenvolvimento)
            const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:8080';
            console.log(`[DEV] Reset link para ${cleanEmail}: ${frontendUrl}/?resetToken=${resetToken}`);
        }

        return res.json(genericResponse);
    } catch (error) {
        console.error('Forgot password error:', error);
        return res.status(500).json({
            success: false,
            message: 'Erro ao processar recuperação de senha.'
        });
    }
};

// @desc    Reset password with token
// @route   POST /api/auth/reset-password
// @access  Public
export const resetPassword = async (req, res) => {
    try {
        const { token, newPassword } = req.body;

        if (!token || !newPassword) {
            return res.status(400).json({ success: false, message: 'Token e nova senha são obrigatórios.' });
        }

        const normalizedToken = String(token).trim();
        const tokenHash = hashResetToken(normalizedToken);

        let user = await User.findOne({
            where: {
                resetPasswordToken: tokenHash,
            }
        });

        // Compatibilidade temporaria com tokens emitidos antes do hardening.
        if (!user) {
            user = await User.findOne({
                where: {
                    resetPasswordToken: normalizedToken,
                }
            });
        }

        if (!user || !user.resetPasswordExpires || new Date() > new Date(user.resetPasswordExpires)) {
            return res.status(400).json({ success: false, message: 'Token inválido ou expirado.' });
        }

        await user.update({
            password: newPassword,
            resetPasswordToken: null,
            resetPasswordExpires: null
        });

        return res.json({ success: true, message: 'Senha redefinida com sucesso. Faça login com a nova senha.' });
    } catch (error) {
        console.error('Reset password error:', error);
        return res.status(500).json({ success: false, message: 'Erro ao redefinir senha.' });
    }
};
