import { User, Medication, MedicationHistory } from '../models/index.js';
import { Op } from 'sequelize';
import sequelize from '../config/database.js';

const sanitizeString = (value, max = 255) => String(value || '').trim().slice(0, max);
const sanitizeOptionalDate = (value) => {
    if (!value) return null;
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? null : parsed;
};
const clampInt = (value, min, max, fallback) => {
    const parsed = Number.parseInt(value, 10);
    if (!Number.isFinite(parsed)) return fallback;
    return Math.min(max, Math.max(min, parsed));
};

// @desc    Get aggregated statistics for public health monitoring
// @route   GET /api/admin/stats
// @access  Admin (requires admin role - to be implemented)
export const getPublicHealthStats = async (req, res) => {
    try {
        const { startDate, endDate } = req.query;
        const region = sanitizeString(req.query.region, 120);
        const healthUnit = sanitizeString(req.query.healthUnit, 120);
        const userWhere = { isActive: true };
        if (region) userWhere.state = region;
        if (healthUnit) userWhere.healthUnit = healthUnit;

        // Total active users
        const totalUsers = await User.count({
            where: userWhere
        });

        // Total medications prescribed
        const totalMedications = await Medication.count({
            where: { active: true }
        });

        // Build where clause for history
        const historyWhere = {};
        if (startDate || endDate) {
            historyWhere.scheduledFor = {};
            const start = sanitizeOptionalDate(startDate);
            const end = sanitizeOptionalDate(endDate);
            if (start) historyWhere.scheduledFor[Op.gte] = start;
            if (end) historyWhere.scheduledFor[Op.lte] = end;
            if (Object.keys(historyWhere.scheduledFor).length === 0) {
                delete historyWhere.scheduledFor;
            }
        }

        // Adherence rate
        const totalScheduled = await MedicationHistory.count({ where: historyWhere });
        const totalTaken = await MedicationHistory.count({
            where: {
                ...historyWhere,
                status: 'taken'
            }
        });
        const adherenceRate = totalScheduled > 0 ? ((totalTaken / totalScheduled) * 100).toFixed(2) : 0;

        // Most common medications
        const topMedications = await Medication.findAll({
            attributes: [
                'name',
                [sequelize.fn('COUNT', sequelize.col('name')), 'count']
            ],
            where: { active: true },
            group: ['name'],
            order: [[sequelize.literal('count'), 'DESC']],
            limit: 10,
            raw: true
        });

        // Regional distribution (if city/state available)
        const regionalDistribution = await User.findAll({
            attributes: [
                'state',
                [sequelize.fn('COUNT', sequelize.col('id')), 'count']
            ],
            where: {
                ...userWhere,
                state: { [Op.ne]: null }
            },
            group: ['state'],
            order: [[sequelize.literal('count'), 'DESC']],
            raw: true
        });

        // Health unit distribution
        const healthUnitDistribution = await User.findAll({
            attributes: [
                'healthUnit',
                [sequelize.fn('COUNT', sequelize.col('id')), 'count']
            ],
            where: {
                ...userWhere,
                healthUnit: { [Op.ne]: null }
            },
            group: ['healthUnit'],
            order: [[sequelize.literal('count'), 'DESC']],
            limit: 20,
            raw: true
        });

        res.json({
            success: true,
            data: {
                overview: {
                    totalUsers,
                    totalMedications,
                    totalScheduled,
                    totalTaken,
                    adherenceRate: `${adherenceRate}%`
                },
                topMedications,
                regionalDistribution,
                healthUnitDistribution,
                generatedAt: new Date()
            }
        });
    } catch (error) {
        console.error('Get public health stats error:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao buscar estatísticas.',
            error: error.message
        });
    }
};

// @desc    Get medication usage report
// @route   GET /api/admin/medications/report
// @access  Admin
export const getMedicationReport = async (req, res) => {
    try {
        const { startDate, endDate } = req.query;
        const medicationName = sanitizeString(req.query.medicationName, 120);

        const where = {};
        if (medicationName) {
            where.medicationName = {
                [Op.iLike]: `%${medicationName}%`
            };
        }

        if (startDate || endDate) {
            where.scheduledFor = {};
            const start = sanitizeOptionalDate(startDate);
            const end = sanitizeOptionalDate(endDate);
            if (start) where.scheduledFor[Op.gte] = start;
            if (end) where.scheduledFor[Op.lte] = end;
            if (Object.keys(where.scheduledFor).length === 0) {
                delete where.scheduledFor;
            }
        }

        const report = await MedicationHistory.findAll({
            attributes: [
                'medicationName',
                'status',
                [sequelize.fn('COUNT', sequelize.col('id')), 'count']
            ],
            where,
            group: ['medicationName', 'status'],
            order: [
                ['medicationName', 'ASC'],
                ['status', 'ASC']
            ],
            raw: true
        });

        // Format report
        const formattedReport = {};
        report.forEach(entry => {
            if (!formattedReport[entry.medicationName]) {
                formattedReport[entry.medicationName] = {
                    name: entry.medicationName,
                    taken: 0,
                    missed: 0,
                    total: 0
                };
            }

            const count = parseInt(entry.count);
            formattedReport[entry.medicationName].total += count;

            if (entry.status === 'taken') {
                formattedReport[entry.medicationName].taken = count;
            } else if (entry.status === 'missed') {
                formattedReport[entry.medicationName].missed = count;
            }
        });

        // Calculate adherence for each medication
        Object.keys(formattedReport).forEach(medName => {
            const med = formattedReport[medName];
            med.adherenceRate = med.total > 0 
                ? ((med.taken / med.total) * 100).toFixed(2) + '%'
                : '0%';
        });

        res.json({
            success: true,
            data: {
                medications: Object.values(formattedReport),
                generatedAt: new Date()
            }
        });
    } catch (error) {
        console.error('Get medication report error:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao gerar relatório.',
            error: error.message
        });
    }
};

// @desc    Get low adherence users (for intervention)
// @route   GET /api/admin/alerts/low-adherence
// @access  Admin
export const getLowAdherenceAlerts = async (req, res) => {
    try {
        const threshold = clampInt(req.query.threshold, 1, 100, 70);
        const days = clampInt(req.query.days, 1, 365, 30);
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - days);

        // Get all users with their adherence
        const users = await User.findAll({
            where: { isActive: true },
            include: [{
                model: MedicationHistory,
                as: 'history',
                where: {
                    scheduledFor: {
                        [Op.gte]: startDate
                    }
                },
                required: false
            }]
        });

        const lowAdherenceUsers = [];

        for (const user of users) {
            const total = user.history.length;
            if (total === 0) continue;

            const taken = user.history.filter(h => h.status === 'taken').length;
            const adherenceRate = (taken / total) * 100;

            if (adherenceRate < parseFloat(threshold)) {
                lowAdherenceUsers.push({
                    userId: user.id,
                    name: user.name,
                    cpf: user.cpf,
                    healthUnit: user.healthUnit,
                    city: user.city,
                    state: user.state,
                    adherenceRate: adherenceRate.toFixed(2) + '%',
                    totalScheduled: total,
                    totalTaken: taken,
                    totalMissed: total - taken
                });
            }
        }

        // Sort by adherence rate
        lowAdherenceUsers.sort((a, b) => 
            parseFloat(a.adherenceRate) - parseFloat(b.adherenceRate)
        );

        res.json({
            success: true,
            data: {
                threshold: `${threshold}%`,
                period: `${days} dias`,
                count: lowAdherenceUsers.length,
                users: lowAdherenceUsers,
                generatedAt: new Date()
            }
        });
    } catch (error) {
        console.error('Get low adherence alerts error:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao buscar alertas de baixa adesão.',
            error: error.message
        });
    }
};

// @desc    Export data for government reporting (anonymized)
// @route   GET /api/admin/export
// @access  Admin
export const exportAnonymizedData = async (req, res) => {
    try {
        const { startDate, endDate } = req.query;

        const where = {};
        if (startDate || endDate) {
            where.scheduledFor = {};
            const start = sanitizeOptionalDate(startDate);
            const end = sanitizeOptionalDate(endDate);
            if (start) where.scheduledFor[Op.gte] = start;
            if (end) where.scheduledFor[Op.lte] = end;
            if (Object.keys(where.scheduledFor).length === 0) {
                delete where.scheduledFor;
            }
        }

        const data = await MedicationHistory.findAll({
            attributes: [
                'medicationName',
                'dosage',
                'status',
                'scheduledFor',
                'takenAt'
            ],
            where,
            include: [{
                model: User,
                as: 'user',
                attributes: ['state', 'city', 'healthUnit', 'birthDate']
            }],
            order: [['scheduledFor', 'DESC']]
        });

        // Anonymize data - remove any identifying information
        const anonymizedData = data.map(entry => ({
            medicationName: entry.medicationName,
            dosage: entry.dosage,
            status: entry.status,
            scheduledFor: entry.scheduledFor,
            takenAt: entry.takenAt,
            state: entry.user?.state,
            city: entry.user?.city,
            healthUnit: entry.user?.healthUnit,
            ageGroup: entry.user?.birthDate 
                ? getAgeGroup(new Date(entry.user.birthDate))
                : 'unknown'
        }));

        res.json({
            success: true,
            data: {
                records: anonymizedData,
                count: anonymizedData.length,
                exportedAt: new Date(),
                note: 'Dados anonimizados em conformidade com LGPD'
            }
        });
    } catch (error) {
        console.error('Export data error:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao exportar dados.',
            error: error.message
        });
    }
};

// Helper function to calculate age group
function getAgeGroup(birthDate) {
    const today = new Date();
    const age = today.getFullYear() - birthDate.getFullYear();

    if (age < 18) return '0-17';
    if (age < 30) return '18-29';
    if (age < 45) return '30-44';
    if (age < 60) return '45-59';
    if (age < 75) return '60-74';
    return '75+';
}

// @desc    Owner dashboard — aggregated business metrics
// @route   GET /api/admin/owner-stats
// @access  Admin
export const getOwnerStats = async (req, res) => {
    try {
        const now = new Date();
        const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const startOfWeek = new Date(startOfToday);
        startOfWeek.setDate(startOfToday.getDate() - startOfToday.getDay());
        const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
        const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

        const [
            totalUsers,
            newToday,
            newThisWeek,
            newThisMonth,
            activeUsers,
            totalMedications,
            totalTaken,
            totalMissed,
            topMedications,
            recentSignups,
            byGender,
            byState,
            byCity,
            allUsersForAge,
            signupTrend
        ] = await Promise.all([
            User.count(),
            User.count({ where: { createdAt: { [Op.gte]: startOfToday } } }),
            User.count({ where: { createdAt: { [Op.gte]: startOfWeek } } }),
            User.count({ where: { createdAt: { [Op.gte]: startOfMonth } } }),
            User.count({ where: { lastSync: { [Op.gte]: sevenDaysAgo } } }),
            Medication.count({ where: { active: true } }),
            MedicationHistory.count({ where: { status: 'taken' } }),
            MedicationHistory.count({ where: { status: 'missed' } }),
            Medication.findAll({
                attributes: ['name', [sequelize.fn('COUNT', sequelize.col('id')), 'count']],
                where: { active: true },
                group: ['name'],
                order: [[sequelize.literal('count'), 'DESC']],
                limit: 10,
                raw: true
            }),
            User.findAll({
                attributes: ['id', 'name', 'email', 'city', 'state', 'gender', 'createdAt', 'lastSync'],
                order: [['createdAt', 'DESC']],
                limit: 15,
                raw: true
            }),
            // By gender
            User.findAll({
                attributes: ['gender', [sequelize.fn('COUNT', sequelize.col('id')), 'count']],
                group: ['gender'],
                raw: true
            }),
            // By state (top 10)
            User.findAll({
                attributes: ['state', [sequelize.fn('COUNT', sequelize.col('id')), 'count']],
                where: { state: { [Op.ne]: null } },
                group: ['state'],
                order: [[sequelize.literal('count'), 'DESC']],
                limit: 10,
                raw: true
            }),
            // By city (top 10)
            User.findAll({
                attributes: ['city', 'state', [sequelize.fn('COUNT', sequelize.col('id')), 'count']],
                where: { city: { [Op.ne]: null } },
                group: ['city', 'state'],
                order: [[sequelize.literal('count'), 'DESC']],
                limit: 10,
                raw: true
            }),
            // All users with birthDate for age group calculation
            User.findAll({
                attributes: ['birth_date'],
                where: { birthDate: { [Op.ne]: null } },
                raw: true
            }),
            // Signups last 30 days by day
            User.findAll({
                attributes: [
                    [sequelize.fn('DATE', sequelize.col('created_at')), 'date'],
                    [sequelize.fn('COUNT', sequelize.col('id')), 'count']
                ],
                where: { createdAt: { [Op.gte]: thirtyDaysAgo } },
                group: [sequelize.fn('DATE', sequelize.col('created_at'))],
                order: [[sequelize.fn('DATE', sequelize.col('created_at')), 'ASC']],
                raw: true
            })
        ]);

        // Age groups from birthDate
        const ageGroups = { '0-17': 0, '18-29': 0, '30-44': 0, '45-59': 0, '60-74': 0, '75+': 0 };
        allUsersForAge.forEach(u => {
            const bd = u.birth_date || u.birthDate;
            if (bd) {
                const group = getAgeGroup(new Date(bd));
                ageGroups[group] = (ageGroups[group] || 0) + 1;
            }
        });

        // Adherence rate
        const totalScheduled = totalTaken + totalMissed;
        const adherenceRate = totalScheduled > 0
            ? ((totalTaken / totalScheduled) * 100).toFixed(1)
            : null;

        res.json({
            success: true,
            data: {
                overview: {
                    totalUsers,
                    newToday,
                    newThisWeek,
                    newThisMonth,
                    activeUsers,
                    totalMedications,
                    totalTaken,
                    totalMissed,
                    adherenceRate
                },
                byGender,
                byState,
                byCity,
                byAge: Object.entries(ageGroups).map(([group, count]) => ({ group, count })),
                topMedications,
                signupTrend,
                recentSignups: recentSignups.map(u => ({
                    id: u.id,
                    name: u.name,
                    email: u.email || '',
                    city: u.city || '',
                    state: u.state || '',
                    gender: u.gender || 'not_informed',
                    createdAt: u.createdAt,
                    lastSync: u.lastSync
                })),
                generatedAt: new Date()
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Erro ao buscar métricas.', error: error.message });
    }
};
