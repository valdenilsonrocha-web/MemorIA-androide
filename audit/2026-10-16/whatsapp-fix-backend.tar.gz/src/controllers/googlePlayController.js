import sequelize, { User } from '../models/index.js';
import { verifyPushToken } from '../services/googlePlayPush.js';
import { configured, packageName, refreshGooglePlay, verifySubscription, acknowledgeSubscription } from '../services/googlePlay.js';

export const verifyGooglePlayPurchase = async (req,res) => {
    if (!configured()) return res.status(503).json({success:false,message:'Google Play Billing não configurado no servidor.'});
    try {
        const {subscription,acknowledged} = await verifySubscription(req.body.purchaseToken, req.user.id);
        // Serialize claims for this MemorIA account. Google also binds each purchase to its hashed ID.
        await sequelize.transaction(async transaction => {
            const user = await User.findByPk(req.user.id,{transaction,lock:transaction.LOCK.UPDATE});
            const current = user.googlePlaySubscription;
            if (current?.purchaseToken !== subscription.purchaseToken && current?.active && Date.parse(current.expiryTime)>Date.now() &&
                (!subscription.active || Date.parse(current.expiryTime)>Date.parse(subscription.expiryTime))) {
                throw Object.assign(new Error('Uma assinatura mais recente já está vinculada à conta.'),{status:409});
            }
            await user.update({googlePlaySubscription:subscription},{transaction});
        });
        // Acknowledge only after durable delivery; retries are safe if acknowledgement fails.
        if (subscription.active && !acknowledged) await acknowledgeSubscription(subscription);
        return res.json({success:true,data:{active:subscription.active,plan:subscription.plan,expiryTime:subscription.expiryTime}});
    } catch(error) {
        const status = [400,403,409].includes(error.status) ? error.status : 502;
        return res.status(status).json({success:false,message:status===502 ? 'Falha ao confirmar a compra. Use Restaurar compras para tentar novamente.' : error.message});
    }
};


export const googlePlayNotification = async (req,res) => {
    if (!process.env.GOOGLE_PLAY_RTDN_AUDIENCE || !process.env.GOOGLE_PLAY_RTDN_SERVICE_ACCOUNT) return res.sendStatus(503);
    if (!await verifyPushToken(req.headers.authorization)) return res.sendStatus(401);
    try {
        const encoded=req.body?.message?.data;
        if(typeof encoded!=='string' || encoded.length>20000) return res.sendStatus(400);
        const notification=JSON.parse(Buffer.from(encoded,'base64').toString('utf8'));
        if(notification.packageName!==packageName()) return res.sendStatus(400);
        if(notification.testNotification) return res.sendStatus(204);
        const token=notification.subscriptionNotification?.purchaseToken || notification.voidedPurchaseNotification?.purchaseToken;
        if(typeof token!=='string' || token.length>4096) return res.sendStatus(204);
        // Event payloads are hints only; always retrieve authoritative subscription state from Google.
        const user=await User.findOne({where:{'googlePlaySubscription.purchaseToken':token}});
        if(user) await refreshGooglePlay(user,true);
        return res.sendStatus(204);
    } catch { return res.sendStatus(503); } // Pub/Sub retries transient failures.
};
