import { timingSafeEqual } from 'node:crypto';

export const matchesSecret = (actual, expected) => {
    if (!expected || expected.length < 32 || typeof actual !== 'string') return false;
    const a = Buffer.from(actual);
    const b = Buffer.from(expected);
    return a.length === b.length && timingSafeEqual(a, b);
};

export const whatsappOperationsOnly = (req, res, next) => {
    if (!matchesSecret(req.get('x-whatsapp-admin-token'), process.env.WHATSAPP_ADMIN_TOKEN)) {
        return res.status(401).json({ success: false, message: 'Acesso operacional não autorizado.' });
    }
    next();
};
