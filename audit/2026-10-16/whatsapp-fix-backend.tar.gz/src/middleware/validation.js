import { validationResult } from 'express-validator';

export const handleValidationErrors = (req, res, next) => {
    const errors = validationResult(req);

    if (errors.isEmpty()) {
        return next();
    }

    const sanitizedErrors = errors.array().map((err) => ({
        field: err.path,
        message: err.msg
    }));

    return res.status(400).json({
        success: false,
        message: 'Dados inválidos na requisição.',
        errors: sanitizedErrors
    });
};

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Rejeita um `:id` que não seja UUID antes de chegar ao Sequelize.
 *
 * Sem isto, `/api/medications/nao-e-uuid` descia até ao Postgres, que rejeitava
 * a query, e o handler devolvia 500 com o erro cru do banco no corpo
 * ("invalid input syntax for type uuid: ..."). Além de ser o código errado —
 * o pedido é que está mal formado, não o servidor — expunha o motor e o tipo
 * da coluna a quem chamasse a API.
 */
export const validateUuidParam = (paramName = 'id') => (req, res, next) => {
    const value = req.params[paramName];
    if (!UUID_RE.test(String(value || ''))) {
        return res.status(400).json({
            success: false,
            message: 'Identificador inválido.'
        });
    }
    return next();
};
