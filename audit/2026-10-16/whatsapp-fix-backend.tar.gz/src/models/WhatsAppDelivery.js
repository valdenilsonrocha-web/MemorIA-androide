import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

// One durable record per notification occurrence and recipient. Never drop on restart.
const WhatsAppDelivery = sequelize.define('WhatsAppDelivery', {
    id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
    deliveryKey: { type: DataTypes.STRING(255), allowNull: false, unique: true, field: 'delivery_key' },
    recipient: { type: DataTypes.STRING(15), allowNull: false },
    message: { type: DataTypes.TEXT, allowNull: false },
    eventType: { type: DataTypes.STRING(50), allowNull: false, field: 'event_type' },
    expiresAt: { type: DataTypes.DATE, allowNull: true, field: 'expires_at' },
    status: { type: DataTypes.STRING(30), allowNull: false, defaultValue: 'pending' },
    messageId: { type: DataTypes.STRING(255), allowNull: true, field: 'message_id' },
    attempts: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
    nextAttemptAt: { type: DataTypes.DATE, allowNull: true, field: 'next_attempt_at' },
    lastError: { type: DataTypes.TEXT, allowNull: true, field: 'last_error' },
}, { tableName: 'whatsapp_deliveries', timestamps: true, underscored: true });

export default WhatsAppDelivery;
