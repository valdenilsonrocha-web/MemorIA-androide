import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Prescription = sequelize.define('Prescription', {
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true
    },
    userId: {
        type: DataTypes.UUID,
        allowNull: false,
        field: 'user_id',
        references: {
            model: 'users',
            key: 'id'
        }
    },
    fileName: {
        type: DataTypes.STRING(255),
        allowNull: false,
        field: 'file_name'
    },
    imageData: {
        type: DataTypes.TEXT('long'),
        allowNull: false,
        field: 'image_data'
    },
    ocrText: {
        type: DataTypes.TEXT,
        allowNull: true,
        field: 'ocr_text'
    },
    capturedAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
        field: 'captured_at'
    }
}, {
    tableName: 'prescriptions',
    timestamps: true,
    underscored: true,
    indexes: [
        {
            fields: ['user_id']
        },
        {
            fields: ['captured_at']
        }
    ]
});

export default Prescription;
