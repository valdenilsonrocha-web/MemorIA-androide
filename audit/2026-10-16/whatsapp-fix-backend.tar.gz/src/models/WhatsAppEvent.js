import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const WhatsAppEvent = sequelize.define('WhatsAppEvent', {
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true
    },
    provider: {
        type: DataTypes.STRING(50),
        allowNull: false,
        defaultValue: 'meta-cloud-api'
    },
    eventType: {
        type: DataTypes.STRING(50),
        allowNull: false,
        field: 'event_type'
    },
    messageId: {
        type: DataTypes.STRING(255),
        allowNull: true,
        field: 'message_id'
    },
    status: {
        type: DataTypes.STRING(50),
        allowNull: true
    },
    recipient: {
        type: DataTypes.STRING(30),
        allowNull: true
    },
    error: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    payload: {
        type: DataTypes.JSON,
        allowNull: true
    },
    eventAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'event_at'
    }
}, {
    tableName: 'whatsapp_events',
    timestamps: true,
    underscored: true
});

export default WhatsAppEvent;