import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const MedicationHistory = sequelize.define('MedicationHistory', {
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true
    },
    userId: {
        type: DataTypes.UUID,
        allowNull: false,
        field: 'user_id',
        references: {
            model: 'users',
            key: 'id'
        }
    },
    medicationId: {
        type: DataTypes.UUID,
        allowNull: false,
        field: 'medication_id',
        references: {
            model: 'medications',
            key: 'id'
        }
    },
    medicationName: {
        type: DataTypes.STRING(255),
        allowNull: false,
        field: 'medication_name'
    },
    dosage: {
        type: DataTypes.STRING(100),
        allowNull: false
    },
    scheduleTime: {
        type: DataTypes.STRING(5),
        allowNull: false,
        field: 'schedule_time',
        comment: 'HH:MM format'
    },
    status: {
        type: DataTypes.ENUM('taken', 'missed', 'snoozed'),
        allowNull: false
    },
    takenAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'taken_at',
        comment: 'Timestamp quando foi marcado como tomado'
    },
    scheduledFor: {
        type: DataTypes.DATE,
        allowNull: false,
        field: 'scheduled_for',
        comment: 'Data e hora que deveria tomar'
    },
    notes: {
        type: DataTypes.TEXT,
        allowNull: true,
        comment: 'Observações do usuário'
    },
    latitude: {
        type: DataTypes.DECIMAL(10, 8),
        allowNull: true,
        comment: 'Geolocalização (opcional)'
    },
    longitude: {
        type: DataTypes.DECIMAL(11, 8),
        allowNull: true,
        comment: 'Geolocalização (opcional)'
    }
}, {
    tableName: 'medication_history',
    timestamps: true,
    underscored: true,
    indexes: [
        {
            fields: ['user_id']
        },
        {
            fields: ['medication_id']
        },
        {
            fields: ['status']
        },
        {
            fields: ['scheduled_for']
        },
        {
            fields: ['taken_at']
        }
    ]
});

export default MedicationHistory;
