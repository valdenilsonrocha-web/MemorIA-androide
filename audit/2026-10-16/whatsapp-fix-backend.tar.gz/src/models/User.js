import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';
import bcrypt from 'bcryptjs';

const User = sequelize.define('User', {
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true
    },
    cpf: {
        type: DataTypes.STRING(11),
        allowNull: false,
        unique: true,
        validate: {
            len: [11, 11],
            isNumeric: true
        }
    },
    susCard: {
        type: DataTypes.STRING(15),
        allowNull: true,
        unique: true,
        field: 'sus_card'
    },
    name: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    email: {
        type: DataTypes.STRING(255),
        allowNull: true,
        unique: true,
        validate: {
            isEmail: true
        }
    },
    phone: {
        type: DataTypes.STRING(15),
        allowNull: true
    },
    password: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    birthDate: {
        type: DataTypes.DATEONLY,
        allowNull: true,
        field: 'birth_date'
    },
    address: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    city: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    state: {
        type: DataTypes.STRING(2),
        allowNull: true
    },
    zipCode: {
        type: DataTypes.STRING(8),
        allowNull: true,
        field: 'zip_code'
    },
    healthUnit: {
        type: DataTypes.STRING(255),
        allowNull: true,
        field: 'health_unit',
        comment: 'Unidade básica de saúde vinculada'
    },
    isActive: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
        field: 'is_active'
    },
    gender: {
        type: DataTypes.ENUM('male', 'female', 'other', 'not_informed'),
        defaultValue: 'not_informed',
        allowNull: false
    },
    isAdmin: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
        field: 'is_admin'
    },
    consentDate: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'consent_date',
        comment: 'Data de aceitação dos termos LGPD'
    },
    lastSync: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'last_sync'
    },
    firstLoginAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'first_login_at',
        comment: 'Data do primeiro login no sistema (início do trial de 7 dias de acesso total)'
    },
    voiceAssistantConfig: {
        type: DataTypes.JSON,
        allowNull: true,
        field: 'voice_assistant_config'
    },
    caregivers: {
        type: DataTypes.JSON,
        allowNull: true,
        field: 'caregivers',
        comment: 'Cuidadores/responsáveis p/ alerta de dose perdida: [{name, phone, relation}]'
    },
    googlePlaySubscription: {
        type: DataTypes.JSON, allowNull: true, field: 'google_play_subscription'
    },
    subscriptionStatus: {
        type: DataTypes.STRING(40),
        allowNull: true,
        field: 'subscription_status',
        comment: 'Estado da assinatura no gateway (ex.: authorized, paused, cancelled)'
    },
    subscriptionId: {
        type: DataTypes.STRING(120),
        allowNull: true,
        field: 'subscription_id',
        comment: 'ID da assinatura/preapproval no gateway de pagamento'
    },
    reportAutoSendEnabled: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
        field: 'report_auto_send_enabled'
    },
    reportFrequency: {
        type: DataTypes.ENUM('weekly', 'monthly'),
        allowNull: false,
        defaultValue: 'weekly',
        field: 'report_frequency'
    },
    reportContactEmail: {
        type: DataTypes.STRING(255),
        allowNull: true,
        field: 'report_contact_email',
        validate: {
            isEmail: true
        }
    },
    lastReportSentAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'last_report_sent_at'
    },
    lastReportPeriodKey: {
        type: DataTypes.STRING(40),
        allowNull: true,
        field: 'last_report_period_key'
    },
    reportLastMeta: {
        type: DataTypes.JSON,
        allowNull: true,
        field: 'report_last_meta'
    },
    medicalConsultations: {
        type: DataTypes.JSON,
        allowNull: true,
        field: 'medical_consultations'
    },
    healthVitalSigns: {
        type: DataTypes.JSON,
        allowNull: true,
        field: 'health_vital_signs'
    },
    resetPasswordToken: {
        type: DataTypes.STRING(64),
        allowNull: true,
        field: 'reset_password_token'
    },
    resetPasswordExpires: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'reset_password_expires'
    }
}, {
    tableName: 'users',
    timestamps: true,
    underscored: true,
    hooks: {
        beforeCreate: async (user) => {
            if (user.password) {
                const salt = await bcrypt.genSalt(10);
                user.password = await bcrypt.hash(user.password, salt);
            }
        },
        beforeUpdate: async (user) => {
            if (user.changed('password')) {
                const salt = await bcrypt.genSalt(10);
                user.password = await bcrypt.hash(user.password, salt);
            }
        }
    }
});

// Instance method to compare passwords
User.prototype.comparePassword = async function(candidatePassword) {
    return await bcrypt.compare(candidatePassword, this.password);
};

// Remove password from JSON output
User.prototype.toJSON = function() {
    const values = Object.assign({}, this.get());
    delete values.password;
    delete values.googlePlaySubscription;
    delete values.resetPasswordToken;
    delete values.resetPasswordExpires;
    return values;
};

export default User;
