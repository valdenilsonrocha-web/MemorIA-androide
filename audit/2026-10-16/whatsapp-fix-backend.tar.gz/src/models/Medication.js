import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Medication = sequelize.define('Medication', {
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true
    },
    userId: {
        type: DataTypes.UUID,
        allowNull: false,
        field: 'user_id',
        references: {
            model: 'users',
            key: 'id'
        }
    },
    name: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    dosage: {
        type: DataTypes.STRING(100),
        allowNull: false
    },
    frequency: {
        type: DataTypes.ENUM('daily', 'alternate', 'weekly'),
        allowNull: false,
        defaultValue: 'daily'
    },
    times: {
        type: DataTypes.JSON,
        allowNull: false,
        defaultValue: []
    },
    weekDays: {
        type: DataTypes.JSON,
        allowNull: true,
        field: 'week_days'
    },
    instructions: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    stock: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
    },
    active: {
        type: DataTypes.BOOLEAN,
        defaultValue: true
    },
    prescriptionNumber: {
        type: DataTypes.STRING(100),
        allowNull: true,
        field: 'prescription_number',
        comment: 'Número da receita médica'
    },
    prescriptionDate: {
        type: DataTypes.DATEONLY,
        allowNull: true,
        field: 'prescription_date'
    },
    prescribedBy: {
        type: DataTypes.STRING(255),
        allowNull: true,
        field: 'prescribed_by',
        comment: 'Nome do médico prescritor'
    },
    distributedBy: {
        type: DataTypes.STRING(255),
        allowNull: true,
        field: 'distributed_by',
        comment: 'Unidade de saúde que distribuiu'
    },
    batchNumber: {
        type: DataTypes.STRING(100),
        allowNull: true,
        field: 'batch_number',
        comment: 'Lote do medicamento'
    },
    expiryDate: {
        type: DataTypes.DATEONLY,
        allowNull: true,
        field: 'expiry_date'
    },
    capsuleColor1: {
        type: DataTypes.STRING(7),
        allowNull: true,
        field: 'capsule_color_1',
        comment: 'Cor da metade 1 da cápsula de duas cores'
    },
    capsuleColor2: {
        type: DataTypes.STRING(7),
        allowNull: true,
        field: 'capsule_color_2',
        comment: 'Cor da metade 2 da cápsula de duas cores'
    },
    supplier: {
        type: DataTypes.JSON,
        allowNull: true,
        field: 'supplier',
        comment: 'Fornecedor/Farmácia (Premium): {name, phone}'
    }
}, {
    tableName: 'medications',
    timestamps: true,
    underscored: true,
    indexes: [
        {
            fields: ['user_id']
        },
        {
            fields: ['active']
        },
        {
            fields: ['prescription_number']
        }
    ]
});

export default Medication;
