import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const VoiceAssistantDelivery = sequelize.define('VoiceAssistantDelivery', {
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true
    },
    userId: {
        type: DataTypes.UUID,
        allowNull: false,
        field: 'user_id',
        references: { model: 'users', key: 'id' }
    },
    medicationId: {
        type: DataTypes.UUID,
        allowNull: false,
        field: 'medication_id',
        references: { model: 'medications', key: 'id' }
    },
    medicationName: {
        type: DataTypes.STRING(255),
        allowNull: false,
        field: 'medication_name'
    },
    dosage: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    scheduleTime: {
        type: DataTypes.STRING(5),
        allowNull: false,
        field: 'schedule_time'
    },
    scheduledFor: {
        type: DataTypes.DATE,
        allowNull: false,
        field: 'scheduled_for'
    },
    status: {
        type: DataTypes.ENUM('pending', 'processing', 'accepted', 'failed', 'cancelled'),
        allowNull: false,
        defaultValue: 'pending'
    },
    attempts: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
    },
    nextAttemptAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'next_attempt_at'
    },
    acceptedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'accepted_at'
    },
    lastError: {
        type: DataTypes.TEXT,
        allowNull: true,
        field: 'last_error'
    }
}, {
    tableName: 'voice_assistant_deliveries',
    timestamps: true,
    underscored: true,
    indexes: [
        {
            unique: true,
            fields: ['medication_id', 'schedule_time', 'scheduled_for']
        },
        {
            fields: ['status', 'next_attempt_at']
        },
        {
            fields: ['user_id', 'scheduled_for']
        }
    ]
});

export default VoiceAssistantDelivery;