import { WhatsAppDelivery, WhatsAppEvent } from '../models/index.js';

export const getProvider = () => (process.env.WHATSAPP_PROVIDER || 'evolution').toLowerCase();
export const getEvolutionConfig = () => ({
    url: (process.env.EVOLUTION_API_URL || 'http://localhost:8081').replace(/\/$/, ''),
    apiKey: process.env.EVOLUTION_API_KEY || '',
    instance: process.env.EVOLUTION_INSTANCE_NAME || 'memoria',
});
export const getMetaConfig = () => ({
    baseUrl: (process.env.WHATSAPP_META_BASE_URL || 'https://graph.facebook.com').replace(/\/$/, ''),
    version: process.env.WHATSAPP_META_API_VERSION || 'v21.0',
    accessToken: process.env.WHATSAPP_ACCESS_TOKEN || '',
    phoneNumberId: process.env.WHATSAPP_PHONE_NUMBER_ID || '',
    templateName: process.env.WHATSAPP_MISSED_ALERT_TEMPLATE || '',
    templateLanguage: process.env.WHATSAPP_TEMPLATE_LANGUAGE || 'pt_BR',
});
export const isConfigured = () => getProvider() === 'meta'
    ? Boolean(getMetaConfig().accessToken && getMetaConfig().phoneNumberId)
    : Boolean(getEvolutionConfig().url && getEvolutionConfig().apiKey);

export const normalizePhone = (raw = '') => {
    let digits = String(raw).replace(/\D/g, '').replace(/^0+/, '');
    if (digits.length === 10 || digits.length === 11) digits = `55${digits}`;
    return /^[1-9]\d{9,14}$/.test(digits) ? digits : '';
};
export const providerError = (data, status) => {
    const error = data?.error?.message || data?.response?.message || data?.message || data?.error || `HTTP ${status}`;
    return (typeof error === 'string' ? error : JSON.stringify(error)).slice(0, 500);
};
const requestJson = async (url, options) => {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 12000);
    try {
        const res = await fetch(url, { ...options, signal: controller.signal });
        const data = await res.json().catch(() => ({}));
        return { ok: res.ok, status: res.status, data };
    } catch (error) {
        return { ok: false, status: 0, uncertain: true, data: { error: { message: error.message } } };
    } finally { clearTimeout(timeout); }
};
export const evolutionRequest = (path, method = 'GET', body) => {
    const { url, apiKey } = getEvolutionConfig();
    return requestJson(`${url}${path}`, {
        method, headers: { 'Content-Type': 'application/json', apikey: apiKey },
        ...(body ? { body: JSON.stringify(body) } : {}),
    });
};

let connectionCache = null;
export const invalidateConnection = () => { connectionCache = null; };
export const getConnectionState = async ({ fresh = false } = {}) => {
    if (!isConfigured()) return { provider: getProvider(), state: 'not_configured', connected: false };
    if (getProvider() === 'meta') return { provider: 'meta', state: 'configured', connected: true };
    if (!fresh && connectionCache && Date.now() - connectionCache.at < 15000) return connectionCache.value;
    const { instance } = getEvolutionConfig();
    const response = await evolutionRequest(`/instance/connectionState/${encodeURIComponent(instance)}`);
    const state = response.ok ? (response.data?.instance?.state || response.data?.state || 'unknown') : 'unavailable';
    const value = { provider: 'evolution', instance, state, connected: state === 'open' };
    connectionCache = { at: Date.now(), value };
    return value;
};
const send = async (recipient, text) => {
    if (getProvider() !== 'meta') {
        return evolutionRequest(`/message/sendText/${encodeURIComponent(getEvolutionConfig().instance)}`, 'POST', { number: recipient, text });
    }
    const c = getMetaConfig();
    const body = c.templateName ? {
        messaging_product: 'whatsapp', to: recipient, type: 'template',
        template: { name: c.templateName, language: { code: c.templateLanguage }, components: [{ type: 'body', parameters: [{ type: 'text', text }] }] },
    } : { messaging_product: 'whatsapp', to: recipient, type: 'text', text: { body: text } };
    return requestJson(`${c.baseUrl}/${c.version}/${c.phoneNumberId}/messages`, {
        method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${c.accessToken}` }, body: JSON.stringify(body),
    });
};
const COMPLETE = ['accepted', 'sent', 'delivered', 'read'];
const MAX_ATTEMPTS = 8;
export const sendTrackedWhatsApp = async ({ deliveryKey, to, message, eventType = 'manual', now = new Date(), expiresAt }) => {
    const recipient = normalizePhone(to);
    if (!recipient) return { ok: false, status: 'failed', error: 'Telefone inválido.' };
    const [delivery] = await WhatsAppDelivery.findOrCreate({
        where: { deliveryKey }, defaults: { recipient, message, eventType, expiresAt, status: 'pending', attempts: 0 },
    });
    if (delivery.recipient !== recipient || delivery.message !== message) {
        return { ok: false, status: 'failed', error: 'Identificador de envio já usado para outro conteúdo ou destinatário.' };
    }
    if (COMPLETE.includes(delivery.status)) return { ok: true, status: delivery.status, messageId: delivery.messageId, duplicate: true };
    if (delivery.status === 'processing' || delivery.status === 'uncertain') {
        // A crash after submission cannot prove the provider rejected it. Never silently resend.
        if (delivery.status === 'processing' && Date.now() - new Date(delivery.updatedAt).getTime() > 120000) {
            await delivery.update({ status: 'uncertain', lastError: 'Resultado do envio não confirmado após reinício; verificar antes de reenviar.' });
            await WhatsAppEvent.create({ provider: getProvider(), eventType, status: 'uncertain', recipient, error: delivery.lastError, payload: { deliveryKey, message }, eventAt: now });
        }
        return { ok: false, status: 'uncertain', error: 'Envio em processamento ou com resultado não confirmado.' };
    }
    if (delivery.status === 'failed' || delivery.status === 'cancelled') return { ok: false, status: delivery.status, error: delivery.lastError };
    if (expiresAt && now > expiresAt) {
        await delivery.update({ status: 'cancelled', lastError: 'Janela de envio encerrada.' });
        return { ok: false, status: 'cancelled', error: delivery.lastError };
    }
    if (delivery.nextAttemptAt && now < new Date(delivery.nextAttemptAt)) return { ok: false, status: 'pending', error: delivery.lastError };
    const state = await getConnectionState();
    if (!state.connected) {
        const error = `WhatsApp desconectado (${state.state}). Vincule a linha pelo QR Code.`;
        if (delivery.lastError !== error) {
            await WhatsAppEvent.create({ provider: getProvider(), eventType, status: 'waiting_connection', recipient, error, payload: { deliveryKey, message }, eventAt: now });
        }
        await delivery.update({ nextAttemptAt: new Date(now.getTime() + 60000), lastError: error });
        return { ok: false, status: 'waiting_connection', error };
    }
    const attempts = delivery.attempts + 1;
    const [claimed] = await WhatsAppDelivery.update({ status: 'processing', attempts, lastError: null }, {
        where: { id: delivery.id, status: 'pending', attempts: delivery.attempts },
    });
    if (!claimed) return { ok: false, status: 'processing', error: 'Envio já em processamento.' };
    const result = await send(recipient, message);
    const messageId = result.data?.key?.id || result.data?.messages?.[0]?.id || null;
    // A 2xx without an ID or a lost HTTP response is not safe to retry automatically.
    const uncertain = result.uncertain || (result.ok && !messageId);
    const ok = result.ok && Boolean(messageId);
    const status = ok ? 'accepted' : uncertain ? 'uncertain' : attempts >= MAX_ATTEMPTS || (result.status >= 400 && result.status < 500 && result.status !== 429) ? 'failed' : 'pending';
    const error = ok ? null : uncertain ? 'Resultado não confirmado pelo provedor; verificar antes de reenviar.' : providerError(result.data, result.status);
    await WhatsAppDelivery.update({ status, messageId, attempts, lastError: error, nextAttemptAt: status === 'pending' ? new Date(now.getTime() + Math.min(300000, 30000 * 2 ** (attempts - 1))) : null }, { where: { id: delivery.id, status: 'processing' } });
    if (ok) {
        // A fast webhook can arrive before the HTTP send response is persisted.
        const confirmation = await WhatsAppEvent.findOne({ where: { messageId, status: ['delivered', 'read'] }, order: [['eventAt', 'DESC']] });
        if (confirmation) await WhatsAppDelivery.update({ status: confirmation.status }, { where: { id: delivery.id, status: ['accepted', 'sent'] } });
    }
    await WhatsAppEvent.create({ provider: getProvider(), eventType, messageId, recipient, status: ok ? 'accepted' : status === 'pending' ? 'retry_pending' : status, error, payload: { deliveryKey, message, attempts, providerStatus: result.status }, eventAt: now });
    return { ok, status, messageId, error };
};

export const recordEvolutionWebhook = async (payload) => {
    invalidateConnection();
    const eventType = String(payload.event || 'unknown').replaceAll('_', '.').toLowerCase();
    const rows = Array.isArray(payload.data) ? payload.data : [payload.data || {}];
    for (const data of rows) {
        const messageId = data.key?.id || data.keyId || data.id || null;
        const raw = data.update?.status ?? data.status;
        const mapped = { 0: 'failed', 1: 'accepted', 2: 'sent', 3: 'delivered', 4: 'read', 5: 'read', PENDING: 'accepted', SERVER_ACK: 'sent', DELIVERY_ACK: 'delivered', READ: 'read', PLAYED: 'read', ERROR: 'failed' };
        const status = eventType === 'connection.update' ? String(data.state || 'unknown') : mapped[raw];
        if (!status) continue;
        const delivery = messageId ? await WhatsAppDelivery.findOne({ where: { messageId } }) : null;
        if (delivery) {
            const rank = { accepted: 1, sent: 2, delivered: 3, read: 4 };
            if ((status === 'failed' && !['delivered', 'read'].includes(delivery.status)) || !rank[delivery.status] || rank[status] > rank[delivery.status]) {
                await delivery.update({ status, lastError: status === 'failed' ? 'Provedor informou falha de entrega.' : null });
            }
        }
        await WhatsAppEvent.create({ provider: 'evolution', eventType: 'provider-status', messageId, recipient: delivery?.recipient || null, status, payload: { event: eventType, state: data.state || null }, eventAt: new Date() });
    }
};
