/**
 * Mercado Pago — assinatura (Preapproval) via API REST, sem SDK (usa fetch).
 *
 * Mantém o MESMO formato de resposta do gateway Stripe (url + sessionId/amount),
 * para o frontend funcionar com mudança mínima: o back-end devolve o `init_point`
 * do Mercado Pago como `url`, e o app redireciona para lá.
 *
 * Requer no .env: MERCADOPAGO_ACCESS_TOKEN (use o de TESTE/sandbox primeiro).
 * Docs: https://www.mercadopago.com.br/developers/pt/reference/subscriptions/_preapproval/post
 */

import crypto from 'crypto';

const MP_API = 'https://api.mercadopago.com';

// Plano único: anual cobrado mês a mês (R$12,90/mês).
// Marketing: "é o preço de um café para monitorar a saúde de seu idoso querido"
export const PLAN_CONFIG = {
    monthly: {
        label: 'Mensal',
        amount: 14.90,
        frequency: 1,
        frequencyType: 'months',
        displayPrice: 'R$ 14,90/mês'
    },
    annual: {
        label: 'Anual',
        // Cobrado mês a mês ao preço de R$12,90 — equivalente ao plano anual parcelado.
        amount: 12.90,
        frequency: 1,
        frequencyType: 'months',
        displayPrice: 'R$ 12,90/mês (plano anual)'
    }
};

export const TRIAL_PERIOD_DAYS = 7;

const getAccessToken = () => process.env.MERCADOPAGO_ACCESS_TOKEN || '';

export const isMercadoPagoConfigured = () => Boolean(getAccessToken());

const sanitizePlan = (value) => (value === 'annual' ? 'annual' : 'monthly');

const mpRequest = async (path, method = 'GET', body = null) => {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 12000);
    try {
        const headers = {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${getAccessToken()}`
        };
        if (method === 'POST') {
            headers['X-Idempotency-Key'] = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
        }
        const res = await fetch(`${MP_API}${path}`, {
            method,
            headers,
            ...(body ? { body: JSON.stringify(body) } : {}),
            signal: controller.signal
        });
        clearTimeout(timeout);
        const text = await res.text();
        let data = null;
        try { data = JSON.parse(text); } catch { data = { raw: text }; }
        return { ok: res.ok, status: res.status, data };
    } catch (err) {
        clearTimeout(timeout);
        return { ok: false, status: 0, data: { message: err.message } };
    }
};

/**
 * Cria uma assinatura (preapproval) e devolve o link de checkout do Mercado Pago.
 * @returns {{ok:boolean, data?:object, error?:string}}
 */
export const createSubscription = async ({ plan, payerEmail, frontendUrl, externalReference }) => {
    const safePlan = sanitizePlan(plan);
    const cfg = PLAN_CONFIG[safePlan];

    const body = {
        reason: `MemorIA Premium ${cfg.label}`,
        external_reference: externalReference || 'anonymous',
        payer_email: payerEmail,
        back_url: `${frontendUrl}/?payment=success&plan=${safePlan}`,
        status: 'pending',
        auto_recurring: {
            frequency: cfg.frequency,
            frequency_type: cfg.frequencyType,
            transaction_amount: cfg.amount,
            currency_id: 'BRL',
            free_trial: { frequency: TRIAL_PERIOD_DAYS, frequency_type: 'days' }
        }
    };

    const result = await mpRequest('/preapproval', 'POST', body);
    if (!result.ok) {
        return {
            ok: false,
            error: result.data?.message || result.data?.error || `status_${result.status}`
        };
    }

    const d = result.data || {};
    // Em conta de TESTE, o sandbox_init_point é o link correto.
    const url = d.sandbox_init_point || d.init_point;
    return {
        ok: true,
        data: {
            sessionId: d.id,
            url,
            plan: safePlan,
            trialDays: TRIAL_PERIOD_DAYS,
            amount: cfg.amount
        }
    };
};

/** Consulta uma assinatura pelo id. */
export const getSubscription = async (id) => mpRequest(`/preapproval/${encodeURIComponent(id)}`);

/** Cancela uma assinatura (preapproval). */
export const cancelSubscription = async (id) =>
    mpRequest(`/preapproval/${encodeURIComponent(id)}`, 'PUT', { status: 'cancelled' });

/** Mercado Pago: só 'authorized' concede acesso (NÃO 'pending' — ainda não pago). */
export const isAccessActive = (status) => status === 'authorized';

/**
 * Valida a assinatura (header x-signature) de um webhook do Mercado Pago.
 * Sem MERCADOPAGO_WEBHOOK_SECRET configurado, aceita (modo dev), como o webhook Stripe.
 */
export const validateWebhookSignature = ({ xSignature, xRequestId, dataId }) => {
    const secret = process.env.MERCADOPAGO_WEBHOOK_SECRET || '';
    if (!secret) return { ok: true, skipped: true };
    if (!xSignature) return { ok: false };
    const parts = Object.fromEntries(
        String(xSignature).split(',').map((kv) => kv.split('=').map((s) => s.trim()))
    );
    const { ts, v1 } = parts;
    if (!ts || !v1) return { ok: false };
    const id = String(dataId || '').toLowerCase();
    const manifest = `id:${id};request-id:${xRequestId || ''};ts:${ts};`;
    const hmac = crypto.createHmac('sha256', secret).update(manifest).digest('hex');
    try {
        const a = Buffer.from(hmac);
        const b = Buffer.from(String(v1));
        return { ok: a.length === b.length && crypto.timingSafeEqual(a, b) };
    } catch {
        return { ok: false };
    }
};

/** Chave pública do Mercado Pago — o app móvel precisa dela para tokenizar. */
export const getPublicKey = () => (process.env.MERCADOPAGO_PUBLIC_KEY || '').trim();

/**
 * Cria a assinatura DIRETAMENTE com um cartão já tokenizado pelo cliente.
 *
 * É o caminho do app nativo: o telemóvel troca os dados do cartão por um
 * `card_token_id` contra a API do Mercado Pago usando a chave pública, e só o
 * token chega até aqui. O número do cartão nunca passa por este servidor — é o
 * que mantém o MemorIA fora do âmbito de armazenamento de dados de cartão.
 *
 * Ao contrário de `createSubscription`, não há `back_url` nem `init_point`: a
 * assinatura nasce `authorized`, sem página nenhuma pelo meio.
 */
export const createSubscriptionWithCardToken = async ({
    plan,
    payerEmail,
    cardTokenId,
    externalReference
}) => {
    const safePlan = sanitizePlan(plan);
    const cfg = PLAN_CONFIG[safePlan];

    const body = {
        reason: `MemorIA Premium ${cfg.label}`,
        external_reference: externalReference || 'anonymous',
        payer_email: payerEmail,
        card_token_id: cardTokenId,
        status: 'authorized',
        auto_recurring: {
            frequency: cfg.frequency,
            frequency_type: cfg.frequencyType,
            transaction_amount: cfg.amount,
            currency_id: 'BRL',
            free_trial: { frequency: TRIAL_PERIOD_DAYS, frequency_type: 'days' }
        }
    };

    const result = await mpRequest('/preapproval', 'POST', body);
    if (!result.ok) {
        return {
            ok: false,
            // A mensagem do Mercado Pago diz o que o utilizador tem de corrigir
            // ("cartão recusado", "CVV inválido"); engoli-la deixaria o ecrã a
            // dizer apenas "erro" para um problema que ele consegue resolver.
            error: result.data?.message || result.data?.error || `status_${result.status}`
        };
    }

    const d = result.data || {};
    return {
        ok: true,
        data: {
            sessionId: d.id,
            plan: safePlan,
            trialDays: TRIAL_PERIOD_DAYS,
            amount: cfg.amount,
            subscriptionStatus: d.status || null
        }
    };
};
