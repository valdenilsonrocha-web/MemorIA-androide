import { Op } from 'sequelize';
import { Medication, MedicationHistory, WhatsAppDelivery, WhatsAppEvent } from '../models/index.js';
import { userIsPremium } from '../middleware/auth.js';
import { APP_TZ, getLocalDateKey, getLocalDayBounds, zonedDateTimeToUtc, isScheduledOnDate, getMedicationTimes } from './medicationSchedule.js';
import { normalizePhone, isConfigured, getProvider, sendTrackedWhatsApp, getMetaConfig } from './whatsappTransport.js';
import { buildReminderMessage, buildLowStockMessage, buildCriticalCaregiverStockMessage, buildCriticalSupplierMessage } from './whatsappMessages.js';

const LEAD = Math.max(0, Math.min(30, Number(process.env.WHATSAPP_REMINDER_LEAD_MINUTES ?? 5)));
const CATCHUP = Math.max(1, Math.min(180, Number(process.env.WHATSAPP_REMINDER_CATCHUP_MINUTES) || 30));
const GRACE = Math.max(1, Number(process.env.WHATSAPP_MISSED_GRACE_MINUTES) || 30);
const MISSED_WINDOW = Math.max(1, Math.min(180, Number(process.env.WHATSAPP_MISSED_ALERT_WINDOW_MIN) || 120));
const LOW_STOCK = Number(process.env.WHATSAPP_LOW_STOCK_THRESHOLD) || 5;
const CRITICAL_STOCK = Number(process.env.WHATSAPP_CRITICAL_STOCK_THRESHOLD) || 2;
let reminderRunning = false;
let missedRunning = false;
let intervalId = null;

const getCaregivers = user => (Array.isArray(user?.caregivers) ? user.caregivers : [])
    .map(c => ({ ...c, phone: normalizePhone(c?.phone) })).filter(c => c.phone);
const key = (kind, med, date, time, phone) => `${kind}:${med.id}:${date}:${time}:${phone}`;
const datesAround = now => [...new Set([-86400000, 0, 86400000].map(delta => getLocalDateKey(new Date(now.getTime() + delta))))];
const dueOccurrences = (med, now, minAge, maxAge) => {
    const result = [];
    for (const date of datesAround(now)) {
        if (!isScheduledOnDate(med, date)) continue;
        for (const time of getMedicationTimes(med)) {
            const [h, m] = time.split(':').map(Number);
            const at = zonedDateTimeToUtc(date, h, m);
            const age = (now.getTime() - at.getTime()) / 60000;
            if (age >= minAge && age <= maxAge) result.push({ date, time, at });
        }
    }
    return result;
};
const resolved = async (med, dose) => {
    const [start, end] = getLocalDayBounds(dose.date);
    return (await MedicationHistory.count({ where: {
        medicationId: med.id, scheduleTime: dose.time,
        status: { [Op.in]: ['taken', 'snoozed'] }, scheduledFor: { [Op.between]: [start, end] },
    } })) > 0;
};
const medications = () => Medication.findAll({ where: { active: true }, include: [{
    association: 'user', required: true, where: { isActive: true },
    attributes: ['id', 'name', 'phone', 'caregivers', 'isAdmin', 'subscriptionStatus', 'googlePlaySubscription', 'firstLoginAt', 'createdAt', 'isActive'],
}] });
const tracked = (kind, med, dose, phone, message, now, windowMinutes = CATCHUP) => sendTrackedWhatsApp({
    deliveryKey: key(kind, med, dose.date, dose.time || '', phone), to: phone, message, eventType: kind, now,
    expiresAt: new Date(dose.at.getTime() + windowMinutes * 60000),
});

export const runReminderCheck = async (now = new Date()) => {
    if (!isConfigured() || reminderRunning) return;
    reminderRunning = true;
    try {
        for (const med of await medications()) {
            const user = med.user;
            const phone = normalizePhone(user?.phone);
            if (!phone) continue;
            for (const dose of dueOccurrences(med, now, -LEAD, CATCHUP)) {
                if (await resolved(med, dose)) continue;
                await tracked('dose-reminder', med, dose, phone, buildReminderMessage(user.name, med.name, med.dosage, dose.time), now);
            }
            if (typeof med.stock !== 'number' || med.stock < 0 || med.stock > LOW_STOCK) continue;
            const date = getLocalDateKey(now);
            const [, end] = getLocalDayBounds(date);
            const stockDose = { date, time: '', at: end };
            await tracked('low-stock', med, stockDose, phone, buildLowStockMessage(user.name, med.name, med.stock), now, 0);
            if (!userIsPremium(user) || med.stock > CRITICAL_STOCK) continue;
            for (const cg of getCaregivers(user)) {
                await tracked('critical-stock-caregiver', med, stockDose, cg.phone, buildCriticalCaregiverStockMessage(cg.name, user.name, med.name, med.stock), now, 0);
            }
            const supplier = normalizePhone(med.supplier?.phone);
            if (supplier) await tracked('critical-stock-supplier', med, stockDose, supplier, buildCriticalSupplierMessage(med.supplier.name, user.name, user.phone, med.name), now, 0);
        }
    } catch (error) { console.error('[whatsapp-reminders] Erro no ciclo:', error.message); }
    finally { reminderRunning = false; }
};

export const runMissedDoseCheck = async (now = new Date()) => {
    if (!isConfigured() || missedRunning) return;
    missedRunning = true;
    try {
        for (const med of await medications()) {
            const caregivers = getCaregivers(med.user);
            if (!caregivers.length) continue;
            for (const dose of dueOccurrences(med, now, GRACE, GRACE + MISSED_WINDOW)) {
                if (await resolved(med, dose)) continue;
                const previous = await WhatsAppDelivery.findOne({ where: {
                    deliveryKey: { [Op.in]: caregivers.map(cg => key('missed-dose', med, dose.date, dose.time, cg.phone)) },
                    status: { [Op.in]: ['accepted', 'sent', 'delivered', 'read', 'processing', 'uncertain'] },
                } });
                if (previous) continue;
                for (const cg of caregivers) {
                    const message = `*MemorIA — Dose não confirmada*\n\nO(a) Sr(a). *${med.user.name}* ainda não confirmou a medicação das *${dose.time}*.\nSe possível, entre em contato para verificar se está tudo bem.\n\nMedicamento: *${med.name}*${med.dosage ? ` — ${med.dosage}` : ''}`;
                    const result = await tracked('missed-dose', med, dose, cg.phone, message, now, GRACE + MISSED_WINDOW);
                    // Escalate only on a known failure. An accepted or uncertain submission is not a delivery failure.
                    if (result.ok || ['uncertain', 'processing', 'waiting_connection'].includes(result.status)) break;
                }
            }
        }
    } catch (error) { console.error('[missed-dose] Erro no ciclo:', error.message); }
    finally { missedRunning = false; }
};

export const expireWhatsAppDeliveries = async (now = new Date()) => {
    const expired = await WhatsAppDelivery.findAll({ where: {
        status: 'pending', expiresAt: { [Op.lt]: now },
    } });
    for (const row of expired) {
        const [changed] = await WhatsAppDelivery.update({ status: 'cancelled', lastError: 'Janela de envio encerrada.' }, { where: { id: row.id, status: 'pending' } });
        if (changed) await WhatsAppEvent.create({ provider: getProvider(), eventType: row.eventType, recipient: row.recipient, status: 'cancelled', error: 'Janela de envio encerrada.', payload: { deliveryKey: row.deliveryKey, message: row.message }, eventAt: now });
    }
    const stale = await WhatsAppDelivery.findAll({ where: { status: 'processing', updatedAt: { [Op.lt]: new Date(now.getTime() - 120000) } } });
    for (const row of stale) {
        const [changed] = await WhatsAppDelivery.update({ status: 'uncertain', lastError: 'Resultado não confirmado após interrupção; verificar antes de reenviar.' }, { where: { id: row.id, status: 'processing', updatedAt: row.updatedAt } });
        if (changed) await WhatsAppEvent.create({ provider: getProvider(), eventType: row.eventType, recipient: row.recipient, status: 'uncertain', error: 'Verifique o resultado antes de reenviar.', payload: { deliveryKey: row.deliveryKey, message: row.message }, eventAt: now });
    }
};

export const startWhatsAppReminderService = (intervalMinutes = 1) => {
    if (intervalId || !isConfigured()) return;
    if (getProvider() === 'meta' && !getMetaConfig().templateName) {
        console.error('[whatsapp-reminders] Configure um template Meta aprovado antes de ativar os lembretes.');
        return;
    }
    const cycle = async () => {
        try { await expireWhatsAppDeliveries(); await runReminderCheck(); await runMissedDoseCheck(); }
        catch (error) { console.error('[whatsapp-reminders] Falha no ciclo:', error.message); }
    };
    console.log(`[whatsapp-reminders] Serviço iniciado; fuso ${APP_TZ}; recuperação ${CATCHUP}min; intervalo ${intervalMinutes}min.`);
    cycle();
    intervalId = setInterval(cycle, intervalMinutes * 60000);
};

export const __whatsappReminderUtils = { dueOccurrences, resolved, getCaregivers };
