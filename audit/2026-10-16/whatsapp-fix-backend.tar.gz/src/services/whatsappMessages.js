const buildReminderMessage = (userName, medName, dosage, scheduleTime) => {
    const [h, m] = scheduleTime.split(':');
    const timeFormatted = `${h}:${m || '00'}`;
    const firstName = (userName || 'você').split(' ')[0];
    return (
        `🔔 *MemorIA — Lembrete de Medicamento*\n\n` +
        `Olá, ${firstName}! Está na hora de tomar:\n\n` +
        `💊 *${medName}*` +
        (dosage ? ` — ${dosage}` : '') +
        `\n⏰ Horário: ${timeFormatted}\n\n` +
        `Abra o app MemorIA para confirmar a dose. 💙`
    );
};

const buildLowStockMessage = (userName, medName, stock) => {
    const firstName = (userName || 'você').split(' ')[0];
    return (
        `⚠️ *MemorIA — Estoque Baixo*\n\n` +
        `Atenção, ${firstName}!\n\n` +
        `O medicamento *${medName}* está com apenas *${stock} unidade(s)* no estoque.\n\n` +
        `Providencie a reposição para não interromper o tratamento. 🏥`
    );
};

const buildCriticalCaregiverStockMessage = (caregiverName, patientName, medName, stock) => {
    return (
        `🚨 *MemorIA — Estoque Crítico*\n\n` +
        `Olá, o(a) Sr(a). *${patientName}* está ficando sem o medicamento *${medName}* ` +
        `(${stock} unidades restantes).\n\n` +
        `Por favor, verifique se a reposição já foi providenciada.`
    );
};

const buildCriticalSupplierMessage = (supplierName, patientName, patientPhone, medName) => {
    const formattedPhone = patientPhone ? patientPhone.replace(/(\d{2})(\d{4,5})(\d{4})/, '($1) $2-$3') : 'não informado';
    return (
        `🏥 *MemorIA — Pedido de Reposição*\n\n` +
        `Olá *${supplierName || 'Farmácia'}*, o paciente *${patientName}* (telefone: ${formattedPhone}) ` +
        `precisa de reposição do medicamento *${medName}*.\n\n` +
        `Favor entrar em contato com o paciente para providenciar.`
    );
};


export { buildReminderMessage, buildLowStockMessage, buildCriticalCaregiverStockMessage, buildCriticalSupplierMessage };
