import crypto from 'node:crypto';
let keyCache;

// Pub/Sub sends a Google-signed OIDC ID token. Verify signature AND intended service account/audience.
export function validatePushClaims(claims, now=Date.now()) {
    return ['https://accounts.google.com','accounts.google.com'].includes(claims.iss) &&
        !!process.env.GOOGLE_PLAY_RTDN_AUDIENCE && !!process.env.GOOGLE_PLAY_RTDN_SERVICE_ACCOUNT &&
        claims.aud === process.env.GOOGLE_PLAY_RTDN_AUDIENCE &&
        claims.email === process.env.GOOGLE_PLAY_RTDN_SERVICE_ACCOUNT && claims.email_verified === true &&
        Number.isFinite(claims.exp) && claims.exp*1000>now &&
        Number.isFinite(claims.iat) && claims.iat*1000<=now+60000;
}

export async function verifyPushToken(authorization='') {
    if (!authorization.startsWith('Bearer ') || authorization.length>12000) return false;
    try {
        const token=authorization.slice(7), parts=token.split('.');
        if(parts.length!==3) return false;
        const header=JSON.parse(Buffer.from(parts[0],'base64url').toString('utf8'));
        const claims=JSON.parse(Buffer.from(parts[1],'base64url').toString('utf8'));
        if(header.alg!=='RS256' || typeof header.kid!=='string' || !validatePushClaims(claims)) return false;
        if(!keyCache || keyCache.expires<Date.now() || !keyCache.keys[header.kid]) {
            const response=await fetch('https://www.googleapis.com/oauth2/v1/certs',{signal:AbortSignal.timeout(10000)});
            if(!response.ok) return false;
            keyCache={keys:await response.json(),expires:Date.now()+300000};
        }
        const cert=keyCache.keys[header.kid];
        return !!cert && crypto.verify('RSA-SHA256',Buffer.from(parts[0]+'.'+parts[1]),cert,Buffer.from(parts[2],'base64url'));
    } catch { return false; }
}
