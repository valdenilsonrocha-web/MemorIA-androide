import crypto from 'node:crypto';
import fs from 'node:fs/promises';

export const packageName = () => process.env.GOOGLE_PLAY_PACKAGE_NAME || 'com.memoria.mobile';
export const productId = () => process.env.GOOGLE_PLAY_PRODUCT_ID || 'memoria_premium';
export const accountId = (id) => crypto.createHash('sha256').update(String(id)).digest('hex');
// Keyless on GCE: the organization forbids service-account keys, so the server
// asks the VM metadata server for a token of the attached service account. The
// VM must carry the androidpublisher scope and that account must be invited in
// Play Console. A JSON key file still works where keys are allowed.
export const usesMetadata = () => process.env.GOOGLE_PLAY_AUTH === 'metadata';
export const configured = () => usesMetadata() || !!process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_FILE;
const METADATA_TOKEN_URL = 'http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token';
let cachedAccessToken;

async function metadataToken() {
    const response = await fetch(METADATA_TOKEN_URL, {headers:{'Metadata-Flavor':'Google'}, signal:AbortSignal.timeout(5000)});
    const data = await response.json().catch(() => ({}));
    if (!response.ok || !data.access_token) throw new Error('Falha na autenticação do servidor com Google Play.');
    return data;
}

export async function accessToken() {
    if (cachedAccessToken?.expires > Date.now() + 60000) return cachedAccessToken.token;
    if (!configured()) throw new Error('Google Play Billing não configurado no servidor.');
    if (usesMetadata()) {
        const data = await metadataToken();
        cachedAccessToken = {token:data.access_token,expires:Date.now()+Number(data.expires_in)*1000};
        return data.access_token;
    }
    const credentials = JSON.parse(await fs.readFile(process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_FILE, 'utf8'));
    const now = Math.floor(Date.now()/1000);
    const encode = (v) => Buffer.from(JSON.stringify(v)).toString('base64url');
    const unsigned = encode({alg:'RS256',typ:'JWT'}) + '.' + encode({
        iss:credentials.client_email, scope:'https://www.googleapis.com/auth/androidpublisher',
        aud:'https://oauth2.googleapis.com/token', iat:now, exp:now+3600
    });
    const assertion = unsigned + '.' + crypto.sign('RSA-SHA256', Buffer.from(unsigned), credentials.private_key).toString('base64url');
    const response = await fetch('https://oauth2.googleapis.com/token', {
        method:'POST', signal:AbortSignal.timeout(10000),
        body:new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:jwt-bearer',assertion})
    });
    const data = await response.json();
    if (!response.ok || !data.access_token) throw new Error('Falha na autenticação do servidor com Google Play.');
    cachedAccessToken = {token:data.access_token,expires:Date.now()+Number(data.expires_in)*1000};
    return data.access_token;
}

async function request(resource, method='GET', body) {
    const response = await fetch('https://androidpublisher.googleapis.com/androidpublisher/v3/applications/' + encodeURIComponent(packageName()) + '/purchases/' + resource, {
        method, headers:{Authorization:'Bearer ' + await accessToken(),'Content-Type':'application/json'},
        signal:AbortSignal.timeout(10000), ...(body ? {body:JSON.stringify(body)} : {})
    });
    if (!response.ok) {
        // Never log responses/URLs: they contain purchase tokens.
        const error = new Error('Não foi possível validar a assinatura com Google Play.');
        error.status = response.status;
        throw error;
    }
    const text = await response.text();
    return text ? JSON.parse(text) : null;
}

export function entitlement(data, userId, token, now=Date.now()) {
    if (data.externalAccountIdentifiers?.obfuscatedExternalAccountId !== accountId(userId)) {
        const error = new Error('Esta compra pertence a outra conta MemorIA.'); error.status=403; throw error;
    }
    const lines = (data.lineItems || []).filter(item => item.productId === productId() &&
        [process.env.GOOGLE_PLAY_MONTHLY_BASE_PLAN || 'monthly', process.env.GOOGLE_PLAY_ANNUAL_BASE_PLAN || 'annual'].includes(item.offerDetails?.basePlanId));
    const line = lines.sort((a,b)=>Date.parse(b.expiryTime)-Date.parse(a.expiryTime))[0];
    const pending = data.subscriptionState === 'SUBSCRIPTION_STATE_PENDING';
    if (!line || (!pending && !Number.isFinite(Date.parse(line.expiryTime)))) {
        const error = new Error('Produto ou plano Google Play inválido.'); error.status=400; throw error;
    }
    const active = ['SUBSCRIPTION_STATE_ACTIVE','SUBSCRIPTION_STATE_IN_GRACE_PERIOD','SUBSCRIPTION_STATE_CANCELED'].includes(data.subscriptionState) && Date.parse(line.expiryTime)>now;
    return {purchaseToken:token, productId:line.productId, basePlanId:line.offerDetails.basePlanId,
        state:data.subscriptionState, expiryTime:line.expiryTime || null, active,
        plan:line.offerDetails.basePlanId===(process.env.GOOGLE_PLAY_ANNUAL_BASE_PLAN || 'annual') ? 'annual':'monthly',
        checkedAt:new Date(now).toISOString()};
}

export const hasGooglePlayAccess = (subscription, now=Date.now()) => subscription?.active === true && Date.parse(subscription.expiryTime)>now;
export async function verifySubscription(token, userId) {
    const data = await request('subscriptionsv2/tokens/' + encodeURIComponent(token));
    return {subscription:entitlement(data,userId,token),acknowledged:data.acknowledgementState==='ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED'};
}
export async function acknowledgeSubscription(subscription) {
    await request('subscriptions/' + encodeURIComponent(subscription.productId) + '/tokens/' + encodeURIComponent(subscription.purchaseToken) + ':acknowledge','POST',{});
}
export async function refreshGooglePlay(user, force=false) {
    const saved = user.googlePlaySubscription;
    if (!saved?.purchaseToken || (!force && Date.now()-Date.parse(saved.checkedAt)<300000)) return;
    const persist = async (subscription) => {
        // Do not overwrite a newer claim/notification that raced this remote lookup.
        const [changed] = await user.constructor.update({googlePlaySubscription:subscription},{where:{
            id:user.id, 'googlePlaySubscription.purchaseToken':saved.purchaseToken,
            'googlePlaySubscription.checkedAt':saved.checkedAt
        }});
        if (changed) user.googlePlaySubscription=subscription;
        return changed;
    };
    try {
        const {subscription,acknowledged} = await verifySubscription(saved.purchaseToken,user.id);
        const savedSuccessfully = await persist(subscription);
        if (savedSuccessfully && subscription.active && !acknowledged) await acknowledgeSubscription(subscription);
    } catch(error) {
        if (![404,410].includes(error.status)) throw error;
        await persist({...saved,active:false,checkedAt:new Date().toISOString()});
    }
}
