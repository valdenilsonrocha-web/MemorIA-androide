import { Op } from 'sequelize';
import { userIsPremium } from '../middleware/auth.js';
import { Medication, MedicationHistory, VoiceAssistantDelivery } from '../models/index.js';

const APP_TZ = process.env.APP_TIMEZONE || 'America/Sao_Paulo';
const POLL_INTERVAL_MS = 30 * 1000;
const MAX_DELIVERY_AGE_MINUTES = Math.min(
    180,
    Math.max(5, Number(process.env.VOICE_ASSISTANT_GRACE_MINUTES) || 30)
);
const MAX_ATTEMPTS = 8;
const MAX_BATCH_SIZE = 20;
const STALE_PROCESSING_MS = 2 * 60 * 1000;

const WEEKDAY_KEYS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
let cycleInProgress = false;
let intervalId = null;

const getZonedParts = (date) => new Intl.DateTimeFormat('en-CA', {
    timeZone: APP_TZ,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23'
}).formatToParts(date).reduce((parts, part) => {
    parts[part.type] = part.value;
    return parts;
}, {});

const dateKeyFromParts = (parts) => `${parts.year}-${parts.month}-${parts.day}`;

const getLocalDateKey = (date) => dateKeyFromParts(getZonedParts(date));

const zonedDateTimeToUtc = (dateKey, hour = 0, minute = 0) => {
    const [year, month, day] = String(dateKey).split('-').map(Number);
    const requestedUtc = Date.UTC(year, month - 1, day, hour, minute, 0, 0);
    let instant = new Date(requestedUtc);

    for (let attempt = 0; attempt < 3; attempt += 1) {
        const parts = getZonedParts(instant);
        const localAsUtc = Date.UTC(
            Number(parts.year), Number(parts.month) - 1, Number(parts.day),
            Number(parts.hour) % 24, Number(parts.minute), Number(parts.second)
        );
        const adjusted = requestedUtc - (localAsUtc - instant.getTime());
        if (adjusted === instant.getTime()) break;
        instant = new Date(adjusted);
    }

    return instant;
};

const getLocalDayBounds = (dateKey) => {
    const [year, month, day] = String(dateKey).split('-').map(Number);
    const nextDay = new Date(Date.UTC(year, month - 1, day + 1));
    const nextDateKey = `${nextDay.getUTCFullYear()}-${String(nextDay.getUTCMonth() + 1).padStart(2, '0')}-${String(nextDay.getUTCDate()).padStart(2, '0')}`;
    return [zonedDateTimeToUtc(dateKey), new Date(zonedDateTimeToUtc(nextDateKey).getTime() - 1)];
};

const getWeekdayIndex = (dateKey) => {
    const [year, month, day] = String(dateKey).split('-').map(Number);
    const weekday = new Intl.DateTimeFormat('en-US', { timeZone: APP_TZ, weekday: 'long' })
        .format(new Date(Date.UTC(year, month - 1, day, 12)));
    return WEEKDAY_KEYS.indexOf(weekday.toLowerCase());
};

const isScheduledOnDate = (medication, dateKey) => {
    const frequency = medication.frequency || 'daily';
    if (frequency === 'weekly') {
        const days = Array.isArray(medication.weekDays) ? medication.weekDays.map(String) : [];
        const weekday = getWeekdayIndex(dateKey);
        return days.includes(String(weekday)) || days.includes(WEEKDAY_KEYS[weekday]);
    }
    if (frequency === 'alternate') {
        if (!medication.createdAt) return false;
        const anchorKey = getLocalDateKey(new Date(medication.createdAt));
        const [year, month, day] = dateKey.split('-').map(Number);
        const [anchorYear, anchorMonth, anchorDay] = anchorKey.split('-').map(Number);
        const dayDifference = Math.floor((Date.UTC(year, month - 1, day) - Date.UTC(anchorYear, anchorMonth - 1, anchorDay)) / 86400000);
        return dayDifference >= 0 && dayDifference % 2 === 0;
    }
    return true;
};

const getMedicationTimes = (medication) => {
    const times = Array.isArray(medication.times) ? medication.times : [medication.times];
    return times.filter(time => typeof time === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(time));
};

const isDoseResolved = async (medicationId, scheduleTime, scheduledFor) => {
    const dateKey = getLocalDateKey(scheduledFor);
    const [dayStart, dayEnd] = getLocalDayBounds(dateKey);
    return MedicationHistory.findOne({
        where: {
            medicationId,
            scheduleTime,
            status: { [Op.in]: ['taken', 'snoozed'] },
            scheduledFor: { [Op.between]: [dayStart, dayEnd] }
        },
        attributes: ['id']
    });
};

const getWebhookUrl = (config) => {
    if (!config?.enabled || config.provider === 'browser-tts' || !config.webhookUrl) return null;
    try {
        const url = new URL(config.webhookUrl);
        return ['http:', 'https:'].includes(url.protocol) ? url.toString() : null;
    } catch {
        return null;
    }
};

const enqueueDueDoses = async (now = new Date()) => {
    const dateKey = getLocalDateKey(now);
    const localParts = getZonedParts(now);
    const medications = await Medication.findAll({
        where: { active: true },
        include: [{
            association: 'user',
            attributes: ['id', 'name', 'isAdmin', 'subscriptionStatus', 'googlePlaySubscription', 'firstLoginAt', 'createdAt', 'voiceAssistantConfig', 'isActive'],
            where: { isActive: true },
            required: true
        }]
    });

    for (const medication of medications) {
        const user = medication.user;
        const config = user?.voiceAssistantConfig || {};
        if (!user || !userIsPremium(user) || !getWebhookUrl(config)) continue;
        if (!isScheduledOnDate(medication, dateKey)) continue;

        for (const scheduleTime of getMedicationTimes(medication)) {
            const [hour, minute] = scheduleTime.split(':').map(Number);
            const scheduledFor = zonedDateTimeToUtc(dateKey, hour, minute);
            const ageMs = now.getTime() - scheduledFor.getTime();
            if (ageMs < 0 || ageMs > MAX_DELIVERY_AGE_MINUTES * 60 * 1000) continue;

            const existing = await VoiceAssistantDelivery.findOne({
                where: { medicationId: medication.id, scheduleTime, scheduledFor },
                attributes: ['id']
            });
            if (existing || await isDoseResolved(medication.id, scheduleTime, scheduledFor)) continue;

            try {
                await VoiceAssistantDelivery.findOrCreate({
                    where: { medicationId: medication.id, scheduleTime, scheduledFor },
                    defaults: {
                        userId: user.id,
                        medicationId: medication.id,
                        medicationName: medication.name,
                        dosage: medication.dosage,
                        scheduleTime,
                        scheduledFor,
                        status: 'pending',
                        attempts: 0,
                        nextAttemptAt: new Date(Math.max(now.getTime(), scheduledFor.getTime() + 15_000))
                    }
                });
            } catch (error) {
                if (error.name !== 'SequelizeUniqueConstraintError') throw error;
            }
        }
    }
};

const retryDelayMs = (attempts) => Math.min(5 * 60 * 1000, 30 * 1000 * (2 ** Math.max(0, attempts - 1)));

const deliver = async (delivery) => {
    const user = delivery.user;
    const config = user?.voiceAssistantConfig || {};
    const webhookUrl = getWebhookUrl(config);

    if (!user || !userIsPremium(user) || !webhookUrl) {
        await delivery.update({ status: 'cancelled', lastError: 'Integração desativada, inválida ou sem Premium.' });
        return;
    }

    const medication = await Medication.findByPk(delivery.medicationId, { attributes: ['id', 'active'] });
    if (!medication?.active) {
        await delivery.update({ status: 'cancelled', lastError: 'Medicamento inativo ou removido.' });
        return;
    }

    if (await isDoseResolved(delivery.medicationId, delivery.scheduleTime, delivery.scheduledFor)) {
        await delivery.update({ status: 'cancelled', lastError: 'Dose já confirmada ou adiada.' });
        return;
    }

    const attempts = Number(delivery.attempts || 0) + 1;
    const claimed = await VoiceAssistantDelivery.update(
        { status: 'processing', attempts },
        { where: { id: delivery.id, status: 'pending' } }
    );
    if (!claimed[0]) return;

    const message = `Hora do medicamento ${delivery.medicationName || 'prescrito'}. Dosagem ${delivery.dosage || ''}. Horário ${delivery.scheduleTime}.`;
    const payload = {
        provider: config.provider || 'alexa',
        deviceName: String(config.deviceName || '').slice(0, 120),
        userName: String(user.name || '').slice(0, 120),
        medicationName: String(delivery.medicationName || '').slice(0, 255),
        scheduleTime: delivery.scheduleTime,
        message,
        timestamp: new Date().toISOString(),
        deliveryId: delivery.id
    };

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);
    try {
        const response = await fetch(webhookUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
            signal: controller.signal
        });
        clearTimeout(timeout);

        if (!response.ok) {
            throw new Error(`Webhook respondeu HTTP ${response.status}.`);
        }

        await delivery.update({ status: 'accepted', acceptedAt: new Date(), lastError: null, nextAttemptAt: null });
        console.log(`[voice-reminders] Webhook aceito para ${user.name}: ${delivery.medicationName} às ${delivery.scheduleTime}.`);
    } catch (error) {
        clearTimeout(timeout);
        const lastError = String(error.message || 'Falha de rede no webhook.').slice(0, 1000);
        const status = attempts >= MAX_ATTEMPTS ? 'failed' : 'pending';
        const nextAttemptAt = status === 'pending'
            ? new Date(Date.now() + retryDelayMs(attempts))
            : null;
        await delivery.update({ status, attempts, lastError, nextAttemptAt });
        console.warn(`[voice-reminders] Tentativa ${attempts}/${MAX_ATTEMPTS} falhou para ${delivery.medicationName}: ${lastError}`);
    }
};

const processPendingDeliveries = async (now = new Date()) => {
    const staleProcessingAt = new Date(now.getTime() - STALE_PROCESSING_MS);
    await VoiceAssistantDelivery.update(
        { status: 'pending', nextAttemptAt: now },
        { where: { status: 'processing', updatedAt: { [Op.lt]: staleProcessingAt } } }
    );

    const pending = await VoiceAssistantDelivery.findAll({
        where: {
            status: 'pending',
            nextAttemptAt: { [Op.lte]: now }
        },
        include: [{
            association: 'user',
            attributes: ['id', 'name', 'isAdmin', 'subscriptionStatus', 'googlePlaySubscription', 'firstLoginAt', 'createdAt', 'voiceAssistantConfig', 'isActive'],
            required: true
        }],
        order: [['nextAttemptAt', 'ASC']],
        limit: MAX_BATCH_SIZE
    });

    for (const delivery of pending) {
        await deliver(delivery);
    }
};

export const runVoiceAssistantReminderCycle = async (now = new Date()) => {
    if (cycleInProgress) return;
    cycleInProgress = true;
    try {
        await enqueueDueDoses(now);
        await processPendingDeliveries(now);
    } catch (error) {
        console.error('[voice-reminders] Erro no ciclo de lembretes:', error.message);
    } finally {
        cycleInProgress = false;
    }
};

export const startVoiceAssistantReminderService = () => {
    if (intervalId) return;
    console.log(`[voice-reminders] Serviço iniciado (fuso: ${APP_TZ}, verificação: ${POLL_INTERVAL_MS / 1000}s, tolerância de retomada: ${MAX_DELIVERY_AGE_MINUTES}min).`);
    runVoiceAssistantReminderCycle();
    intervalId = setInterval(runVoiceAssistantReminderCycle, POLL_INTERVAL_MS);
};

export const __voiceAssistantReminderUtils = {
    getLocalDateKey,
    getMedicationTimes,
    isScheduledOnDate,
    retryDelayMs,
    zonedDateTimeToUtc
};