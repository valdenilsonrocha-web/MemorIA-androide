export const APP_TZ = process.env.APP_TIMEZONE || 'America/Sao_Paulo';
const WEEKDAY_KEYS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
const getZonedParts = (date) => new Intl.DateTimeFormat('en-CA', {
    timeZone: APP_TZ,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23'
}).formatToParts(date).reduce((parts, part) => {
    parts[part.type] = part.value;
    return parts;
}, {});

const dateKeyFromParts = (parts) => `${parts.year}-${parts.month}-${parts.day}`;

const getLocalDateKey = (date) => dateKeyFromParts(getZonedParts(date));

const zonedDateTimeToUtc = (dateKey, hour = 0, minute = 0) => {
    const [year, month, day] = String(dateKey).split('-').map(Number);
    const requestedUtc = Date.UTC(year, month - 1, day, hour, minute, 0, 0);
    let instant = new Date(requestedUtc);

    for (let attempt = 0; attempt < 3; attempt += 1) {
        const parts = getZonedParts(instant);
        const localAsUtc = Date.UTC(
            Number(parts.year), Number(parts.month) - 1, Number(parts.day),
            Number(parts.hour) % 24, Number(parts.minute), Number(parts.second)
        );
        const adjusted = requestedUtc - (localAsUtc - instant.getTime());
        if (adjusted === instant.getTime()) break;
        instant = new Date(adjusted);
    }

    return instant;
};

const getLocalDayBounds = (dateKey) => {
    const [year, month, day] = String(dateKey).split('-').map(Number);
    const nextDay = new Date(Date.UTC(year, month - 1, day + 1));
    const nextDateKey = `${nextDay.getUTCFullYear()}-${String(nextDay.getUTCMonth() + 1).padStart(2, '0')}-${String(nextDay.getUTCDate()).padStart(2, '0')}`;
    return [zonedDateTimeToUtc(dateKey), new Date(zonedDateTimeToUtc(nextDateKey).getTime() - 1)];
};

const getWeekdayIndex = (dateKey) => {
    const [year, month, day] = String(dateKey).split('-').map(Number);
    const weekday = new Intl.DateTimeFormat('en-US', { timeZone: APP_TZ, weekday: 'long' })
        .format(new Date(Date.UTC(year, month - 1, day, 12)));
    return WEEKDAY_KEYS.indexOf(weekday.toLowerCase());
};

const isScheduledOnDate = (medication, dateKey) => {
    const frequency = medication.frequency || 'daily';
    if (frequency === 'weekly') {
        const days = Array.isArray(medication.weekDays) ? medication.weekDays.map(String) : [];
        const weekday = getWeekdayIndex(dateKey);
        return days.includes(String(weekday)) || days.includes(WEEKDAY_KEYS[weekday]);
    }
    if (frequency === 'alternate') {
        if (!medication.createdAt) return false;
        const anchorKey = getLocalDateKey(new Date(medication.createdAt));
        const [year, month, day] = dateKey.split('-').map(Number);
        const [anchorYear, anchorMonth, anchorDay] = anchorKey.split('-').map(Number);
        const dayDifference = Math.floor((Date.UTC(year, month - 1, day) - Date.UTC(anchorYear, anchorMonth - 1, anchorDay)) / 86400000);
        return dayDifference >= 0 && dayDifference % 2 === 0;
    }
    return true;
};

const getMedicationTimes = (medication) => {
    const times = Array.isArray(medication.times) ? medication.times : [medication.times];
    return times.filter(time => typeof time === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(time));
};


export { getLocalDateKey, getLocalDayBounds, zonedDateTimeToUtc, isScheduledOnDate, getMedicationTimes };
