import { Resend } from 'resend';

// Inicialização preguiçosa: sem RESEND_API_KEY o SDK atira no construtor e
// derruba a app inteira no import. Só instanciamos quando um e-mail é enviado.
let resendClient = null;
const getResend = () => {
    if (!process.env.RESEND_API_KEY) {
        throw new Error('RESEND_API_KEY não configurada — envio de e-mail indisponível.');
    }
    if (!resendClient) {
        resendClient = new Resend(process.env.RESEND_API_KEY);
    }
    return resendClient;
};

const FROM_ADDRESS = process.env.EMAIL_FROM || 'MemorIA <contato@brasmaster.com.br>';
const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:8080';

/**
 * Envia e-mail de recuperação de senha
 */
export async function sendPasswordResetEmail({ to, name, resetToken }) {
    const resetLink = `${FRONTEND_URL}/?resetToken=${resetToken}`;

    const html = `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Recuperação de Senha — MemorIA</title>
</head>
<body style="margin:0; padding:0; background:#f4f7fa; font-family: 'Segoe UI', Arial, sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f7fa; padding: 40px 0;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff; border-radius:12px; overflow:hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.08); max-width:600px; width:100%;">
          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%); padding: 36px 40px; text-align:center;">
              <h1 style="margin:0; color:#ffffff; font-size:28px; font-weight:700; letter-spacing:-0.5px;">
                💊 MemorIA
              </h1>
              <p style="margin: 8px 0 0; color:#93c5fd; font-size:14px;">Lembretes de Medicamentos</p>
            </td>
          </tr>
          <!-- Body -->
          <tr>
            <td style="padding: 40px 40px 24px;">
              <h2 style="margin:0 0 16px; color:#1e293b; font-size:22px; font-weight:600;">
                Recuperação de Senha
              </h2>
              <p style="margin:0 0 12px; color:#475569; font-size:16px; line-height:1.6;">
                Olá${name ? ', <strong>' + name + '</strong>' : ''}!
              </p>
              <p style="margin:0 0 24px; color:#475569; font-size:16px; line-height:1.6;">
                Recebemos uma solicitação para redefinir a senha da sua conta no <strong>MemorIA</strong>.
                Clique no botão abaixo para criar uma nova senha:
              </p>
              <!-- CTA Button -->
              <table cellpadding="0" cellspacing="0" width="100%">
                <tr>
                  <td align="center" style="padding: 8px 0 32px;">
                    <a href="${resetLink}" 
                       style="display:inline-block; background:linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%); color:#ffffff; text-decoration:none; font-size:16px; font-weight:600; padding:14px 36px; border-radius:8px; letter-spacing:0.3px;">
                      🔑 Redefinir minha senha
                    </a>
                  </td>
                </tr>
              </table>
              <!-- Warning -->
              <table cellpadding="0" cellspacing="0" width="100%" style="background:#fef9c3; border-radius:8px; border: 1px solid #fde047;">
                <tr>
                  <td style="padding: 14px 18px;">
                    <p style="margin:0; color:#713f12; font-size:14px; line-height:1.5;">
                      ⚠️ <strong>Este link expira em 1 hora.</strong>
                      Se você não solicitou a recuperação de senha, ignore este e-mail — sua conta permanece segura.
                    </p>
                  </td>
                </tr>
              </table>
              <!-- Fallback link -->
              <p style="margin: 24px 0 0; color:#94a3b8; font-size:13px; line-height:1.6;">
                Se o botão não funcionar, copie e cole o link abaixo no seu navegador:<br>
                <a href="${resetLink}" style="color:#2563eb; word-break:break-all;">${resetLink}</a>
              </p>
            </td>
          </tr>
          <!-- Footer -->
          <tr>
            <td style="background:#f8fafc; padding: 20px 40px; border-top: 1px solid #e2e8f0; text-align:center;">
              <p style="margin:0; color:#94a3b8; font-size:13px; line-height:1.6;">
                MemorIA — Lembretes de Medicamentos<br>
                Dúvidas? Fale conosco: <a href="mailto:contato@brasmaster.com.br" style="color:#2563eb;">contato@brasmaster.com.br</a>
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;

    const text = `
MemorIA — Recuperação de Senha

Olá${name ? ', ' + name : ''}!

Recebemos uma solicitação para redefinir a senha da sua conta no MemorIA.

Acesse o link abaixo para criar uma nova senha (válido por 1 hora):
${resetLink}

Se você não solicitou isso, ignore este e-mail.

MemorIA — contato@brasmaster.com.br
`.trim();

    const { data, error } = await getResend().emails.send({
        from: FROM_ADDRESS,
        to: [to],
        subject: '🔑 Recuperação de Senha — MemorIA',
        html,
        text
    });

    if (error) {
        throw new Error(`Resend error: ${error.message}`);
    }

    return data;
}

/**
 * Envia e-mail de boas-vindas após cadastro
 */
export async function sendWelcomeEmail({ to, name }) {
    const html = `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Bem-vindo ao MemorIA</title>
</head>
<body style="margin:0; padding:0; background:#f4f7fa; font-family: 'Segoe UI', Arial, sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f7fa; padding: 40px 0;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff; border-radius:12px; overflow:hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.08); max-width:600px; width:100%;">
          <tr>
            <td style="background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%); padding: 36px 40px; text-align:center;">
              <h1 style="margin:0; color:#ffffff; font-size:28px; font-weight:700;">💊 MemorIA</h1>
              <p style="margin: 8px 0 0; color:#93c5fd; font-size:14px;">Lembretes de Medicamentos</p>
            </td>
          </tr>
          <tr>
            <td style="padding: 40px 40px 24px;">
              <h2 style="margin:0 0 16px; color:#1e293b; font-size:22px;">Bem-vindo${name ? ', ' + name : ''}! 🎉</h2>
              <p style="margin:0 0 16px; color:#475569; font-size:16px; line-height:1.6;">
                Sua conta no <strong>MemorIA</strong> foi criada com sucesso. Agora você pode:
              </p>
              <ul style="color:#475569; font-size:15px; line-height:2;">
                <li>📋 Cadastrar seus medicamentos e horários</li>
                <li>🔔 Receber lembretes personalizados</li>
                <li>📊 Acompanhar seu histórico de adesão</li>
                <li>👨‍⚕️ Compartilhar relatórios com seu médico</li>
              </ul>
              <p style="margin:24px 0 0; color:#475569; font-size:16px; line-height:1.6;">
                Precisa de ajuda? Fale com a gente:<br>
                <a href="mailto:contato@brasmaster.com.br" style="color:#2563eb;">contato@brasmaster.com.br</a>
              </p>
            </td>
          </tr>
          <tr>
            <td style="background:#f8fafc; padding: 20px 40px; border-top: 1px solid #e2e8f0; text-align:center;">
              <p style="margin:0; color:#94a3b8; font-size:13px;">MemorIA — Lembretes de Medicamentos</p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;

    const { data, error } = await getResend().emails.send({
        from: FROM_ADDRESS,
        to: [to],
        subject: '🎉 Bem-vindo ao MemorIA!',
        html
    });

    if (error) {
        console.error('Welcome email error:', error.message);
        // Não lança — falha silenciosa para não bloquear o registro
    }

    return data;
}

const APP_TZ = process.env.APP_TIMEZONE || 'America/Sao_Paulo';
const DAILY_REPORT_HOUR = Number.parseInt(process.env.REPORT_SEND_HOUR || '8', 10);

const escapeHtml = (value) => String(value || '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');

const formatDate = (value) => new Date(value).toLocaleDateString('pt-BR');
const formatDateTime = (value) => new Date(value).toLocaleString('pt-BR');

const getISOWeekKey = (date) => {
    const utcDate = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    const dayNum = utcDate.getUTCDay() || 7;
    utcDate.setUTCDate(utcDate.getUTCDate() + 4 - dayNum);
    const yearStart = new Date(Date.UTC(utcDate.getUTCFullYear(), 0, 1));
    const weekNo = Math.ceil((((utcDate - yearStart) / 86400000) + 1) / 7);
    return `${utcDate.getUTCFullYear()}-W${String(weekNo).padStart(2, '0')}`;
};

const getReportPeriod = (frequency = 'weekly', now = new Date()) => {
    const end = new Date(now);
    end.setHours(23, 59, 59, 999);

    if (frequency === 'monthly') {
        const start = new Date(now.getFullYear(), now.getMonth(), 1);
        start.setHours(0, 0, 0, 0);
        return {
            frequency: 'monthly',
            key: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`,
            start,
            end
        };
    }

    const start = new Date(end);
    start.setDate(start.getDate() - 6);
    start.setHours(0, 0, 0, 0);
    return {
        frequency: 'weekly',
        key: getISOWeekKey(now),
        start,
        end
    };
};

const estimateDailyUsage = (medication, takenCount, daysInPeriod) => {
    if (takenCount > 0 && daysInPeriod > 0) {
        return Math.max(0.1, takenCount / daysInPeriod);
    }

    const timesCount = Array.isArray(medication?.times) && medication.times.length > 0 ? medication.times.length : 1;
    const frequency = medication?.frequency || 'daily';
    if (frequency === 'alternate') return Math.max(0.1, timesCount / 2);
    if (frequency === 'weekly') {
        const weekDaysCount = Array.isArray(medication?.weekDays) && medication.weekDays.length > 0
            ? medication.weekDays.length
            : 1;
        return Math.max(0.1, (timesCount * weekDaysCount) / 7);
    }
    return Math.max(0.1, timesCount);
};

const calculateReplenishmentForecast = (medication, takenCount, daysInPeriod) => {
    const stock = Number.isFinite(Number(medication?.stock)) ? Number(medication.stock) : 0;
    const dailyUsage = estimateDailyUsage(medication, takenCount, daysInPeriod);
    if (stock <= 0 || dailyUsage <= 0) {
        return { stock, dailyUsage, daysUntilOut: 0, estimatedOutDate: 'Sem estoque' };
    }

    const daysUntilOut = Math.max(0, Math.floor(stock / dailyUsage));
    const estimatedOutDate = new Date();
    estimatedOutDate.setDate(estimatedOutDate.getDate() + daysUntilOut);

    return {
        stock,
        dailyUsage,
        daysUntilOut,
        estimatedOutDate: formatDate(estimatedOutDate)
    };
};

const buildMedicationSummary = ({ medications = [], history = [], periodDays = 7 }) => {
    const byMedication = new Map();
    history.forEach((entry) => {
        const key = String(entry.medicationId || '');
        const current = byMedication.get(key) || { taken: 0, missed: 0, snoozed: 0 };
        if (entry.status === 'taken') current.taken += 1;
        if (entry.status === 'missed') current.missed += 1;
        if (entry.status === 'snoozed') current.snoozed += 1;
        byMedication.set(key, current);
    });

    return medications.map((med) => {
        const stats = byMedication.get(String(med.id)) || { taken: 0, missed: 0, snoozed: 0 };
        const total = stats.taken + stats.missed + stats.snoozed;
        const adherencePct = total > 0 ? Math.round((stats.taken / total) * 100) : 0;
        return {
            id: med.id,
            name: med.name,
            dosage: med.dosage,
            taken: stats.taken,
            missed: stats.missed,
            snoozed: stats.snoozed,
            adherencePct,
            replenishment: calculateReplenishmentForecast(med, stats.taken, periodDays)
        };
    });
};

const buildFutureConsultations = (consultations = []) => {
    const now = new Date();
    return consultations
        .map((item) => ({
            dateTime: new Date(String(item?.dateTime || '')),
            professional: String(item?.professional || '').trim(),
            location: String(item?.location || '').trim(),
            notes: String(item?.notes || '').trim()
        }))
        .filter((item) => !Number.isNaN(item.dateTime.getTime()) && item.dateTime >= now && item.professional)
        .sort((a, b) => a.dateTime - b.dateTime)
        .slice(0, 20);
};

const buildVitalSignsInPeriod = (records = [], periodStart, periodEnd) => {
    return records
        .map((item) => {
            const date = new Date(String(item?.date || ''));
            if (Number.isNaN(date.getTime())) return null;
            return {
                date,
                systolic: item?.systolic ?? null,
                diastolic: item?.diastolic ?? null,
                heartRate: item?.heartRate ?? null,
                spo2: item?.spo2 ?? null,
                glucose: item?.glucose ?? null,
                hba1c: item?.hba1c ?? null,
                temperature: item?.temperature ?? null
            };
        })
        .filter((item) => item && item.date >= periodStart && item.date <= periodEnd)
        .sort((a, b) => b.date - a.date)
        .slice(0, 20);
};

const buildReportHtml = ({ patientName, period, medicationSummary, consultations, vitalSigns }) => {
    const periodTitle = period.frequency === 'monthly' ? 'Mensal' : 'Semanal';
    const medsRows = medicationSummary.map((med) => `
        <tr>
          <td style="padding:8px;border-bottom:1px solid #e2e8f0;"><strong>${escapeHtml(med.name)}</strong>${med.dosage ? ` <span style="color:#64748b">${escapeHtml(med.dosage)}</span>` : ''}</td>
          <td style="padding:8px;border-bottom:1px solid #e2e8f0;text-align:center;">${med.taken}</td>
          <td style="padding:8px;border-bottom:1px solid #e2e8f0;text-align:center;">${med.missed}</td>
          <td style="padding:8px;border-bottom:1px solid #e2e8f0;text-align:center;">${med.adherencePct}%</td>
          <td style="padding:8px;border-bottom:1px solid #e2e8f0;">${med.replenishment.stock} un. • recompra em ~${med.replenishment.daysUntilOut} dia(s) (${escapeHtml(med.replenishment.estimatedOutDate)})</td>
        </tr>
    `).join('');

    const consultationsRows = consultations.length
        ? consultations.map((item) => `<li><strong>${formatDateTime(item.dateTime)}</strong> — ${escapeHtml(item.professional)}${item.location ? ` (${escapeHtml(item.location)})` : ''}</li>`).join('')
        : '<li>Nenhuma consulta futura cadastrada.</li>';

    const vitalRows = vitalSigns.length
        ? vitalSigns.map((item) => `<li>${formatDateTime(item.date)} • PA: ${item.systolic ?? '-'} / ${item.diastolic ?? '-'} mmHg • FC: ${item.heartRate ?? '-'} bpm • SpO₂: ${item.spo2 ?? '-'}% • Glicose: ${item.glucose ?? '-'} mg/dL • HbA1c: ${item.hba1c ?? '-'}% • Temp: ${item.temperature ?? '-'}°C</li>`).join('')
        : '<li>Sem sinais vitais registrados no período.</li>';

    return `
<!DOCTYPE html>
<html lang="pt-BR">
<head><meta charset="UTF-8"><title>Relatório ${periodTitle} — MemorIA</title></head>
<body style="font-family:Arial,sans-serif;background:#f4f7fa;padding:24px;color:#1e293b;">
  <h1 style="color:#1d4ed8;">💊 MemorIA — Relatório ${periodTitle}</h1>
  <p>Paciente: <strong>${escapeHtml(patientName)}</strong></p>
  <p>Período: <strong>${formatDate(period.start)}</strong> até <strong>${formatDate(period.end)}</strong></p>

  <h2>Medicamentos tomados e aderência</h2>
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#fff;border:1px solid #e2e8f0;border-radius:8px;">
    <thead>
      <tr style="background:#f8fafc;">
        <th style="padding:8px;text-align:left;">Medicamento</th>
        <th style="padding:8px;">Tomados</th>
        <th style="padding:8px;">Perdidos</th>
        <th style="padding:8px;">Aderência</th>
        <th style="padding:8px;text-align:left;">Estoque e recompra</th>
      </tr>
    </thead>
    <tbody>${medsRows || '<tr><td colspan="5" style="padding:12px;">Nenhum medicamento ativo encontrado.</td></tr>'}</tbody>
  </table>

  <h2>Consultas agendadas</h2>
  <ul>${consultationsRows}</ul>

  <h2>Sinais vitais no período</h2>
  <ul>${vitalRows}</ul>

  <p style="margin-top:24px;color:#64748b;font-size:12px;">Relatório enviado automaticamente pelo MemorIA.</p>
</body>
</html>`;
};

const buildReportText = ({ patientName, period, medicationSummary, consultations, vitalSigns }) => {
    const periodTitle = period.frequency === 'monthly' ? 'Mensal' : 'Semanal';
    const medsText = medicationSummary.length
        ? medicationSummary.map((med) => `• ${med.name}${med.dosage ? ` (${med.dosage})` : ''}: tomado ${med.taken}, perdido ${med.missed}, adesão ${med.adherencePct}%, estoque ${med.replenishment.stock}, recompra ~${med.replenishment.daysUntilOut} dia(s) (${med.replenishment.estimatedOutDate})`).join('\n')
        : '• Nenhum medicamento ativo encontrado.';
    const consultationsText = consultations.length
        ? consultations.map((item) => `• ${formatDateTime(item.dateTime)} - ${item.professional}${item.location ? ` (${item.location})` : ''}`).join('\n')
        : '• Nenhuma consulta futura cadastrada.';
    const vitalText = vitalSigns.length
        ? vitalSigns.map((item) => `• ${formatDateTime(item.date)} - PA ${item.systolic ?? '-'} / ${item.diastolic ?? '-'} mmHg, FC ${item.heartRate ?? '-'} bpm, SpO₂ ${item.spo2 ?? '-'}%, Glicose ${item.glucose ?? '-'} mg/dL, HbA1c ${item.hba1c ?? '-'}%, Temp ${item.temperature ?? '-'}°C`).join('\n')
        : '• Sem sinais vitais registrados no período.';

    return `MemorIA — Relatório ${periodTitle}

Paciente: ${patientName}
Período: ${formatDate(period.start)} até ${formatDate(period.end)}

Medicamentos tomados e aderência:
${medsText}

Consultas agendadas:
${consultationsText}

Sinais vitais no período:
${vitalText}

Relatório enviado automaticamente pelo MemorIA.`;
};

const sendAutomaticHealthReportEmail = async ({ to, patientName, period, medicationSummary, consultations, vitalSigns }) => {
    const periodicityLabel = period.frequency === 'monthly' ? 'Mensal' : 'Semanal';
    const html = buildReportHtml({ patientName, period, medicationSummary, consultations, vitalSigns });
    const text = buildReportText({ patientName, period, medicationSummary, consultations, vitalSigns });

    const { data, error } = await getResend().emails.send({
        from: FROM_ADDRESS,
        to: [to],
        subject: `📋 Relatório ${periodicityLabel} de Saúde — ${patientName}`,
        html,
        text
    });

    if (error) {
        throw new Error(`Resend error: ${error.message}`);
    }
    return data;
};

const msUntilNextDailyRun = (hour = 8) => {
    const now = new Date();
    const nowInTimeZone = new Date(now.toLocaleString('en-US', { timeZone: APP_TZ }));
    const nextRunInTimeZone = new Date(nowInTimeZone);
    nextRunInTimeZone.setHours(hour, 0, 0, 0);
    if (nextRunInTimeZone.getTime() <= nowInTimeZone.getTime()) {
        nextRunInTimeZone.setDate(nextRunInTimeZone.getDate() + 1);
    }
    return Math.max(0, nextRunInTimeZone.getTime() - nowInTimeZone.getTime());
};

const updateUserReportMeta = async (user, payload) => {
    await user.update({
        reportLastMeta: {
            ...(user.reportLastMeta || {}),
            ...payload,
            updatedAt: new Date().toISOString()
        }
    });
};

/**
 * Inicia o serviço de relatórios periódicos automáticos (semanal/mensal).
 * A execução é diária, e cada usuário recebe de acordo com a frequência escolhida.
 */
export const startWeeklyReportService = () => {
    if (!process.env.RESEND_API_KEY) {
        console.log('[periodic-report] ⚠ RESEND_API_KEY não configurada — relatórios automáticos desativados.');
        return;
    }

    const runReports = async () => {
        console.log('[periodic-report] 📊 Iniciando ciclo diário de relatórios automáticos...');
        try {
            const { User, Medication, MedicationHistory } = await import('../models/index.js');
            const { Op } = await import('sequelize');

            const users = await User.findAll({
                where: { isActive: true, reportAutoSendEnabled: true },
                include: [{ model: Medication, as: 'medications', where: { active: true }, required: false }]
            });

            let sent = 0;
            let skipped = 0;

            for (const user of users) {
                const frequency = user.reportFrequency === 'monthly' ? 'monthly' : 'weekly';
                const period = getReportPeriod(frequency, new Date());
                const targetEmail = String(user.reportContactEmail || user.email || '').trim().toLowerCase();

                if (!targetEmail) {
                    skipped += 1;
                    await updateUserReportMeta(user, {
                        status: 'skipped',
                        reason: 'no_contact_email',
                        message: 'Relatório não enviado: e-mail de contato não cadastrado.',
                        periodKey: period.key
                    });
                    console.log(`[periodic-report] ℹ Usuário ${user.id} sem e-mail de contato. Envio ignorado.`);
                    continue;
                }

                if (user.lastReportPeriodKey === period.key) {
                    skipped += 1;
                    await updateUserReportMeta(user, {
                        status: 'skipped',
                        reason: 'already_sent_period',
                        message: 'Relatório já enviado para o período atual.',
                        periodKey: period.key
                    });
                    console.log(`[periodic-report] ℹ Usuário ${user.id} já recebeu relatório do período ${period.key}.`);
                    continue;
                }

                const meds = user.medications || [];
                const medIds = meds.map((med) => med.id);
                const history = medIds.length > 0
                    ? await MedicationHistory.findAll({
                        where: {
                            userId: user.id,
                            medicationId: { [Op.in]: medIds },
                            scheduledFor: { [Op.between]: [period.start, period.end] }
                        }
                    })
                    : [];

                const periodDays = Math.max(1, Math.ceil((period.end - period.start) / (1000 * 60 * 60 * 24)));
                const medicationSummary = buildMedicationSummary({
                    medications: meds,
                    history,
                    periodDays
                });
                const consultations = buildFutureConsultations(Array.isArray(user.medicalConsultations) ? user.medicalConsultations : []);
                const vitalSigns = buildVitalSignsInPeriod(
                    Array.isArray(user.healthVitalSigns) ? user.healthVitalSigns : [],
                    period.start,
                    period.end
                );

                try {
                    await sendAutomaticHealthReportEmail({
                        to: targetEmail,
                        patientName: user.name,
                        period,
                        medicationSummary,
                        consultations,
                        vitalSigns
                    });

                    await user.update({
                        lastReportSentAt: new Date(),
                        lastReportPeriodKey: period.key,
                        reportLastMeta: {
                            status: 'sent',
                            reason: null,
                            periodKey: period.key,
                            sentAt: new Date().toISOString(),
                            medicationCount: medicationSummary.length,
                            consultationCount: consultations.length,
                            vitalSignsCount: vitalSigns.length
                        }
                    });
                    sent += 1;
                    console.log(`[periodic-report] ✅ Relatório ${frequency} enviado para ${targetEmail} (${user.name})`);
                } catch (error) {
                    await updateUserReportMeta(user, {
                        status: 'failed',
                        reason: 'send_error',
                        message: error.message,
                        periodKey: period.key
                    });
                    console.warn(`[periodic-report] ❌ Falha no envio para ${targetEmail}: ${error.message}`);
                }

                await new Promise((resolve) => setTimeout(resolve, 300));
            }

            console.log(`[periodic-report] Ciclo concluído: ${sent} enviado(s), ${skipped} ignorado(s).`);
        } catch (err) {
            console.error('[periodic-report] Erro no ciclo de relatórios:', err.message);
        }
    };

    const scheduleNext = async () => {
        try {
            await runReports();
        } catch (error) {
            console.error('[periodic-report] Falha inesperada no agendador:', error.message);
        } finally {
            setTimeout(scheduleNext, msUntilNextDailyRun(Number.isFinite(DAILY_REPORT_HOUR) ? DAILY_REPORT_HOUR : 8));
        }
    };

    const msFirst = msUntilNextDailyRun(Number.isFinite(DAILY_REPORT_HOUR) ? DAILY_REPORT_HOUR : 8);
    const nextRun = new Date(Date.now() + msFirst);
    console.log(`[periodic-report] ✅ Serviço iniciado. Próximo ciclo: ${nextRun.toLocaleString('pt-BR', { timeZone: APP_TZ })}`);
    setTimeout(scheduleNext, msFirst);
};

export const __reportUtils = {
    getReportPeriod,
    estimateDailyUsage,
    calculateReplenishmentForecast,
    buildMedicationSummary,
    buildFutureConsultations,
    buildVitalSignsInPeriod
};
