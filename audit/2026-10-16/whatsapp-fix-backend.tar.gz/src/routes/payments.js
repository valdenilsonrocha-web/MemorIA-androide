import express from 'express';
import { configured, packageName, productId } from '../services/googlePlay.js';
import { verifyGooglePlayPurchase, googlePlayNotification } from '../controllers/googlePlayController.js';
import { body } from 'express-validator';
import rateLimit from 'express-rate-limit';
import { createCheckoutSession, getPaymentConfig, verifySession, getSubscriptionStatus, cancelSubscription, subscribeWithCard, stripeWebhook } from '../controllers/paymentController.js';
import { protect } from '../middleware/auth.js';
import { handleValidationErrors } from '../middleware/validation.js';

const router = express.Router();

const paymentLimiter = rateLimit({
	windowMs: 10 * 60 * 1000,
	max: 20,
	standardHeaders: true,
	legacyHeaders: false,
	message: {
		success: false,
		message: 'Muitas tentativas de checkout. Tente novamente em alguns minutos.'
	}
});

router.post('/google-play/notifications', googlePlayNotification);
router.get('/config', getPaymentConfig);
router.get('/google-play/config', protect, (req,res) => res.json({success:true,data:{
    configured:configured(), packageName:packageName(), productId:productId()
}}));
router.post('/google-play/verify', protect, paymentLimiter, [
    body('purchaseToken').isString().isLength({min:10,max:4096}).withMessage('Token de compra inválido.')
], handleValidationErrors, verifyGooglePlayPurchase);
router.post(
	'/create-checkout-session',
	paymentLimiter,
	[
		body('plan').optional().isIn(['monthly', 'annual']).withMessage('Plano de pagamento inválido.'),
		body('customerName').optional({ checkFalsy: true }).trim().isLength({ min: 3, max: 120 }).withMessage('Nome do titular inválido.'),
		body('customerEmail').optional({ checkFalsy: true }).isEmail().withMessage('Email do titular inválido.'),
		// Campos de NF: opcionais na rota (o Mercado Pago não os exige). O controller
		// Stripe continua a exigir presença (missingInvoiceFields) quando esse gateway está ativo.
		body('invoiceLegalName').optional({ checkFalsy: true }).isString().trim().isLength({ min: 3, max: 120 }).withMessage('Nome/Razão social para nota fiscal inválido.'),
		body('invoiceDocument').optional({ checkFalsy: true }).isString().trim().matches(/^(\d{11}|\d{14})$/).withMessage('CPF/CNPJ para nota fiscal inválido.'),
		body('invoiceEmail').optional({ checkFalsy: true }).isEmail().withMessage('Email para nota fiscal inválido.'),
		body('invoicePhone').optional({ checkFalsy: true }).isString().trim().matches(/^\d{10,15}$/).withMessage('Telefone para nota fiscal inválido.'),
		body('invoiceAddressLine1').optional({ checkFalsy: true }).isString().trim().isLength({ min: 3, max: 120 }).withMessage('Logradouro para nota fiscal inválido.'),
		body('invoiceAddressNumber').optional({ checkFalsy: true }).isString().trim().isLength({ min: 1, max: 20 }).withMessage('Número do endereço para nota fiscal inválido.'),
		body('invoiceNeighborhood').optional({ checkFalsy: true }).isString().trim().isLength({ min: 2, max: 80 }).withMessage('Bairro para nota fiscal inválido.'),
		body('invoiceCity').optional({ checkFalsy: true }).isString().trim().isLength({ min: 2, max: 80 }).withMessage('Cidade para nota fiscal inválida.'),
		body('invoiceState').optional({ checkFalsy: true }).isString().trim().matches(/^[A-Za-z]{2}$/).withMessage('UF para nota fiscal inválida.'),
		body('invoiceZipCode').optional({ checkFalsy: true }).isString().trim().matches(/^\d{8}$/).withMessage('CEP para nota fiscal inválido.'),
		body('invoiceCountry').optional({ checkFalsy: true }).isString().trim().isLength({ min: 2, max: 2 }).withMessage('País para nota fiscal inválido.'),
		body('cardNumber').not().exists().withMessage('Não envie número de cartão para o backend.'),
		body('card_number').not().exists().withMessage('Não envie número de cartão para o backend.'),
		body('cvv').not().exists().withMessage('Não envie CVV para o backend.'),
		body('cvc').not().exists().withMessage('Não envie CVC para o backend.'),
		body('expMonth').not().exists().withMessage('Não envie dados de expiração para o backend.'),
		body('expYear').not().exists().withMessage('Não envie dados de expiração para o backend.')
	],
	handleValidationErrors,
	createCheckoutSession
);

router.post(
	'/verify-session',
	protect,
	paymentLimiter,
	[
		body('sessionId').isString().trim().isLength({ min: 10, max: 200 }).withMessage('sessionId inválido.')
	],
	handleValidationErrors,
	verifySession
);

router.post(
	'/subscription-status',
	protect,
	paymentLimiter,
	[
		body('sessionId').isString().trim().isLength({ min: 10, max: 200 }).withMessage('sessionId inválido.')
	],
	handleValidationErrors,
	getSubscriptionStatus
);

// Assinatura pelo app nativo: recebe SÓ o token do cartão, nunca o cartão.
router.post(
	'/subscribe',
	paymentLimiter,
	protect,
	[
		body('plan').optional().isIn(['monthly', 'annual']).withMessage('Plano de pagamento inválido.'),
		body('cardTokenId').trim().isLength({ min: 8, max: 128 }).withMessage('Token do cartão inválido.'),
		body('payerEmail').optional({ checkFalsy: true }).isEmail().withMessage('E-mail do pagador inválido.')
	],
	handleValidationErrors,
	subscribeWithCard
);
router.post('/cancel-subscription', protect, paymentLimiter, cancelSubscription);

// Webhook Stripe — raw body tratado no server.js antes do express.json()
router.post('/webhook', stripeWebhook);

export default router;
