import express from 'express';
import { body } from 'express-validator';
import { register, login, getMe, updateProfile, updateConsent, forgotPassword, resetPassword, exportMyData, deleteMyAccount } from '../controllers/authController.js';
import { protect } from '../middleware/auth.js';
import { handleValidationErrors } from '../middleware/validation.js';

const isValidEmailAddress = (value = '') => {
	const normalized = String(value || '').trim().toLowerCase();
	const at = normalized.indexOf('@');
	if (at <= 0 || at !== normalized.lastIndexOf('@')) return false;
	const domain = normalized.slice(at + 1);
	return (
		!normalized.includes(' ') &&
		domain.includes('.') &&
		!domain.startsWith('.') &&
		!domain.endsWith('.')
	);
};

const router = express.Router();

router.post(
	'/register',
	[
		body('cpf').trim().matches(/^\d{11}$/).withMessage('CPF deve conter 11 dígitos numéricos.'),
		body('name').trim().isLength({ min: 3, max: 255 }).withMessage('Nome deve ter entre 3 e 255 caracteres.'),
		body('password').isLength({ min: 8, max: 72 }).withMessage('Senha deve ter entre 8 e 72 caracteres.'),
		body('lgpdConsent').custom((value) => value === true).withMessage('Você deve aceitar a política de privacidade (LGPD).'),
		body('email').optional({ checkFalsy: true }).isEmail().withMessage('Email inválido.'),
		body('phone').optional({ checkFalsy: true }).trim().isLength({ max: 20 }).withMessage('Telefone inválido.'),
		body('susCard').optional({ checkFalsy: true }).trim().isLength({ max: 15 }).withMessage('Cartão SUS inválido.')
	],
	handleValidationErrors,
	register
);

router.post(
	'/login',
	[
		body('cpf').trim().matches(/^\d{11}$/).withMessage('CPF deve conter 11 dígitos numéricos.'),
		body('password').isLength({ min: 1 }).withMessage('Senha é obrigatória.')
	],
	handleValidationErrors,
	login
);
router.get('/me', protect, getMe);
router.put(
	'/profile',
	protect,
	[
		body('name').optional({ checkFalsy: true }).trim().isLength({ min: 3, max: 255 }).withMessage('Nome inválido.'),
		body('email').optional({ checkFalsy: true }).isEmail().withMessage('Email inválido.'),
		body('phone').optional({ checkFalsy: true }).trim().isLength({ max: 20 }).withMessage('Telefone inválido.'),
		body('zipCode').optional({ checkFalsy: true }).trim().isLength({ max: 8 }).withMessage('CEP inválido.'),
		body('reportAutoSendEnabled').optional().isBoolean().withMessage('Configuração de envio automático inválida.'),
		body('reportFrequency').optional().isIn(['weekly', 'monthly']).withMessage('Frequência de relatório inválida.'),
		body('reportContactEmail').optional({ nullable: true }).custom((value) => {
			if (value === null || value === undefined || String(value).trim() === '') return true;
			return isValidEmailAddress(value);
		}).withMessage('E-mail de contato do relatório inválido.'),
		body('medicalConsultations').optional().isArray({ max: 100 }).withMessage('Consultas médicas inválidas.'),
		body('healthVitalSigns').optional().isArray({ max: 5000 }).withMessage('Sinais vitais inválidos.')
	],
	handleValidationErrors,
	updateProfile
);

router.put(
	'/consent',
	protect,
	[
		body('consent').isBoolean().withMessage('Consentimento deve ser verdadeiro ou falso.')
	],
	handleValidationErrors,
	updateConsent
);

router.post(
	'/forgot-password',
	[
		body('cpf').trim().matches(/^\d{11}$/).withMessage('CPF inválido.'),
		body('email').isEmail().withMessage('E-mail inválido.')
	],
	handleValidationErrors,
	forgotPassword
);

router.post(
	'/reset-password',
	[
		body('token').trim().notEmpty().withMessage('Token é obrigatório.'),
		body('newPassword').isLength({ min: 8, max: 72 }).withMessage('A nova senha deve ter entre 8 e 72 caracteres.')
	],
	handleValidationErrors,
	resetPassword
);

// LGPD — direito de acesso/portabilidade e de apagamento
router.get('/export-data', protect, exportMyData);
router.delete('/account', protect, deleteMyAccount);

export default router;
