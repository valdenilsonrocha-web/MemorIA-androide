import express from 'express';
import { query } from 'express-validator';
import {
    getPublicHealthStats,
    getMedicationReport,
    getLowAdherenceAlerts,
    exportAnonymizedData,
    getOwnerStats
} from '../controllers/adminController.js';
import { protect, adminOnly } from '../middleware/auth.js';
import { handleValidationErrors } from '../middleware/validation.js';

const router = express.Router();

router.use(protect, adminOnly);

router.get('/owner-stats', getOwnerStats);

router.get(
    '/stats',
    [
        query('startDate').optional().isISO8601().withMessage('startDate inválido.'),
        query('endDate').optional().isISO8601().withMessage('endDate inválido.'),
        query('region').optional({ checkFalsy: true }).isString().trim().isLength({ max: 120 }).withMessage('region inválido.'),
        query('healthUnit').optional({ checkFalsy: true }).isString().trim().isLength({ max: 120 }).withMessage('healthUnit inválido.')
    ],
    handleValidationErrors,
    getPublicHealthStats
);

router.get(
    '/medications/report',
    [
        query('medicationName').optional({ checkFalsy: true }).isString().trim().isLength({ max: 120 }).withMessage('medicationName inválido.'),
        query('startDate').optional().isISO8601().withMessage('startDate inválido.'),
        query('endDate').optional().isISO8601().withMessage('endDate inválido.')
    ],
    handleValidationErrors,
    getMedicationReport
);

router.get(
    '/alerts/low-adherence',
    [
        query('threshold').optional().isInt({ min: 1, max: 100 }).withMessage('threshold inválido.'),
        query('days').optional().isInt({ min: 1, max: 365 }).withMessage('days inválido.')
    ],
    handleValidationErrors,
    getLowAdherenceAlerts
);

router.get(
    '/export',
    [
        query('startDate').optional().isISO8601().withMessage('startDate inválido.'),
        query('endDate').optional().isISO8601().withMessage('endDate inválido.')
    ],
    handleValidationErrors,
    exportAnonymizedData
);

export default router;
