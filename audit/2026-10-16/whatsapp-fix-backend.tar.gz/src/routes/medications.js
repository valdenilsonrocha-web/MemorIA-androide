import express from 'express';
import {
    getMedications,
    getMedication,
    createMedication,
    updateMedication,
    deleteMedication,
    syncMedications
} from '../controllers/medicationController.js';
import { protect } from '../middleware/auth.js';
import { validateUuidParam } from '../middleware/validation.js';

const router = express.Router();

router.use(protect); // All routes require authentication

router.route('/')
    .get(getMedications)
    .post(createMedication);

router.post('/sync', syncMedications);

router.route('/:id')
    .all(validateUuidParam('id'))
    .get(getMedication)
    .put(updateMedication)
    .delete(deleteMedication);

export default router;
