import express from 'express';
import {
    getHistory,
    addHistoryEntry,
    syncHistory,
    getAdherence
} from '../controllers/historyController.js';
import { protect } from '../middleware/auth.js';

const router = express.Router();

router.use(protect); // All routes require authentication

router.route('/')
    .get(getHistory)
    .post(addHistoryEntry);

router.post('/sync', syncHistory);
router.get('/adherence', getAdherence);

export default router;
