import express from 'express';
import { protect } from '../middleware/auth.js';
import { validateUuidParam } from '../middleware/validation.js';
import {
    getPrescriptions,
    createPrescription,
    deletePrescription
} from '../controllers/prescriptionController.js';

const router = express.Router();

router.use(protect);

router.route('/')
    .get(getPrescriptions)
    .post(createPrescription);

router.delete('/:id', validateUuidParam('id'), deletePrescription);

export default router;
