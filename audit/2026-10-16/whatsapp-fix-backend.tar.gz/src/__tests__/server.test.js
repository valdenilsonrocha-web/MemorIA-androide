import request from 'supertest';
import { app } from '../server.js';

describe('MemorIA backend health endpoints', () => {
    test('GET /health returns ok payload', async () => {
        const response = await request(app).get('/health');

        expect(response.status).toBe(200);
        expect(response.body.status).toBe('ok');
        expect(response.body).toHaveProperty('timestamp');
        expect(response.body).toHaveProperty('uptime');
    });

    test('GET /api/health returns ok payload', async () => {
        const response = await request(app).get('/api/health');

        expect(response.status).toBe(200);
        expect(response.body.status).toBe('ok');
    });

    test('unknown routes return 404 json', async () => {
        const response = await request(app).get('/rota-inexistente');

        expect(response.status).toBe(404);
        expect(response.body.success).toBe(false);
        expect(response.body.message).toMatch(/Endpoint nao encontrado|Endpoint não encontrado/);
    });
});
