import { jest } from '@jest/globals';
process.env.DB_DIALECT = 'sqlite';
process.env.DB_STORAGE = ':memory:';
process.env.WHATSAPP_PROVIDER = 'evolution';
process.env.EVOLUTION_API_KEY = 'test-only-key';
process.env.EVOLUTION_API_URL = 'http://example.test';
process.env.WHATSAPP_ADMIN_TOKEN = 'a'.repeat(64);
process.env.WHATSAPP_WEBHOOK_SECRET = 'b'.repeat(64);
const { default: sequelize, WhatsAppDelivery, WhatsAppEvent, Medication, MedicationHistory } = await import('../models/index.js');
const { sendTrackedWhatsApp, normalizePhone, invalidateConnection, recordEvolutionWebhook } = await import('../services/whatsappTransport.js');
const { __whatsappReminderUtils, runReminderCheck, runMissedDoseCheck, expireWhatsAppDeliveries } = await import('../services/whatsappReminderService.js');
const { getLocalDayBounds, isScheduledOnDate } = await import('../services/medicationSchedule.js');
const { app } = await import('../server.js');
const { default: request } = await import('supertest');
const originalFetch = global.fetch;
const response = (data, ok = true, status = 200) => ({ ok, status, json: async () => data });
let connected;
let sends;
let sendResult;
const input = (overrides = {}) => ({ deliveryKey: 'test:dose:1', to: '(11) 91234-5678', message: 'Mensagem sintética', expiresAt: new Date(Date.now() + 3600000), ...overrides });

beforeAll(async () => { await WhatsAppDelivery.sync({ force: true }); await WhatsAppEvent.sync({ force: true }); });
afterAll(async () => { global.fetch = originalFetch; await sequelize.close(); });
beforeEach(async () => {
    jest.restoreAllMocks();
    await WhatsAppDelivery.destroy({ where: {} }); await WhatsAppEvent.destroy({ where: {} });
    connected = true; sends = 0; sendResult = response({ key: { id: 'provider-message-1' }, status: 'PENDING' }, true, 201);
    invalidateConnection();
    global.fetch = jest.fn(async (url, options) => {
        if (url.includes('/connectionState/')) return response({ instance: { state: connected ? 'open' : 'close' } });
        if (url.includes('/sendText/')) { sends++; expect(JSON.parse(options.body).number).toBe('5511912345678'); return sendResult; }
        throw new Error('Unexpected outbound request');
    });
});

test('Brazilian numbers normalize DDI and trunk zero without altering valid international digits', () => {
    expect(normalizePhone('011912345678')).toBe('5511912345678');
    expect(normalizePhone('+55 (11) 91234-5678')).toBe('5511912345678');
    expect(normalizePhone('+351912345678')).toBe('351912345678');
    expect(normalizePhone('123')).toBe('');
});
test('provider acceptance is persisted once across subsequent scans and cache resets', async () => {
    const first = await sendTrackedWhatsApp(input());
    invalidateConnection();
    const second = await sendTrackedWhatsApp(input());
    expect(first.status).toBe('accepted'); expect(second.duplicate).toBe(true); expect(sends).toBe(1);
    expect(await WhatsAppEvent.count({ where: { status: 'delivered' } })).toBe(0);
    expect(await WhatsAppEvent.count({ where: { status: 'accepted' } })).toBe(1);
});
test('closed session records the outage without submitting messages', async () => {
    connected = false;
    const result = await sendTrackedWhatsApp(input());
    expect(result.status).toBe('waiting_connection'); expect(sends).toBe(0);
    expect(await WhatsAppEvent.count({ where: { status: 'waiting_connection' } })).toBe(1);
});
test('known rejection retries after backoff within the recovery window', async () => {
    const now = new Date();
    sendResult = response({ response: { message: ['socket disconnected'] } }, false, 500);
    const first = await sendTrackedWhatsApp(input({ now }));
    expect(first.status).toBe('pending');
    await sendTrackedWhatsApp(input({ now: new Date(now.getTime() + 1000) }));
    expect(sends).toBe(1);
    sendResult = response({ key: { id: 'retry-id' } }, true, 201);
    expect((await sendTrackedWhatsApp(input({ now: new Date(now.getTime() + 61000) }))).ok).toBe(true);
    expect(sends).toBe(2);
});
test('lost response becomes uncertain and is not blindly resubmitted', async () => {
    const normal = global.fetch;
    global.fetch = jest.fn(async (url, options) => { if (url.includes('/sendText/')) { sends++; throw new Error('timeout'); } return normal(url, options); });
    expect((await sendTrackedWhatsApp(input())).status).toBe('uncertain');
    expect((await sendTrackedWhatsApp(input())).status).toBe('uncertain');
    expect(sends).toBe(1);
});
test('delivery webhook confirms delivery and ignores late lower acknowledgements', async () => {
    await sendTrackedWhatsApp(input());
    await recordEvolutionWebhook({ event: 'messages.update', data: [{ keyId: 'provider-message-1', status: 'DELIVERY_ACK' }] });
    await recordEvolutionWebhook({ event: 'messages.update', data: [{ keyId: 'provider-message-1', status: 'SERVER_ACK' }] });
    expect((await WhatsAppDelivery.findOne()).status).toBe('delivered');
});
test('expiration and stale processing are explicit states rather than duplicate sends', async () => {
    const now = new Date();
    await WhatsAppDelivery.create({ deliveryKey: 'expired', recipient: '5511912345678', message: 'test', eventType: 'dose-reminder', expiresAt: new Date(now.getTime() - 1000) });
    const stale = await WhatsAppDelivery.create({ deliveryKey: 'stale', recipient: '5511912345678', message: 'test', eventType: 'dose-reminder', status: 'processing' });
    await sequelize.query("UPDATE whatsapp_deliveries SET updated_at = '2020-01-01 00:00:00.000 +00:00' WHERE delivery_key = 'stale'");
    await expireWhatsAppDeliveries(now);
    expect((await WhatsAppDelivery.findOne({ where: { deliveryKey: 'expired' } })).status).toBe('cancelled');
    expect((await WhatsAppDelivery.findByPk(stale.id)).status).toBe('uncertain');
    expect(sends).toBe(0);
});
test('calendar filters weekly and alternate days with recovery across midnight', () => {
    const med = { frequency: 'weekly', weekDays: ['monday'], times: ['09:00'] };
    expect(__whatsappReminderUtils.dueOccurrences(med, new Date('2026-10-16T12:01:00Z'), -5, 30)).toEqual([]);
    expect(isScheduledOnDate({ frequency: 'alternate', createdAt: '2026-10-14T12:00:00Z' }, '2026-10-16')).toBe(true);
    const recovered = __whatsappReminderUtils.dueOccurrences({ frequency: 'daily', times: ['23:55'] }, new Date('2026-10-17T03:05:00Z'), -5, 30);
    expect(recovered[0].date).toBe('2026-10-16');
    expect(getLocalDayBounds('2026-10-16')[0].toISOString()).toBe('2026-10-16T03:00:00.000Z');
});
test('a recovered dose resolves history by scheduled date and skips confirmed doses', async () => {
    const med = { id: 'synthetic', frequency: 'daily', times: ['09:00'], stock: 20, user: { phone: '11912345678' } };
    jest.spyOn(Medication, 'findAll').mockResolvedValue([med]);
    const count = jest.spyOn(MedicationHistory, 'count').mockResolvedValue(1);
    await runReminderCheck(new Date('2026-10-16T12:05:00Z'));
    expect(count.mock.calls[0][0].where.scheduledFor).toBeDefined(); expect(sends).toBe(0);
});
test('operations token is required and cannot authorize patient endpoints', async () => {
    expect((await request(app).get('/api/integrations/whatsapp/ops/status')).status).toBe(401);
    const result = await request(app).get('/api/integrations/whatsapp/ops/status').set('x-whatsapp-admin-token', process.env.WHATSAPP_ADMIN_TOKEN);
    expect(result.body.data.state).toBe('open');
    expect((await request(app).get('/api/medications').set('x-whatsapp-admin-token', process.env.WHATSAPP_ADMIN_TOKEN)).status).toBe(401);
});
test('Evolution webhooks require the separate secret and expected instance', async () => {
    expect((await request(app).post('/api/integrations/whatsapp/webhook').send({ event: 'connection.update' })).status).toBe(401);
    const result = await request(app).post('/api/integrations/whatsapp/webhook').set('x-whatsapp-webhook-token', process.env.WHATSAPP_WEBHOOK_SECRET).send({ instance: process.env.EVOLUTION_INSTANCE_NAME || 'memoria', event: 'connection.update', data: { state: 'open' } });
    expect(result.status).toBe(200);
});
