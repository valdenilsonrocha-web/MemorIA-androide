import { __reportUtils } from '../services/emailService.js';

describe('Periodic report utils', () => {
    test('getReportPeriod returns weekly window by default', () => {
        const now = new Date('2026-07-23T12:00:00.000Z');
        const period = __reportUtils.getReportPeriod(undefined, now);

        expect(period.frequency).toBe('weekly');
        expect(period.key).toMatch(/^2026-W\d{2}$/);
        expect(period.start <= period.end).toBe(true);
    });

    test('getReportPeriod returns monthly period key', () => {
        const now = new Date('2026-07-23T12:00:00.000Z');
        const period = __reportUtils.getReportPeriod('monthly', now);

        expect(period.frequency).toBe('monthly');
        expect(period.key).toBe('2026-07');
    });

    test('buildMedicationSummary includes adherence and replenishment estimation', () => {
        const medications = [
            { id: 'm1', name: 'Losartana', dosage: '50mg', stock: 30, frequency: 'daily', times: ['08:00'] }
        ];
        const history = [
            { medicationId: 'm1', status: 'taken' },
            { medicationId: 'm1', status: 'taken' },
            { medicationId: 'm1', status: 'missed' }
        ];

        const summary = __reportUtils.buildMedicationSummary({ medications, history, periodDays: 7 });

        expect(summary).toHaveLength(1);
        expect(summary[0].adherencePct).toBe(67);
        expect(summary[0].replenishment.stock).toBe(30);
        expect(summary[0].replenishment.daysUntilOut).toBeGreaterThanOrEqual(0);
    });
});
