import {jest} from '@jest/globals';
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import {refreshGooglePlay,accountId} from '../services/googlePlay.js';
const key=crypto.generateKeyPairSync('rsa',{modulusLength:2048}).privateKey.export({format:'pem',type:'pkcs8'});
const original=process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_FILE;
const makeUser=()=>({id:'user-a',googlePlaySubscription:{purchaseToken:'token-a',checkedAt:'2020-01-01',active:true,expiryTime:'2099-01-01'},constructor:{update:jest.fn().mockResolvedValue([1])}});
const data=()=>({subscriptionState:'SUBSCRIPTION_STATE_ACTIVE',acknowledgementState:'ACKNOWLEDGEMENT_STATE_PENDING',externalAccountIdentifiers:{obfuscatedExternalAccountId:accountId('user-a')},lineItems:[{productId:'memoria_premium',expiryTime:'2099-01-01',offerDetails:{basePlanId:'monthly'}}]});
describe('Google Play authoritative refresh and delivery',()=>{
    beforeEach(()=>{
        process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_FILE='/test/service-account.json';
        jest.spyOn(fs,'readFile').mockResolvedValue(JSON.stringify({client_email:'test@example.com',private_key:key}));
    });
    afterEach(()=>jest.restoreAllMocks());
    afterAll(()=>{if(original===undefined)delete process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_FILE;else process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_FILE=original;});
    function gateway(status=200){return jest.spyOn(globalThis,'fetch').mockImplementation(async url=>{
        if(url==='https://oauth2.googleapis.com/token')return new Response(JSON.stringify({access_token:'test-token',expires_in:3600}));
        if(url.endsWith(':acknowledge'))return new Response('',{status:200});
        return new Response(JSON.stringify(status===200?data():{}),{status});
    });}
    test('persist before acknowledgement, and accept empty successful acknowledgement',async()=>{
        const user=makeUser(),fetch=gateway();
        await refreshGooglePlay(user,true);
        expect(user.constructor.update).toHaveBeenCalled();
        const ack=fetch.mock.calls.findIndex(([url])=>url.endsWith(':acknowledge'));
        expect(ack).toBeGreaterThan(0);
        expect(user.constructor.update.mock.invocationCallOrder[0]).toBeLessThan(fetch.mock.invocationCallOrder[ack]);
        expect(user.googlePlaySubscription.plan).toBe('monthly');
    });
    test('concurrent replacement is not overwritten or acknowledged',async()=>{
        const user=makeUser(),saved=user.googlePlaySubscription,fetch=gateway();
        user.constructor.update.mockResolvedValue([0]);
        await refreshGooglePlay(user,true);
        expect(user.googlePlaySubscription).toBe(saved);
        expect(fetch.mock.calls.some(([url])=>url.endsWith(':acknowledge'))).toBe(false);
        expect(user.constructor.update.mock.calls[0][1].where['googlePlaySubscription.purchaseToken']).toBe('token-a');
    });
    test('invalid token revokes access; transient Google errors never extend validity',async()=>{
        const revoked=makeUser();gateway(404);await refreshGooglePlay(revoked,true);
        expect(revoked.googlePlaySubscription.active).toBe(false);
        jest.restoreAllMocks();gateway(503);
        const unavailable=makeUser(),saved=unavailable.googlePlaySubscription;
        await expect(refreshGooglePlay(unavailable,true)).rejects.toThrow();
        expect(unavailable.googlePlaySubscription).toBe(saved);
        expect(unavailable.constructor.update).not.toHaveBeenCalled();
    });
});
