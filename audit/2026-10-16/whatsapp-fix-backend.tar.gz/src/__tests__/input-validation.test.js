/**
 * Cobre as validações de entrada acrescentadas depois dos testes ponta-a-ponta
 * contra o ambiente publicado, onde estes casos devolviam 500 (com o erro cru
 * do Postgres no corpo) ou 201 com os dados silenciosamente alterados.
 *
 * Cada teste falha sem a correção correspondente: são todos casos que o
 * servidor publicado aceitava.
 */
import jwt from 'jsonwebtoken';
import request from 'supertest';
import { jest } from '@jest/globals';
import { app } from '../server.js';
import { User, Medication, MedicationHistory } from '../models/index.js';

const USER_ID = '11111111-1111-4111-8111-111111111111';
const MED_ID = '22222222-2222-4222-8222-222222222222';

describe('Validação de entrada (medicamentos e histórico)', () => {
    const originalJwtSecret = process.env.JWT_SECRET;
    let token;

    beforeEach(() => {
        jest.restoreAllMocks();
        process.env.JWT_SECRET = 'test-jwt-secret';
        jest.spyOn(console, 'error').mockImplementation(() => {});

        jest.spyOn(User, 'findByPk').mockResolvedValue({
            id: USER_ID,
            isActive: true,
            isAdmin: false,
            subscriptionStatus: null,
            update: async () => {},
        });

        token = jwt.sign({ id: USER_ID }, 'test-jwt-secret', { expiresIn: '1h' });
    });

    afterAll(() => {
        if (originalJwtSecret === undefined) delete process.env.JWT_SECRET;
        else process.env.JWT_SECRET = originalJwtSecret;
        jest.restoreAllMocks();
    });

    const auth = (req) => req.set('Authorization', `Bearer ${token}`);

    // ---- :id malformado -----------------------------------------------------

    test('PUT /api/medications/:id com id não-UUID devolve 400, não 500', async () => {
        // Antes descia até ao Postgres e devolvia 500 com
        // "invalid input syntax for type uuid: \"nao-e-uuid\"" no corpo.
        const create = jest.spyOn(Medication, 'findOne');

        const res = await auth(
            request(app)
                .put('/api/medications/nao-e-uuid')
                .send({ name: 'X', dosage: '1mg', frequency: 'daily', times: ['08:00'] })
        );

        expect(res.status).toBe(400);
        expect(res.body.success).toBe(false);
        // Barrado antes de tocar na base — e sem revelar o motor nem o tipo.
        expect(create).not.toHaveBeenCalled();
        expect(JSON.stringify(res.body)).not.toMatch(/uuid|postgres|syntax/i);
    });

    test('DELETE /api/medications/:id com id não-UUID devolve 400', async () => {
        const res = await auth(request(app).delete('/api/medications/123'));
        expect(res.status).toBe(400);
    });

    // ---- medicamento que nunca lembraria -----------------------------------

    test('POST /api/medications sem horários é recusado', async () => {
        // Antes devolvia 201: o utilizador via "cadastrado com sucesso" e nunca
        // recebia lembrete nenhum, porque o agendador salta medicamentos sem horários.
        const create = jest.spyOn(Medication, 'create');

        const res = await auth(
            request(app).post('/api/medications').send({
                name: 'Losartana',
                dosage: '50mg',
                frequency: 'daily',
                times: [],
            })
        );

        expect(res.status).toBe(400);
        expect(res.body.message).toMatch(/horário/i);
        expect(create).not.toHaveBeenCalled();
    });

    test('POST /api/medications com frequência desconhecida é recusado', async () => {
        // Antes era corrigido em silêncio para 'daily' e gravado como se nada fosse.
        const create = jest.spyOn(Medication, 'create');

        const res = await auth(
            request(app).post('/api/medications').send({
                name: 'Losartana',
                dosage: '50mg',
                frequency: 'a-cada-lua-cheia',
                times: ['08:00'],
            })
        );

        expect(res.status).toBe(400);
        expect(res.body.message).toMatch(/frequência/i);
        expect(create).not.toHaveBeenCalled();
    });

    test('POST /api/medications semanal sem dias da semana é recusado', async () => {
        const res = await auth(
            request(app).post('/api/medications').send({
                name: 'Losartana',
                dosage: '50mg',
                frequency: 'weekly',
                times: ['08:00'],
                weekDays: [],
            })
        );

        expect(res.status).toBe(400);
        expect(res.body.message).toMatch(/semana/i);
    });

    test('medicamento inativo pode ser guardado sem horários', async () => {
        // Um tratamento pausado não precisa de agenda — a validação não pode
        // impedir que seja guardado.
        jest.spyOn(Medication, 'create').mockResolvedValue({ id: MED_ID });

        const res = await auth(
            request(app).post('/api/medications').send({
                name: 'Losartana',
                dosage: '50mg',
                frequency: 'daily',
                times: [],
                active: false,
            })
        );

        expect(res.status).toBe(201);
    });

    test('medicamento válido continua a ser aceite', async () => {
        jest.spyOn(Medication, 'create').mockResolvedValue({ id: MED_ID });

        const res = await auth(
            request(app).post('/api/medications').send({
                name: 'Losartana',
                dosage: '50mg',
                frequency: 'daily',
                times: ['08:00', '20:00'],
            })
        );

        expect(res.status).toBe(201);
    });

    // ---- fornecedor não pode ser apagado por omissão ------------------------

    test('PUT sem o campo supplier não mexe no fornecedor guardado', async () => {
        // Nenhum ecrã do app móvel preenche `supplier`, portanto uma edição
        // feita no telemóvel enviava o objeto sem esse campo e apagava o
        // contacto da farmácia definido na web — desligando o alerta de stock
        // crítico sem que ninguém desse por isso.
        let updatePayload = null;
        jest.spyOn(Medication, 'findOne').mockResolvedValue({
            id: MED_ID,
            update: async (data) => { updatePayload = data; },
        });

        const res = await auth(
            request(app).put(`/api/medications/${MED_ID}`).send({
                name: 'Losartana',
                dosage: '50mg',
                frequency: 'daily',
                times: ['08:00'],
            })
        );

        expect(res.status).toBe(200);
        expect(updatePayload).not.toHaveProperty('supplier');
    });

    test('PUT com supplier: null continua a limpar o fornecedor', async () => {
        // Limpar tem de continuar possível — mas só quando é pedido de propósito.
        let updatePayload = null;
        jest.spyOn(Medication, 'findOne').mockResolvedValue({
            id: MED_ID,
            update: async (data) => { updatePayload = data; },
        });

        await auth(
            request(app).put(`/api/medications/${MED_ID}`).send({
                name: 'Losartana',
                dosage: '50mg',
                frequency: 'daily',
                times: ['08:00'],
                supplier: null,
            })
        );

        expect(updatePayload).toHaveProperty('supplier', null);
    });

    // ---- histórico sem medicationId ----------------------------------------

    test('POST /api/history sem medicationId devolve 400, não 500', async () => {
        // `medication_id` é UUID NOT NULL: o campo em falta virava string vazia
        // e só rebentava no Postgres, devolvendo 500 com o erro cru.
        const create = jest.spyOn(MedicationHistory, 'create');

        const res = await auth(
            request(app).post('/api/history').send({
                medicationName: 'Losartana',
                dosage: '50mg',
                scheduleTime: '08:00',
                status: 'taken',
                scheduledFor: '2026-08-08T08:00:00.000Z',
            })
        );

        expect(res.status).toBe(400);
        expect(res.body.message).toMatch(/medicationId/i);
        expect(create).not.toHaveBeenCalled();
        expect(JSON.stringify(res.body)).not.toMatch(/uuid|postgres|syntax/i);
    });

    test('POST /api/history com medicationId não-UUID devolve 400', async () => {
        const res = await auth(
            request(app).post('/api/history').send({
                medicationId: 'nao-e-uuid',
                medicationName: 'Losartana',
                dosage: '50mg',
                scheduleTime: '08:00',
                status: 'taken',
                scheduledFor: '2026-08-08T08:00:00.000Z',
            })
        );

        expect(res.status).toBe(400);
    });

    test('POST /api/history/sync ignora a entrada inválida e grava as boas', async () => {
        // O ponto central: uma entrada má não pode fazer perder o lote inteiro,
        // que é o histórico acumulado offline.
        jest.spyOn(MedicationHistory, 'findOne').mockResolvedValue(null);
        const create = jest.spyOn(MedicationHistory, 'create').mockResolvedValue({ id: 'x' });

        const valida = {
            medicationId: MED_ID,
            medicationName: 'Losartana',
            dosage: '50mg',
            scheduleTime: '08:00',
            status: 'taken',
            scheduledFor: '2026-08-08T08:00:00.000Z',
        };

        const res = await auth(
            request(app)
                .post('/api/history/sync')
                .send({ history: [valida, { ...valida, medicationId: undefined }, valida] })
        );

        expect(res.status).toBe(200);
        expect(res.body.data.syncedCount).toBe(2);
        expect(res.body.data.skippedCount).toBe(1);
        expect(create).toHaveBeenCalledTimes(2);
    });
});
