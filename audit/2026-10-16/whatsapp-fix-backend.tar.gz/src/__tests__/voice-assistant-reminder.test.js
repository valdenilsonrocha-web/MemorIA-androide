import { jest } from '@jest/globals';
import { Medication, MedicationHistory, VoiceAssistantDelivery } from '../models/index.js';

process.env.APP_TIMEZONE ||= 'America/Sao_Paulo';

const {
    __voiceAssistantReminderUtils,
    runVoiceAssistantReminderCycle
} = await import('../services/voiceAssistantReminderService.js');

const {
    getLocalDateKey,
    getMedicationTimes,
    isScheduledOnDate,
    retryDelayMs,
    zonedDateTimeToUtc
} = __voiceAssistantReminderUtils;

describe('Voice assistant reminder scheduling', () => {
    beforeEach(() => {
        jest.restoreAllMocks();
    });

    test('converts a local medication time to UTC and back in the configured timezone', () => {
        const scheduledFor = zonedDateTimeToUtc('2026-09-27', 8, 0);

        expect(scheduledFor.toISOString()).toBe('2026-09-27T11:00:00.000Z');
        expect(getLocalDateKey(scheduledFor)).toBe('2026-09-27');
    });

    test('matches weekly schedules to Sunday as day zero', () => {
        const medication = { frequency: 'weekly', weekDays: [0] };

        expect(isScheduledOnDate(medication, '2026-09-27')).toBe(true);
        expect(isScheduledOnDate(medication, '2026-09-28')).toBe(false);
    });

    test('matches alternate-day schedules against the medication creation date', () => {
        const medication = { frequency: 'alternate', createdAt: '2026-09-25T15:00:00.000Z' };

        expect(isScheduledOnDate(medication, '2026-09-25')).toBe(true);
        expect(isScheduledOnDate(medication, '2026-09-26')).toBe(false);
        expect(isScheduledOnDate(medication, '2026-09-27')).toBe(true);
    });

    test('filters malformed medication times before scheduling', () => {
        const medication = { times: ['08:00', '25:00', '8:00', '18:30'] };

        expect(getMedicationTimes(medication)).toEqual(['08:00', '18:30']);
    });

    test('backs off repeat deliveries and caps the delay at five minutes', () => {
        expect(retryDelayMs(1)).toBe(30_000);
        expect(retryDelayMs(4)).toBe(240_000);
        expect(retryDelayMs(8)).toBe(300_000);
    });

    test('delivers a due dose once and does not send duplicates on the next scan', async () => {
        const user = {
            id: 'user-1',
            name: 'Pessoa Teste',
            isAdmin: true,
            isActive: true,
            voiceAssistantConfig: {
                enabled: true,
                provider: 'alexa',
                deviceName: 'Echo Sala',
                webhookUrl: 'https://example.test/voice'
            }
        };
        const medication = {
            id: 'medication-1',
            user,
            active: true,
            frequency: 'daily',
            times: ['08:00'],
            name: 'Losartana',
            dosage: '50 mg'
        };
        const delivery = {
            id: 'delivery-1',
            user,
            medicationId: medication.id,
            medicationName: medication.name,
            dosage: medication.dosage,
            scheduleTime: '08:00',
            scheduledFor: new Date('2026-09-27T11:00:00.000Z'),
            attempts: 0,
            update: jest.fn().mockResolvedValue(true)
        };

        const fetchSpy = jest.spyOn(globalThis, 'fetch').mockResolvedValue({ ok: true, status: 200 });
        jest.spyOn(Medication, 'findAll').mockResolvedValue([medication]);
        jest.spyOn(Medication, 'findByPk').mockResolvedValue({ id: medication.id, active: true });
        const deliveryLookup = jest.spyOn(VoiceAssistantDelivery, 'findOne').mockResolvedValue(null);
        jest.spyOn(VoiceAssistantDelivery, 'findOrCreate').mockResolvedValue([delivery, true]);
        const pendingDeliveries = jest.spyOn(VoiceAssistantDelivery, 'findAll').mockResolvedValue([delivery]);
        jest.spyOn(VoiceAssistantDelivery, 'update').mockResolvedValue([1]);
        jest.spyOn(MedicationHistory, 'findOne').mockResolvedValue(null);

        await runVoiceAssistantReminderCycle(new Date('2026-09-27T11:00:30.000Z'));
        expect(fetchSpy).toHaveBeenCalledTimes(1);
        expect(JSON.parse(fetchSpy.mock.calls[0][1].body)).toMatchObject({
            provider: 'alexa',
            deviceName: 'Echo Sala',
            userName: 'Pessoa Teste',
            medicationName: 'Losartana',
            scheduleTime: '08:00'
        });

        deliveryLookup.mockResolvedValueOnce({ id: delivery.id });
        pendingDeliveries.mockResolvedValueOnce([]);
        await runVoiceAssistantReminderCycle(new Date('2026-09-27T11:01:00.000Z'));

        expect(fetchSpy).toHaveBeenCalledTimes(1);
    });

    test('keeps a failed webhook delivery pending for a retry', async () => {
        const user = {
            id: 'user-2',
            name: 'Pessoa Teste',
            isAdmin: true,
            isActive: true,
            voiceAssistantConfig: {
                enabled: true,
                provider: 'alexa',
                webhookUrl: 'https://example.test/voice'
            }
        };
        const delivery = {
            id: 'delivery-2',
            user,
            medicationId: 'medication-2',
            medicationName: 'Losartana',
            dosage: '50 mg',
            scheduleTime: '08:00',
            scheduledFor: new Date('2026-09-27T11:00:00.000Z'),
            attempts: 0,
            update: jest.fn().mockResolvedValue(true)
        };

        jest.spyOn(globalThis, 'fetch').mockResolvedValue({ ok: false, status: 503 });
        jest.spyOn(Medication, 'findAll').mockResolvedValue([]);
        jest.spyOn(Medication, 'findByPk').mockResolvedValue({ id: delivery.medicationId, active: true });
        jest.spyOn(VoiceAssistantDelivery, 'findAll').mockResolvedValue([delivery]);
        jest.spyOn(VoiceAssistantDelivery, 'update').mockResolvedValue([1]);
        jest.spyOn(MedicationHistory, 'findOne').mockResolvedValue(null);

        await runVoiceAssistantReminderCycle(new Date('2026-09-27T11:01:00.000Z'));

        expect(delivery.update).toHaveBeenCalledWith(expect.objectContaining({
            status: 'pending',
            attempts: 1,
            lastError: 'Webhook respondeu HTTP 503.'
        }));
    });
});