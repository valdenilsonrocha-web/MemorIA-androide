import {jest} from '@jest/globals';
import crypto from 'node:crypto';
import {validatePushClaims,verifyPushToken} from '../services/googlePlayPush.js';
describe('Google Play Pub/Sub authentication',()=>{
    const original={...process.env};
    beforeEach(()=>{process.env.GOOGLE_PLAY_RTDN_AUDIENCE='https://api.example/notifications';process.env.GOOGLE_PLAY_RTDN_SERVICE_ACCOUNT='push@example.iam.gserviceaccount.com';});
    afterAll(()=>{process.env=original;});
    const now=1000000;
    const claims=()=>({iss:'https://accounts.google.com',aud:process.env.GOOGLE_PLAY_RTDN_AUDIENCE,email:process.env.GOOGLE_PLAY_RTDN_SERVICE_ACCOUNT,email_verified:true,iat:999,exp:1100});
    test('accepts intended verified account and audience',()=>expect(validatePushClaims(claims(),now)).toBe(true));
    test.each([{iss:'https://attacker.example'},{aud:'wrong'},{email:'attacker@example.com'},{email_verified:false},{exp:999},{iat:1200}])('rejects invalid claim %p',(change)=>expect(validatePushClaims({...claims(),...change},now)).toBe(false));
    test('checks the RSA signature against Google keys',async()=>{
        const pair=crypto.generateKeyPairSync('rsa',{modulusLength:2048});
        const encode=v=>Buffer.from(JSON.stringify(v)).toString('base64url');
        const now=Math.floor(Date.now()/1000);
        const unsigned=encode({alg:'RS256',kid:'test-google-key'})+'.'+encode({...claims(),iat:now,exp:now+600});
        const token=unsigned+'.'+crypto.sign('RSA-SHA256',Buffer.from(unsigned),pair.privateKey).toString('base64url');
        const fetch=jest.spyOn(globalThis,'fetch').mockResolvedValue(new Response(JSON.stringify({'test-google-key':pair.publicKey.export({type:'spki',format:'pem'})})));
        try {
            expect(await verifyPushToken('Bearer '+token)).toBe(true);
            expect(await verifyPushToken('Bearer '+unsigned+'.'+Buffer.from('forged').toString('base64url'))).toBe(false);
        } finally {fetch.mockRestore();}
    });
    test('never accepts a malformed or unsigned token',async()=>{
        expect(await verifyPushToken('')).toBe(false);
        expect(await verifyPushToken('Bearer a.b.c')).toBe(false);
        const encode=v=>Buffer.from(JSON.stringify(v)).toString('base64url');
        expect(await verifyPushToken('Bearer '+encode({alg:'none'})+'.'+encode(claims())+'.')).toBe(false);
    });
});
