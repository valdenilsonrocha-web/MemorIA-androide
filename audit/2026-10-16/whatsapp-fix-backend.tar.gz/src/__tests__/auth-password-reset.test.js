import crypto from 'crypto';
import request from 'supertest';
import { jest } from '@jest/globals';
import { app } from '../server.js';
import { User } from '../models/index.js';

describe('Auth password reset flows', () => {
    const originalResendKey = process.env.RESEND_API_KEY;
    const originalFrontendUrl = process.env.FRONTEND_URL;

    beforeEach(() => {
        jest.restoreAllMocks();
        delete process.env.RESEND_API_KEY;
        process.env.FRONTEND_URL = 'http://localhost:8080';
        jest.spyOn(console, 'log').mockImplementation(() => {});
        jest.spyOn(console, 'error').mockImplementation(() => {});
    });

    afterAll(() => {
        if (originalResendKey === undefined) {
            delete process.env.RESEND_API_KEY;
        } else {
            process.env.RESEND_API_KEY = originalResendKey;
        }

        if (originalFrontendUrl === undefined) {
            delete process.env.FRONTEND_URL;
        } else {
            process.env.FRONTEND_URL = originalFrontendUrl;
        }

        jest.restoreAllMocks();
    });

    test('forgot-password returns generic success for unknown account', async () => {
        jest.spyOn(User, 'findOne').mockResolvedValue(null);

        const response = await request(app)
            .post('/api/auth/forgot-password')
            .send({ cpf: '12345678901', email: 'naoexiste@example.com' });

        expect(response.status).toBe(200);
        expect(response.body.success).toBe(true);
        expect(response.body.message).toMatch(/Se encontrarmos uma conta/i);
        expect(User.findOne).toHaveBeenCalledWith({ where: { cpf: '12345678901' } });
    });

    test('forgot-password stores token hash instead of raw token', async () => {
        const mockUser = {
            email: 'user@example.com',
            name: 'Usuario Teste',
            update: jest.fn().mockResolvedValue(true)
        };

        jest.spyOn(User, 'findOne').mockResolvedValue(mockUser);

        const response = await request(app)
            .post('/api/auth/forgot-password')
            .send({ cpf: '12345678901', email: 'user@example.com' });

        expect(response.status).toBe(200);
        expect(mockUser.update).toHaveBeenCalledTimes(1);

        const payload = mockUser.update.mock.calls[0][0];
        expect(payload.resetPasswordToken).toMatch(/^[a-f0-9]{64}$/);
        expect(payload.resetPasswordExpires instanceof Date).toBe(true);
        expect(payload.resetPasswordExpires.getTime()).toBeGreaterThan(Date.now());
    });

    test('reset-password validates hashed token', async () => {
        const rawToken = 'token-seguro-123';
        const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
        const mockUser = {
            resetPasswordExpires: new Date(Date.now() + 15 * 60 * 1000),
            update: jest.fn().mockResolvedValue(true)
        };

        const findOneSpy = jest.spyOn(User, 'findOne').mockResolvedValueOnce(mockUser);

        const response = await request(app)
            .post('/api/auth/reset-password')
            .send({ token: rawToken, newPassword: 'SenhaForte123' });

        expect(response.status).toBe(200);
        expect(findOneSpy).toHaveBeenCalledWith({
            where: {
                resetPasswordToken: tokenHash
            }
        });
        expect(mockUser.update).toHaveBeenCalledWith({
            password: 'SenhaForte123',
            resetPasswordToken: null,
            resetPasswordExpires: null
        });
    });

    test('reset-password supports temporary fallback for legacy raw token', async () => {
        const rawToken = 'token-legado-plain-text';
        const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
        const mockUser = {
            resetPasswordExpires: new Date(Date.now() + 15 * 60 * 1000),
            update: jest.fn().mockResolvedValue(true)
        };

        const findOneSpy = jest
            .spyOn(User, 'findOne')
            .mockResolvedValueOnce(null)
            .mockResolvedValueOnce(mockUser);

        const response = await request(app)
            .post('/api/auth/reset-password')
            .send({ token: rawToken, newPassword: 'SenhaNova123' });

        expect(response.status).toBe(200);
        expect(findOneSpy.mock.calls[0][0]).toEqual({
            where: {
                resetPasswordToken: tokenHash
            }
        });
        expect(findOneSpy.mock.calls[1][0]).toEqual({
            where: {
                resetPasswordToken: rawToken
            }
        });
    });
});
