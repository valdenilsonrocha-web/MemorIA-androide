import jwt from 'jsonwebtoken';
import request from 'supertest';
import { jest } from '@jest/globals';
import { app } from '../server.js';
import { User } from '../models/index.js';

describe('Auth core flows', () => {
    const originalJwtSecret = process.env.JWT_SECRET;
    const originalResendApiKey = process.env.RESEND_API_KEY;

    beforeEach(() => {
        jest.restoreAllMocks();
        process.env.JWT_SECRET = 'test-jwt-secret';
        delete process.env.RESEND_API_KEY;
        jest.spyOn(console, 'error').mockImplementation(() => {});
    });

    afterAll(() => {
        if (originalJwtSecret === undefined) {
            delete process.env.JWT_SECRET;
        } else {
            process.env.JWT_SECRET = originalJwtSecret;
        }

        if (originalResendApiKey === undefined) {
            delete process.env.RESEND_API_KEY;
        } else {
            process.env.RESEND_API_KEY = originalResendApiKey;
        }

        jest.restoreAllMocks();
    });

    test('POST /api/auth/register creates user and returns token', async () => {
        const now = new Date();
        const mockUser = {
            id: 101,
            name: 'Maria Silva',
            email: 'maria@example.com',
            toJSON: () => ({
                id: 101,
                name: 'Maria Silva',
                email: 'maria@example.com',
                phone: '',
                cpf: '12345678901',
                city: '',
                state: '',
                healthUnit: '',
                isActive: true,
                consentDate: now,
                lastSync: null,
                createdAt: now,
                updatedAt: now
            })
        };

        const findOneSpy = jest
            .spyOn(User, 'findOne')
            .mockResolvedValueOnce(null)
            .mockResolvedValueOnce(null);

        jest.spyOn(User, 'create').mockResolvedValue(mockUser);

        const response = await request(app)
            .post('/api/auth/register')
            .send({
                cpf: '12345678901',
                name: 'Maria Silva',
                password: 'SenhaForte123',
                email: 'maria@example.com',
                lgpdConsent: true
            });

        expect(response.status).toBe(201);
        expect(response.body.success).toBe(true);
        expect(response.body.data.user.name).toBe('Maria Silva');
        expect(response.body.data.user.cpfMasked).toBe('123***789**');
        expect(typeof response.body.data.token).toBe('string');
        expect(findOneSpy).toHaveBeenCalledTimes(2);
    });

    test('POST /api/auth/login authenticates active user with valid password', async () => {
        const now = new Date();
        const mockUser = {
            id: 202,
            isActive: true,
            comparePassword: jest.fn().mockResolvedValue(true),
            update: jest.fn().mockResolvedValue(true),
            toJSON: () => ({
                id: 202,
                name: 'Joao Souza',
                email: 'joao@example.com',
                phone: '',
                cpf: '98765432100',
                city: '',
                state: '',
                healthUnit: '',
                isActive: true,
                consentDate: now,
                lastSync: now,
                createdAt: now,
                updatedAt: now
            })
        };

        jest.spyOn(User, 'findOne').mockResolvedValue(mockUser);

        const response = await request(app)
            .post('/api/auth/login')
            .send({ cpf: '98765432100', password: 'SenhaForte123' });

        expect(response.status).toBe(200);
        expect(response.body.success).toBe(true);
        expect(typeof response.body.data.token).toBe('string');
        expect(mockUser.comparePassword).toHaveBeenCalledWith('SenhaForte123');
        expect(mockUser.update).toHaveBeenCalledTimes(1);
    });

    test('PUT /api/auth/profile updates authenticated user data', async () => {
        const now = new Date();
        const token = jwt.sign({ id: 303 }, process.env.JWT_SECRET, { expiresIn: '1h' });
        const mockUser = {
            id: 303,
            isActive: true,
            update: jest.fn().mockResolvedValue(true),
            toJSON: () => ({
                id: 303,
                name: 'Ana Lima',
                email: 'ana@example.com',
                phone: '11999990000',
                cpf: '45678912300',
                city: 'Sao Paulo',
                state: 'SP',
                healthUnit: 'UBS Centro',
                isActive: true,
                consentDate: now,
                lastSync: null,
                createdAt: now,
                updatedAt: now
            })
        };

        jest.spyOn(User, 'findByPk').mockResolvedValue(mockUser);

        const response = await request(app)
            .put('/api/auth/profile')
            .set('Authorization', 'Bearer ' + token)
            .send({ name: 'Ana Lima Atualizada', city: 'Campinas' });

        expect(response.status).toBe(200);
        expect(response.body.success).toBe(true);
        expect(mockUser.update).toHaveBeenCalledWith({
            name: 'Ana Lima Atualizada',
            city: 'Campinas'
        });
    });

    test('PUT /api/auth/profile persists automated report settings and health snapshots', async () => {
        const now = new Date();
        const token = jwt.sign({ id: 333 }, process.env.JWT_SECRET, { expiresIn: '1h' });
        const mockUser = {
            id: 333,
            isActive: true,
            email: 'ana@example.com',
            update: jest.fn().mockResolvedValue(true),
            toJSON: () => ({
                id: 333,
                name: 'Ana Lima',
                email: 'ana@example.com',
                phone: '11999990000',
                cpf: '45678912300',
                city: 'Sao Paulo',
                state: 'SP',
                healthUnit: 'UBS Centro',
                isActive: true,
                consentDate: now,
                lastSync: null,
                createdAt: now,
                updatedAt: now
            })
        };

        jest.spyOn(User, 'findByPk').mockResolvedValue(mockUser);

        const response = await request(app)
            .put('/api/auth/profile')
            .set('Authorization', 'Bearer ' + token)
            .send({
                reportAutoSendEnabled: true,
                reportFrequency: 'monthly',
                reportContactEmail: 'contato@example.com',
                medicalConsultations: [
                    { dateTime: '2030-01-10T09:00:00.000Z', professional: 'Dra. Maria', location: 'Clínica A' }
                ],
                healthVitalSigns: [
                    { date: '2030-01-09T08:00:00.000Z', systolic: 120, diastolic: 80, heartRate: 75 }
                ]
            });

        expect(response.status).toBe(200);
        expect(response.body.success).toBe(true);
        expect(mockUser.update).toHaveBeenCalledWith(expect.objectContaining({
            reportAutoSendEnabled: true,
            reportFrequency: 'monthly',
            reportContactEmail: 'contato@example.com',
            medicalConsultations: expect.any(Array),
            healthVitalSigns: expect.any(Array)
        }));
    });

    test('PUT /api/auth/consent updates consentDate when authenticated', async () => {
        const now = new Date();
        const token = jwt.sign({ id: 404 }, process.env.JWT_SECRET, { expiresIn: '1h' });
        const mockUser = {
            id: 404,
            isActive: true,
            update: jest.fn().mockResolvedValue(true),
            toJSON: () => ({
                id: 404,
                name: 'Carlos Nunes',
                email: 'carlos@example.com',
                phone: '',
                cpf: '15975348620',
                city: '',
                state: '',
                healthUnit: '',
                isActive: true,
                consentDate: now,
                lastSync: null,
                createdAt: now,
                updatedAt: now
            })
        };

        jest.spyOn(User, 'findByPk').mockResolvedValue(mockUser);

        const response = await request(app)
            .put('/api/auth/consent')
            .set('Authorization', 'Bearer ' + token)
            .send({ consent: false });

        expect(response.status).toBe(200);
        expect(response.body.success).toBe(true);
        expect(mockUser.update).toHaveBeenCalledWith({ consentDate: null });
    });
});
