import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import request from 'supertest';
import { app } from '../server.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const routesDir = path.join(here, '..', 'routes');
const serverSource = fs.readFileSync(path.join(here, '..', 'server.js'), 'utf8');

const routeFiles = fs
    .readdirSync(routesDir)
    .filter((name) => name.endsWith('.js'))
    .sort();

/**
 * Maps the identifier each router is imported as to the file it came from:
 *   import prescriptionRoutes from './routes/prescriptions.js';
 * yields { prescriptions: 'prescriptionRoutes' }.
 */
const importedRouters = new Map();
for (const match of serverSource.matchAll(/import\s+(\w+)\s+from\s+'\.\/routes\/([\w-]+)\.js'/g)) {
    importedRouters.set(match[2], match[1]);
}

/** Every identifier actually handed to app.use('/api/...', <identifier>). */
const mountedIdentifiers = new Set();
const mountedPrefixes = new Map();
for (const match of serverSource.matchAll(/app\.use\('(\/api\/[\w-]+)',\s*(\w+)\)/g)) {
    mountedIdentifiers.add(match[2]);
    mountedPrefixes.set(match[2], match[1]);
}

/**
 * These tests exist because of a real outage, not for coverage.
 *
 * `routes/prescriptions.js`, `controllers/prescriptionController.js` and
 * `models/Prescription.js` were all written, committed and correct — and
 * `/api/prescriptions` still answered 404 to every client for weeks, because
 * nobody added the `app.use()` line. "Minhas Receitas" was dead on the web and
 * on Android, and nothing failed loudly: a router that is never mounted is
 * simply unreachable code, and no unit test touching the router directly would
 * have noticed.
 *
 * The first test therefore checks the WIRING rather than any single route, so
 * the next router someone forgets to mount fails here instead of in production.
 */
describe('montagem de rotas', () => {
    test('existe pelo menos um ficheiro de rotas para verificar', () => {
        // Guards against the suite passing vacuously if the directory moves.
        expect(routeFiles.length).toBeGreaterThan(0);
    });

    test.each(routeFiles)('routes/%s é importado e montado no server.js', (fileName) => {
        const base = fileName.replace(/\.js$/, '');
        const identifier = importedRouters.get(base);

        expect(identifier).toBeDefined();
        expect(mountedIdentifiers.has(identifier)).toBe(true);
        expect(mountedPrefixes.get(identifier)).toMatch(/^\/api\//);
    });
});

/**
 * The behavioural half: a mounted protected namespace answers 401 (from
 * `protect`) to an unauthenticated request. 404 would mean the request fell
 * through to the catch-all handler — i.e. the namespace is not mounted at all.
 * This is exactly the 401-vs-404 distinction that identified the original bug.
 */
describe('namespaces protegidos respondem 401, nunca o 404 do catch-all', () => {
    const protectedNamespaces = [
        ['GET', '/api/prescriptions'],
        ['POST', '/api/prescriptions'],
        ['GET', '/api/medications'],
        ['GET', '/api/history'],
        ['GET', '/api/auth/me'],
    ];

    test.each(protectedNamespaces)('%s %s', async (method, url) => {
        const response = await request(app)[method.toLowerCase()](url);

        expect(response.status).toBe(401);
        expect(response.status).not.toBe(404);
    });
});

/**
 * The root endpoint doubles as the API index, so an omission there tells a
 * reader a route does not exist when it does. It drifted once already:
 * `prescriptions` was missing from it even after the mount was fixed.
 */
describe('índice do endpoint raiz', () => {
    test('lista todos os prefixos montados', async () => {
        const response = await request(app).get('/');

        expect(response.status).toBe(200);
        const advertised = Object.values(response.body.endpoints || {});

        for (const prefix of mountedPrefixes.values()) {
            expect(advertised).toContain(prefix);
        }
    });
});
