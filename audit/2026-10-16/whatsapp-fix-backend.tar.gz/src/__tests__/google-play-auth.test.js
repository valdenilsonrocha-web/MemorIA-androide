import { jest } from '@jest/globals';
import { accessToken, configured, usesMetadata } from '../services/googlePlay.js';

// The organization forbids service-account keys: on the VM the token comes from
// the metadata server of the attached service account instead of a JSON key.
describe('Google Play keyless auth (GCE metadata)', () => {
    const realFetch = global.fetch;
    beforeEach(() => {
        delete process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_FILE;
        process.env.GOOGLE_PLAY_AUTH = 'metadata';
    });
    afterEach(() => {
        global.fetch = realFetch;
        delete process.env.GOOGLE_PLAY_AUTH;
    });

    test('metadata mode counts as configured without a key file', () => {
        expect(usesMetadata()).toBe(true);
        expect(configured()).toBe(true);
        delete process.env.GOOGLE_PLAY_AUTH;
        expect(configured()).toBe(false);
    });

    test('a metadata failure is an error, never an empty token', async () => {
        global.fetch = jest.fn(async () => ({ok:false, json:async () => ({})}));
        await expect(accessToken()).rejects.toThrow('autenticação');
    });

    test('token is requested with the metadata header and then cached', async () => {
        global.fetch = jest.fn(async () => ({ok:true, json:async () => ({access_token:'tok-1', expires_in:3599})}));
        await expect(accessToken()).resolves.toBe('tok-1');
        await expect(accessToken()).resolves.toBe('tok-1');
        expect(global.fetch).toHaveBeenCalledTimes(1);
        const [url, init] = global.fetch.mock.calls[0];
        expect(url).toBe('http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token');
        expect(init.headers['Metadata-Flavor']).toBe('Google');
    });
});
