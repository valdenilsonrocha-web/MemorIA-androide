import crypto from 'crypto';
import { isAccessActive, validateWebhookSignature, PLAN_CONFIG } from '../services/mercadoPago.js';

describe('mercadoPago service', () => {
    test('isAccessActive: só "authorized" concede acesso', () => {
        expect(isAccessActive('authorized')).toBe(true);
        expect(isAccessActive('pending')).toBe(false);
        expect(isAccessActive('cancelled')).toBe(false);
        expect(isAccessActive(undefined)).toBe(false);
    });

    test('PLAN_CONFIG tem planos mensal e anual com valor', () => {
        expect(PLAN_CONFIG.monthly.amount).toBeGreaterThan(0);
        expect(PLAN_CONFIG.annual.amount).toBeGreaterThan(0);
    });

    describe('validateWebhookSignature', () => {
        const OLD = process.env.MERCADOPAGO_WEBHOOK_SECRET;
        afterAll(() => { process.env.MERCADOPAGO_WEBHOOK_SECRET = OLD; });

        test('sem secret configurado → aceita (modo dev)', () => {
            delete process.env.MERCADOPAGO_WEBHOOK_SECRET;
            const res = validateWebhookSignature({ xSignature: 'x', xRequestId: 'r', dataId: '1' });
            expect(res.ok).toBe(true);
            expect(res.skipped).toBe(true);
        });

        test('assinatura correta → ok', () => {
            const secret = 'segredo-teste';
            process.env.MERCADOPAGO_WEBHOOK_SECRET = secret;
            const ts = '1700000000';
            const dataId = 'ABC123';
            const manifest = `id:${dataId.toLowerCase()};request-id:req-1;ts:${ts};`;
            const v1 = crypto.createHmac('sha256', secret).update(manifest).digest('hex');
            const res = validateWebhookSignature({
                xSignature: `ts=${ts},v1=${v1}`, xRequestId: 'req-1', dataId
            });
            expect(res.ok).toBe(true);
        });

        test('assinatura errada → rejeita', () => {
            process.env.MERCADOPAGO_WEBHOOK_SECRET = 'segredo-teste';
            const res = validateWebhookSignature({
                xSignature: 'ts=1,v1=deadbeef', xRequestId: 'r', dataId: 'x'
            });
            expect(res.ok).toBe(false);
        });
    });
});
