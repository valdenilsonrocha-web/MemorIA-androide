import { accountId, entitlement, hasGooglePlayAccess } from '../services/googlePlay.js';
import { getUserTrialInfo } from '../middleware/auth.js';
const now=Date.parse('2026-10-05T12:00:00Z');
const make = (state='SUBSCRIPTION_STATE_ACTIVE', expiry='2026-11-05T12:00:00Z') => ({
    subscriptionState:state,
    externalAccountIdentifiers:{obfuscatedExternalAccountId:accountId('user-a')},
    lineItems:[{productId:'memoria_premium',expiryTime:expiry,offerDetails:{basePlanId:'monthly'}}]
});
describe('Google Play server entitlement',()=>{
    test('verified active purchase grants access',()=>{
        const s=entitlement(make(),'user-a','purchase-token',now);
        expect(s.active).toBe(true); expect(s.plan).toBe('monthly');
        expect(hasGooglePlayAccess(s,now)).toBe(true);
    });
    test('purchase cannot be replayed on another MemorIA account',()=>{
        expect(()=>entitlement(make(),'user-b','token',now)).toThrow('outra conta');
        const noOwner=make(); delete noOwner.externalAccountIdentifiers;
        expect(()=>entitlement(noOwner,'user-a','token',now)).toThrow('outra conta');
    });
    test.each(['SUBSCRIPTION_STATE_PENDING','SUBSCRIPTION_STATE_EXPIRED','SUBSCRIPTION_STATE_PAUSED','SUBSCRIPTION_STATE_ON_HOLD'])('%s does not grant access',(state)=>{
        expect(entitlement(make(state),'user-a','token',now).active).toBe(false);
    });
    test('pending token is associated without granting access even before an expiry exists',()=>{
        const pending=make('SUBSCRIPTION_STATE_PENDING'); delete pending.lineItems[0].expiryTime;
        const s=entitlement(pending,'user-a','pending-token',now);
        expect(s.active).toBe(false); expect(s.expiryTime).toBeNull(); expect(s.purchaseToken).toBe('pending-token');
    });
    test('cancelled renewal keeps access until paid expiry',()=>{
        const s=entitlement(make('SUBSCRIPTION_STATE_CANCELED'),'user-a','token',now);
        expect(s.active).toBe(true); expect(hasGooglePlayAccess(s,now+40*86400000)).toBe(false);
    });
    test('grace period grants access, elapsed expiry never does',()=>{
        expect(entitlement(make('SUBSCRIPTION_STATE_IN_GRACE_PERIOD'),'user-a','token',now).active).toBe(true);
        expect(entitlement(make('SUBSCRIPTION_STATE_ACTIVE','2026-10-01T12:00:00Z'),'user-a','token',now).active).toBe(false);
    });
    test('unexpected products and plans are rejected',()=>{
        const bad=make(); bad.lineItems[0].productId='another_product';
        expect(()=>entitlement(bad,'user-a','token',now)).toThrow('inválido');
        bad.lineItems[0].productId='memoria_premium'; bad.lineItems[0].offerDetails.basePlanId='another_plan';
        expect(()=>entitlement(bad,'user-a','token',now)).toThrow('inválido');
    });
    test('Premium gating uses Google expiry rather than permanent authorized status',()=>{
        const user={createdAt:'2020-01-01',googlePlaySubscription:{active:true,expiryTime:'2099-01-01'}};
        expect(getUserTrialInfo(user).isPremium).toBe(true);
        user.googlePlaySubscription.expiryTime='2020-01-01';
        expect(getUserTrialInfo(user).isPremium).toBe(false);
    });
});
